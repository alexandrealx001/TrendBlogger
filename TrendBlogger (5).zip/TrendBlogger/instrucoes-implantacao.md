# Instruções de Implantação para VPS

## 1. Preparação do Servidor

```bash
# Atualizar o sistema
sudo apt update && sudo apt upgrade -y

# Instalar dependências essenciais
sudo apt install -y curl wget git build-essential nginx

# Instalar Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verificar instalações
node -v
npm -v
```

## 2. Configurar PostgreSQL

```bash
# Instalar PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Iniciar e configurar para iniciar com o sistema
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Configurar banco de dados
sudo -u postgres psql

# No shell do PostgreSQL (altere os valores conforme necessário)
CREATE USER trendpulse WITH PASSWORD 'sua_senha_segura';
CREATE DATABASE trendpulse;
GRANT ALL PRIVILEGES ON DATABASE trendpulse TO trendpulse;
\q
```

## 3. Preparar Diretório da Aplicação

```bash
# Criar diretório para a aplicação
sudo mkdir -p /var/www/trendpulse
sudo chown -R $USER:$USER /var/www/trendpulse
cd /var/www/trendpulse

# Descompactar o arquivo ZIP (substitua pelo caminho do seu arquivo)
unzip /caminho/para/trendpulse.zip -d .
```

## 4. Configurar as Variáveis de Ambiente

```bash
# Editar o arquivo .env.production
nano .env.production

# Após editar, copiar para .env
cp .env.production .env
```

## 5. Instalar PM2 para Gerenciamento de Processos

```bash
# Instalar PM2 globalmente
sudo npm install -g pm2
```

## 6. Tornar o Script de Inicialização Executável e Executá-lo

```bash
# Tornar o script executável
chmod +x start-server.sh

# Executar o script
./start-server.sh
```

## 7. Configurar o Nginx

```bash
# Editar o arquivo de configuração
nano nginx-trendpulse.conf

# Substituir "seu-dominio.com" pelo domínio real

# Copiar para o diretório do Nginx
sudo cp nginx-trendpulse.conf /etc/nginx/sites-available/trendpulse

# Criar link simbólico
sudo ln -s /etc/nginx/sites-available/trendpulse /etc/nginx/sites-enabled/

# Testar configuração
sudo nginx -t

# Reiniciar Nginx
sudo systemctl restart nginx
```

## 8. Configurar HTTPS com Certbot

```bash
# Instalar Certbot
sudo apt install -y certbot python3-certbot-nginx

# Obter certificado SSL (substitua pelo seu domínio)
sudo certbot --nginx -d seu-dominio.com -d www.seu-dominio.com

# Verificar renovação automática
sudo certbot renew --dry-run
```

## 9. Configurar Firewall

```bash
# Instalar UFW se não estiver instalado
sudo apt install -y ufw

# Configurar regras
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https

# Ativar o firewall
sudo ufw enable
```

## 10. Verificar o Status da Aplicação

```bash
# Verificar status com PM2
pm2 status

# Ver logs da aplicação
pm2 logs trendpulse

# Monitoramento em tempo real
pm2 monit
```

## 11. Manutenção Regular

### Atualizar a aplicação:

1. Baixar nova versão ZIP
2. Fazer backup da versão atual
3. Descompactar nova versão
4. Reiniciar com PM2: `pm2 restart trendpulse`

### Backup do banco de dados:

```bash
sudo -u postgres pg_dump trendpulse > /backup/trendpulse_$(date +%Y%m%d).sql
```