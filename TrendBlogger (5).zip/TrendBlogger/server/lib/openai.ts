import OpenAI from "openai";
import { storage } from "../storage";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const OPENAI_MODEL = "gpt-4o";

// Initialize OpenAI with API key
const getOpenAI = async () => {
  const apiKey = await storage.getApiKeyByService("openai");
  
  // Prefer environment variable, then fall back to stored API key
  const key = process.env.OPENAI_API_KEY || (apiKey?.key || "");
  
  if (!key) {
    throw new Error("OpenAI API key not found. Please set OPENAI_API_KEY or add key in settings.");
  }
  
  return new OpenAI({ apiKey: key });
};

export interface GeneratePostOptions {
  trend: string;
  contentType: string;
  seoOptimization: boolean;
  useRelatedKeywords: boolean;
  addMetaDescription: boolean;
  useRecentNews: boolean;
  wordCount: string;
}

export interface GeneratedPost {
  title: string;
  content: string;
  metaDescription?: string;
  keywords: string[];
  wordCount: number;
  category: string;
  references?: string[]; // Links externos de referência
}

/**
 * Função que infere a categoria de um post com base nas suas palavras-chave e título
 */
function inferCategoryFromKeywords(keywords: string[], title: string): string {
  // Dicionário de palavras-chave relacionadas a cada categoria
  const categoryKeywords: Record<string, string[]> = {
    tecnologia: ["tecnologia", "digital", "software", "app", "programação", "computação", "ia", "inteligência artificial", "chatgpt", "5g", "iot", "internet", "computador", "celular", "smartphone", "robot", "robô", "automação", "código", "programador", "desenvolvimento", "informática", "inovação", "gadget", "dispositivo", "virtual", "realidade aumentada", "plataforma", "big data", "app"],
    negocios: ["negócios", "empresa", "empreendedorismo", "startups", "mercado", "corporativo", "economia", "negócio", "comercial", "venda", "marketing", "cliente", "empreendedor", "gestão", "administração", "marca", "consumidor", "oferta", "demanda", "loja", "comércio", "serviço", "produto", "b2b", "b2c", "ecommerce"],
    financas: ["finanças", "dinheiro", "investimento", "banco", "pix", "criptomoedas", "financeiro", "economia", "economias", "financiamento", "crédito", "débito", "cartão", "bolsa", "ações", "mercado", "juros", "inflação", "moeda", "capital", "rendimento", "aplicação", "bolsa de valores", "tesouro", "tributação", "imposto", "contabilidade", "receita", "despesa"],
    saude: ["saúde", "bem-estar", "médico", "medicina", "hospital", "clínica", "tratamento", "doença", "covid", "vacina", "enfermidade", "sintoma", "remédio", "medicamento", "terapia", "psicologia", "mental", "físico", "exercício", "nutrição", "alimentação", "dieta", "peso", "corpo", "prevenção", "cuidado", "paciente", "consulta", "diagnóstico", "vírus", "bactéria", "patologia", "procedimento", "cirurgia"],
    politica: ["política", "governo", "eleição", "congresso", "lei", "legislação", "democracia", "voto", "candidato", "presidente", "governador", "prefeito", "senador", "deputado", "partido", "projeto de lei", "constituição", "direito", "público", "estado", "municipal", "federal", "ministério", "ministro", "corrupção", "campanha", "urna", "parlamento", "supremo", "juiz", "tribunal"],
    esportes: ["esporte", "futebol", "copa", "olimpíada", "jogo", "atletismo", "atleta", "competição", "campeonato", "torneio", "partida", "time", "equipe", "jogador", "técnico", "treinador", "estádio", "quadra", "campo", "gol", "ponto", "medalha", "confronto", "vitória", "derrota", "corrida", "maratona", "basquete", "vôlei", "natação"],
    sustentabilidade: ["sustentabilidade", "meio ambiente", "clima", "ecologia", "verde", "biodiversidade", "natureza", "ambiental", "ecológico", "reciclagem", "renovável", "energia limpa", "preservação", "planeta", "terra", "fauna", "flora", "poluição", "desmatamento", "carbono", "aquecimento global", "orgânico", "eco", "horta", "lixo", "resíduo", "reuso", "descarte", "combustível"],
    educacao: ["educação", "escola", "universidade", "faculdade", "ensino", "aprendizado", "professor", "aluno", "estudo", "conhecimento", "aula", "matéria", "disciplina", "pedagógico", "didático", "estudante", "acadêmico", "graduação", "pós-graduação", "mestrado", "doutorado", "curso", "formação", "currículo", "alfabetização", "leitura", "literatura", "ciência", "pesquisa"]
  };

  // Normaliza todas as palavras-chave e o título para minúsculas
  const normalizedKeywords = keywords.map(k => k.toLowerCase());
  const normalizedTitle = title.toLowerCase();
  
  // Cria um mapa de pontuação para cada categoria
  const categoryScores: Record<string, number> = {
    tecnologia: 0,
    negocios: 0,
    financas: 0,
    saude: 0,
    politica: 0,
    esportes: 0,
    sustentabilidade: 0,
    educacao: 0
  };
  
  // Pontua cada categoria com base nas palavras-chave e no título
  for (const [category, catKeywords] of Object.entries(categoryKeywords)) {
    // Verifica palavras-chave
    for (const keyword of normalizedKeywords) {
      for (const catKeyword of catKeywords) {
        if (keyword.includes(catKeyword) || catKeyword.includes(keyword)) {
          categoryScores[category] += 1;
        }
      }
    }
    
    // Verifica no título (peso maior)
    for (const catKeyword of catKeywords) {
      if (normalizedTitle.includes(catKeyword)) {
        categoryScores[category] += 2; // Peso maior para correspondências no título
      }
    }
  }
  
  // Encontra a categoria com maior pontuação
  let bestCategory = "tecnologia"; // Usar tecnologia como padrão em caso de empate ou sem pontuação
  let highestScore = 0;
  
  for (const [category, score] of Object.entries(categoryScores)) {
    if (score > highestScore) {
      highestScore = score;
      bestCategory = category;
    }
  }
  
  return bestCategory;
}

export async function generateBlogPost(options: GeneratePostOptions): Promise<GeneratedPost> {
  const openai = await getOpenAI();
  
  const wordCountMap: Record<string, string> = {
    'short': '500-800',
    'medium': '800-1200',
    'long': '1200-2000',
    'in-depth': '2000+'
  };
  
  const wordCountRange = wordCountMap[options.wordCount.toLowerCase()] || '800-1200';
  
  const seoInstructions = options.seoOptimization 
    ? "Optimize the content for SEO. Include a catchy, keyword-rich title, proper heading structure (H2, H3), and strategic keyword placement." 
    : "";
  
  const keywordsInstructions = options.useRelatedKeywords 
    ? "Include a list of 5-8 relevant keywords related to the topic." 
    : "";
  
  const metaDescriptionInstructions = options.addMetaDescription 
    ? "Include a compelling meta description of about 150-160 characters that would encourage clicks from search results." 
    : "";
    
  const recentNewsInstructions = options.useRecentNews
    ? "Research and include recent information (from the last week) about this topic. Make sure to incorporate the latest developments, statistics, or news related to the topic to keep the content current and relevant."
    : "";
  
  const availableCategories = [
    "tecnologia", "negocios", "financas", "saude", "politica", 
    "esportes", "sustentabilidade", "educacao"
  ];

  const categoryDescriptions = {
    tecnologia: "Tecnologia: posts sobre tecnologia, digital, software, app, programação, computação, IA, inteligência artificial, ChatGPT, 5G, IoT",
    negocios: "Negócios: posts sobre empresas, empreendedorismo, startups, mercado, corporativo, economia de empresas",
    financas: "Finanças: posts sobre dinheiro, investimento, banco, PIX, criptomoedas, finanças pessoais, economia",
    saude: "Saúde: posts sobre bem-estar, médico, medicina, hospital, clínica, tratamento, doença, COVID",
    politica: "Política: posts sobre governo, eleição, congresso, lei, legislação, democracia, voto",
    esportes: "Esportes: posts sobre futebol, copa, olimpíada, jogo, atletismo, atleta, competição, campeonato",
    sustentabilidade: "Sustentabilidade: posts sobre meio ambiente, clima, ecologia, verde, biodiversidade, natureza",
    educacao: "Educação: posts sobre escola, universidade, faculdade, ensino, aprendizado, professor, aluno"
  };

  // Juntar todas as descrições de categorias em um único texto
  const categoriesText = Object.values(categoryDescriptions).join('\n');

  const prompt = `
    Gere um artigo de blog de alta qualidade sobre o tema atual: "${options.trend}".
    
    Tipo de conteúdo: ${options.contentType}
    Contagem de palavras desejada: ${wordCountRange} palavras
    Estilo de escrita: Jornalístico e informativo
    Idioma: Português do Brasil (pt-BR) - É OBRIGATÓRIO que todo o conteúdo esteja em português brasileiro
    
    ${seoInstructions}
    ${keywordsInstructions}
    ${metaDescriptionInstructions}
    ${recentNewsInstructions}
    
    IMPORTANTE: Você DEVE pesquisar na internet e fornecer informações detalhadas sobre este tópico. O estilo de escrita deve ser jornalístico e informativo, apresentando fatos, citações e dados de maneira objetiva.
    
    IMPORTANTE: Você DEVE analisar o conteúdo e atribuir uma destas categorias específicas que melhor se adapte ao conteúdo:
    ${categoriesText}
    
    Você DEVE escolher uma das categorias acima. "geral" NÃO é uma opção válida.
    Se o conteúdo não se encaixar perfeitamente em nenhuma categoria, escolha a mais relevante com base no tema predominante.
    
    O post deve ser informativo, bem estruturado e envolvente. Inclua uma introdução, corpo principal organizado em seções lógicas com subtítulos, e uma conclusão.
    
    IMPORTANTE: Você DEVE incluir pelo menos 3-5 links externos para fontes confiáveis como referências. Formate-os como links HTML adequados (<a href="URL" target="_blank" rel="noopener noreferrer">Texto do link</a>). Use fontes como sites governamentais, universidades, instituições de pesquisa ou fontes de notícias/indústria respeitáveis. Essas referências devem reforçar a credibilidade do conteúdo.
    
    IMPORTANTE: Todo o conteúdo DEVE estar em português do Brasil, incluindo o título, corpo do texto, meta descrição e palavras-chave.
    
    Formate a resposta como um objeto JSON com a seguinte estrutura:
    {
      "title": "Título do post do blog em português",
      "content": "Conteúdo completo do post com formatação HTML adequada (p, h2, h3, ul, ol, etc.) e pelo menos 3-5 links de referência externos, TUDO EM PORTUGUÊS DO BRASIL",
      "metaDescription": "Uma meta descrição atraente para SEO (se solicitado), em português",
      "keywords": ["palavra-chave1", "palavra-chave2", "etc" - todas em português],
      "wordCount": 800,
      "category": "uma dessas: tecnologia, negocios, financas, saude, politica, esportes, sustentabilidade, educacao",
      "references": ["URL1", "URL2", "URL3"] // Inclua também todos os URLs de referência aqui
    }
  `;

  try {
    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [
        { 
          role: "system", 
          content: "Você é um redator especializado em SEO capaz de criar posts de blog de alta qualidade e envolventes que se posicionam bem nos mecanismos de busca. Seu estilo de escrita é jornalístico e informativo, apresentando fatos, citações e dados de maneira objetiva. Você pesquisa extensivamente tópicos na internet e fornece informações detalhadas organizadas em seções lógicas com subtítulos claros. É obrigatório categorizar cada post em uma das categorias específicas fornecidas. Nunca use categorias genéricas como 'geral' ou 'outros'. Sempre escolha a categoria específica mais relevante, mesmo que a correspondência não seja perfeita. Com conteúdo versátil, analise o tema predominante para selecionar a categoria mais apropriada. Sempre inclua pelo menos 3-5 links externos para fontes confiáveis para aumentar a credibilidade e profundidade do seu conteúdo. IMPORTANTE: Você SEMPRE deve escrever em português do Brasil (pt-BR). Nunca gere conteúdo em inglês ou qualquer outro idioma que não seja o português brasileiro."
        },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    // Calculate approximate word count if not provided or ensure it's a number
    if (result.content) {
      // Se wordCount não existir ou não for um número, calcule-o
      if (!result.wordCount || typeof result.wordCount !== 'number') {
        result.wordCount = result.content.split(/\s+/).length;
      }
    }
    
    // Ensure keywords is an array
    if (!result.keywords) {
      result.keywords = [];
    }
    
    // Verificar e definir uma categoria padrão se necessário
    if (!result.category || !availableCategories.includes(result.category)) {
      console.log("Categoria inválida ou não fornecida pela API:", result.category);
      
      // Tentar inferir a categoria a partir das palavras-chave
      const category = inferCategoryFromKeywords(result.keywords, result.title);
      console.log("Categoria inferida:", category);
      result.category = category;
    }
    
    return result as GeneratedPost;
  } catch (error: any) {
    console.error("Error generating blog post:", error.message);
    throw new Error(`Failed to generate blog post: ${error.message}`);
  }
}
