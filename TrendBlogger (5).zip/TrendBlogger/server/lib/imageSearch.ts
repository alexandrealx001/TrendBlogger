import axios from 'axios';
import { storage } from '../storage';

// Google Search API configuration
const GOOGLE_SEARCH_API = 'https://www.googleapis.com/customsearch/v1';

/**
 * Searches for relevant images based on query and keywords
 * @param query The main query (trend title)
 * @param keywords Optional array of keywords to improve image relevance
 */
export async function searchImages(query: string, keywords?: string[]): Promise<string | null> {
  try {
    // Get API key
    const key = process.env.GOOGLE_SEARCH_API_KEY;
    console.log('Searching for images related to:', query);
    if (keywords && keywords.length > 0) {
      console.log('Using keywords:', keywords.join(', '));
    }
    
    if (!key) {
      console.warn('Google Search API key not found in environment');
      // Try to get from database as fallback
      const apiKey = await storage.getApiKeyByService('google_search');
      if (!apiKey?.key) {
        throw new Error('Google Search API key not found');
      }
    }
    
    // Lista expandida de domínios confiáveis para imagens públicas
    const trustedDomains = [
      // Pixabay
      'pixabay.com',
      'cdn.pixabay.com',
      // Pexels
      'pexels.com',
      'images.pexels.com',
      // Unsplash
      'unsplash.com',
      'images.unsplash.com',
      // Flickr
      'flickr.com',
      'live.staticflickr.com',
      'staticflickr.com',
      // StockSnap
      'stocksnap.io',
      // Burst (Shopify)
      'burst.shopify.com',
      // Picjumbo
      'picjumbo.com',
      // Reshot
      'reshot.com',
      // Rawpixel
      'rawpixel.com',
      // Google APIs / Content
      'googleapis.com',
      'googleusercontent.com',
      'gstatic.com',
      // Outros
      'wikimedia.org',
      'libreshot.com',
      'freestockphotos.biz'
    ];
    
    // Função para verificar se uma URL é de um domínio confiável
    const isFromTrustedDomain = (url: string): boolean => {
      try {
        if (!url) return false;
        
        const hostname = new URL(url).hostname;
        return trustedDomains.some(domain => hostname.includes(domain));
      } catch {
        return false;
      }
    };
    
    // Função para garantir que a URL de imagem esteja corretamente formatada
    const ensureCorrectImageUrl = (url: string): string => {
      try {
        // Faz uma verificação básica se é uma URL válida
        const parsedUrl = new URL(url);
        
        // Específico para Unsplash - adiciona parâmetros necessários
        if (parsedUrl.hostname.includes('unsplash.com')) {
          // Extrai a parte base da URL
          const baseUrl = url.split('?')[0];
          // Adiciona os parâmetros necessários
          return `${baseUrl}?q=85&w=1200&auto=format&fit=crop`;
        }
        
        // Para outras fontes, mantém a URL como está
        return url;
      } catch (e) {
        console.warn('Invalid URL format:', url);
        return url; // Retorna como está, mesmo se inválida
      }
    };
    
    // Função para verificar se a imagem está acessível
    const isImageAccessible = async (url: string): Promise<boolean> => {
      try {
        if (!isFromTrustedDomain(url)) {
          console.log(`Rejecting image from untrusted domain: ${url}`);
          return false;
        }
        
        // Verifica se é uma URL válida
        new URL(url);
        
        // Não fazemos requisição real para verificar para evitar problemas de CORS
        // Apenas confiamos nos domínios permitidos
        return true;
      } catch (error: any) {
        console.warn(`Image accessibility check failed for ${url}:`, error?.message || 'Unknown error');
        return false;
      }
    };
    
    // Tenta usar a API do Google Search se existir uma chave
    if (key) {
      try {
        // Constrói a consulta usando palavras-chave quando disponíveis
        const searchQuery = keywords && keywords.length > 0 
          ? `${query} ${keywords.slice(0, 3).join(' ')}` 
          : query;
        
        const searchParams = new URLSearchParams({
          key,
          cx: '017576662512468239146:omuauf_lfve', // Search engine ID
          q: searchQuery,
          searchType: 'image',
          num: '1',
          safe: 'active',
          rights: 'cc_publicdomain,cc_attribute',
          imgSize: 'large'
        });
        
        console.log('Attempting to use Google Search API');
        const response = await axios.get(
          `${GOOGLE_SEARCH_API}?${searchParams.toString()}`,
          { timeout: 5000 }
        );
        
        if (response.data?.items?.length > 0) {
          const imageUrl = response.data.items[0].link;
          
          if (imageUrl && await isImageAccessible(imageUrl)) {
            console.log('Image found via Google Search API:', imageUrl);
            return ensureCorrectImageUrl(imageUrl);
          }
        }
      } catch (error: any) {
        console.warn('Google Search API request failed:', error?.message || 'Unknown error');
      }
    }
    
    // Se a API falhar ou não estiver disponível, usa o método alternativo
    console.log('Using alternative image search method');
    
    // Primeiro tenta encontrar uma imagem usando as palavras-chave
    let imageResult = null;
    
    // Se tivermos palavras-chave, tenta cada uma delas
    if (keywords && keywords.length > 0) {
      // Tenta encontrar combinando o query com cada palavra-chave
      for (const keyword of keywords) {
        const keywordQuery = `${query} ${keyword}`;
        imageResult = getRelevantImage(keywordQuery);
        if (imageResult && await isImageAccessible(imageResult)) {
          console.log(`Found image using keyword: ${keyword}`);
          return ensureCorrectImageUrl(imageResult);
        }
      }
      
      // Se não achou nada específico combinando, tenta só as palavras-chave
      for (const keyword of keywords) {
        imageResult = getRelevantImage(keyword);
        if (imageResult && await isImageAccessible(imageResult)) {
          console.log(`Found image using only keyword: ${keyword}`);
          return ensureCorrectImageUrl(imageResult);
        }
      }
    }
    
    // Se não encontrou com palavras-chave, cai para o query original
    imageResult = getRelevantImage(query);
    
    if (imageResult && await isImageAccessible(imageResult)) {
      return ensureCorrectImageUrl(imageResult);
    }
    
    // Se chegou aqui, nenhuma imagem estava acessível
    console.log('No accessible images found, using fallback');
    return getFallbackImage('default');
  } catch (error: any) {
    console.error('Error fetching image:', error?.message || 'Unknown error');
    
    // Fallback to a generic image
    return getFallbackImage('default');
  }
}

/**
 * Seleciona uma imagem relevante com base em palavras-chave no query
 */
function getRelevantImage(query: string): string | null {
  // Mapeamento de palavras-chave para imagens públicas e acessíveis
  // Usando formatos mais compatíveis (JPG) e imagens verificadas de domínio público
  const keywordImageMap: Record<string, string> = {
    // Technology - Brazil Specific
    "inteligencia artificial": "https://cdn.pixabay.com/photo/2017/05/10/19/29/robot-2301646_1280.jpg",
    "tecnologia brasil": "https://cdn.pixabay.com/photo/2018/05/08/08/44/artificial-intelligence-3382507_1280.jpg",
    "startups": "https://cdn.pixabay.com/photo/2015/01/09/11/08/startup-594090_1280.jpg",
    "computacao": "https://cdn.pixabay.com/photo/2016/11/19/14/00/code-1839406_1280.jpg",
    "chatgpt": "https://cdn.pixabay.com/photo/2023/05/06/17/17/ai-generated-7974299_1280.jpg",
    "ia": "https://cdn.pixabay.com/photo/2023/05/08/15/14/ai-generated-7979391_1280.jpg",
    "app": "https://cdn.pixabay.com/photo/2017/01/19/13/22/ecommerce-1992280_1280.jpg",
    "software": "https://cdn.pixabay.com/photo/2016/11/19/14/00/code-1839406_1280.jpg",
    "programacao": "https://cdn.pixabay.com/photo/2016/11/30/20/58/programming-1873854_1280.png",
    
    // Agribusiness & Rural - Brazil Specific
    "agronegocio": "https://cdn.pixabay.com/photo/2016/09/07/10/25/agriculture-1651275_1280.jpg",
    "agricultura": "https://cdn.pixabay.com/photo/2016/11/14/04/36/agriculture-1822851_1280.jpg",
    "plantacao": "https://cdn.pixabay.com/photo/2016/11/08/05/15/agriculture-1807581_1280.jpg", 
    "rural": "https://cdn.pixabay.com/photo/2014/07/10/11/15/landscape-388858_1280.jpg",
    "agritech": "https://cdn.pixabay.com/photo/2016/11/19/10/31/agriculture-1838935_1280.jpg",
    "fazenda": "https://cdn.pixabay.com/photo/2020/01/10/18/18/rural-4755253_1280.jpg",
    "soja": "https://cdn.pixabay.com/photo/2014/07/01/12/25/wheat-381848_1280.jpg",
    
    // Crypto & Fintech - Brazil Specific
    "criptomoedas": "https://cdn.pixabay.com/photo/2018/01/18/07/31/bitcoin-3089728_1280.jpg", 
    "fintechs": "https://cdn.pixabay.com/photo/2017/12/04/07/34/bitcoin-2996254_1280.jpg",
    "pagamentos digitais": "https://cdn.pixabay.com/photo/2019/01/09/14/13/bank-3923156_1280.jpg",
    "blockchain": "https://cdn.pixabay.com/photo/2018/02/15/23/35/bit-coin-3156347_1280.jpg",
    "pix": "https://cdn.pixabay.com/photo/2017/08/30/07/56/money-2696229_1280.jpg",
    "banco central": "https://cdn.pixabay.com/photo/2016/10/16/16/33/bank-1745352_1280.jpg",
    "banco": "https://cdn.pixabay.com/photo/2018/01/16/01/02/bank-3085452_1280.jpg",
    "dinheiro": "https://cdn.pixabay.com/photo/2017/08/30/07/56/money-2696229_1280.jpg",
    "financas": "https://cdn.pixabay.com/photo/2016/08/25/16/06/money-1619650_1280.jpg",
    "investimento": "https://cdn.pixabay.com/photo/2016/11/27/21/42/stock-1863880_1280.jpg",
    
    // Work - Brazil Specific
    "remoto": "https://cdn.pixabay.com/photo/2020/04/01/16/05/virus-4992372_1280.jpg",
    "trabalho": "https://cdn.pixabay.com/photo/2015/01/08/18/26/man-593333_1280.jpg",
    "empresas brasileiras": "https://cdn.pixabay.com/photo/2015/01/21/13/20/business-606807_1280.jpg",
    "emprego": "https://cdn.pixabay.com/photo/2017/06/27/11/48/team-spirit-2447163_1280.jpg",
    "escritorio": "https://cdn.pixabay.com/photo/2015/05/15/02/07/computer-767781_1280.jpg",
    "carreira": "https://cdn.pixabay.com/photo/2017/01/23/17/33/businessman-2003536_1280.jpg",
    
    // Sustainability - Brazil Specific
    "sustentavel": "https://cdn.pixabay.com/photo/2016/06/29/22/02/renewable-energy-1487835_1280.jpg",
    "energia renovavel": "https://cdn.pixabay.com/photo/2016/10/18/21/22/alternative-1751458_1280.jpg",
    "meio ambiente": "https://cdn.pixabay.com/photo/2015/12/01/20/28/green-1072828_1280.jpg",
    "sustentabilidade": "https://cdn.pixabay.com/photo/2015/07/28/22/11/autumn-865157_1280.jpg",
    "amazonia": "https://cdn.pixabay.com/photo/2014/01/19/07/33/amazon-247630_1280.jpg",
    "floresta": "https://cdn.pixabay.com/photo/2015/06/19/21/24/avenue-815297_1280.jpg",
    "climatica": "https://cdn.pixabay.com/photo/2018/08/21/21/34/globe-3622398_1280.jpg",
    
    // Security & Privacy - Brazil Specific
    "seguranca": "https://cdn.pixabay.com/photo/2017/01/10/03/54/locked-1968548_1280.png",
    "dados": "https://cdn.pixabay.com/photo/2017/01/10/23/01/data-traffic-1970405_1280.png",
    "privacidade": "https://cdn.pixabay.com/photo/2017/06/09/15/41/cyber-security-2387402_1280.jpg",
    "seguranca digital": "https://cdn.pixabay.com/photo/2017/12/23/14/26/password-3035867_1280.png",
    "ciberseguranca": "https://cdn.pixabay.com/photo/2019/09/16/08/29/cyber-4480204_1280.jpg",
    "hacker": "https://cdn.pixabay.com/photo/2017/07/13/12/51/network-2500696_1280.jpg",
    
    // Healthcare - Brazil Specific
    "saude": "https://cdn.pixabay.com/photo/2014/12/10/20/56/medical-563427_1280.jpg",
    "medico": "https://cdn.pixabay.com/photo/2016/11/13/00/40/stetoskop-1820461_1280.jpg",
    "saude digital": "https://cdn.pixabay.com/photo/2019/06/06/16/02/technology-4256272_1280.jpg",
    "hospital": "https://cdn.pixabay.com/photo/2016/11/23/15/14/journal-1853305_1280.jpg",
    "telemedicina": "https://cdn.pixabay.com/photo/2014/10/23/21/01/tablet-500308_1280.jpg",
    "bem estar": "https://cdn.pixabay.com/photo/2017/03/26/21/54/yoga-2176668_1280.jpg",
    "mental": "https://cdn.pixabay.com/photo/2016/11/09/15/27/dna-1811955_1280.jpg",
    
    // IoT & Smart Home - Brazil Specific
    "iot": "https://cdn.pixabay.com/photo/2017/03/23/12/23/virtual-2168404_1280.jpg",
    "casa inteligente": "https://cdn.pixabay.com/photo/2017/05/19/22/03/house-2327756_1280.jpg",
    "automacao": "https://cdn.pixabay.com/photo/2018/04/10/17/26/factory-3308904_1280.jpg",
    "dispositivos": "https://cdn.pixabay.com/photo/2015/06/24/15/45/iphone-820352_1280.jpg",
    "eletronicos": "https://cdn.pixabay.com/photo/2015/02/02/11/08/office-620817_1280.jpg",
    "smartphone": "https://cdn.pixabay.com/photo/2017/01/06/13/38/smartphone-1957740_1280.jpg"
  };
  
  const lowerQuery = query.toLowerCase();
  
  // Verifica por palavras-chave nos tópicos
  for (const [keyword, imageUrl] of Object.entries(keywordImageMap)) {
    if (lowerQuery.includes(keyword)) {
      // Retorna a URL do Pixabay diretamente (sem parâmetros extras)
      return imageUrl;
    }
  }
  
  // Se não encontrou nada específico, usa o fallback
  return getFallbackImage(query);
}

/**
 * Returns a fallback image URL based on the query topic
 */
function getFallbackImage(query: string): string | null {
  // URLs de imagens públicas do Pixabay para diferentes categorias em português
  const categoryMappings: Record<string, string> = {
    // Tecnologia e inovação
    "tecnologia": 'https://cdn.pixabay.com/photo/2015/09/09/19/56/office-932926_1280.jpg',
    "inovacao": 'https://cdn.pixabay.com/photo/2016/11/19/14/16/man-1839500_1280.jpg',
    "digital": 'https://cdn.pixabay.com/photo/2015/05/28/14/38/ux-787980_1280.jpg',
    "internet": 'https://cdn.pixabay.com/photo/2014/08/22/15/27/network-424665_1280.jpg',
    "web": 'https://cdn.pixabay.com/photo/2019/08/26/21/19/internet-4433031_1280.jpg',
    
    // Negócios e finanças
    "negocios": 'https://cdn.pixabay.com/photo/2015/01/09/11/08/startup-594090_1280.jpg',
    "empreendedorismo": 'https://cdn.pixabay.com/photo/2015/01/09/11/08/startup-594091_1280.jpg',
    "financas": 'https://cdn.pixabay.com/photo/2017/03/01/21/41/board-2109862_1280.jpg',
    "economia": 'https://cdn.pixabay.com/photo/2017/12/29/13/49/council-3047260_1280.jpg',
    "mercado": 'https://cdn.pixabay.com/photo/2015/11/19/21/14/glasses-1052023_1280.jpg',
    
    // Saúde e bem-estar
    "saude": 'https://cdn.pixabay.com/photo/2015/06/24/01/15/health-819359_1280.jpg',
    "bem estar": 'https://cdn.pixabay.com/photo/2016/11/18/14/05/brick-wall-1834784_1280.jpg',
    "medico": 'https://cdn.pixabay.com/photo/2017/03/14/03/20/nurse-2141808_1280.jpg',
    
    // Sustentabilidade e meio ambiente
    "ambiental": 'https://cdn.pixabay.com/photo/2015/09/09/16/05/forest-931706_1280.jpg',
    "sustentabilidade": 'https://cdn.pixabay.com/photo/2018/04/06/00/25/nature-3294681_1280.jpg',
    "verde": 'https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_1280.jpg',
    "clima": 'https://cdn.pixabay.com/photo/2018/05/30/15/39/thunderstorm-3441687_1280.jpg',
    
    // Mídia, arte e entretenimento
    "midia": 'https://cdn.pixabay.com/photo/2016/11/29/09/40/person-1868701_1280.jpg',
    "entretenimento": 'https://cdn.pixabay.com/photo/2017/11/24/10/43/ticket-2974645_1280.jpg',
    "cultura": 'https://cdn.pixabay.com/photo/2018/05/19/00/53/art-3412836_1280.jpg',
    "arte": 'https://cdn.pixabay.com/photo/2019/04/29/16/58/graffiti-4166938_1280.jpg',
    
    // Esportes e lazer
    "esportes": 'https://cdn.pixabay.com/photo/2016/11/19/17/33/athletes-1840437_1280.jpg',
    "fitness": 'https://cdn.pixabay.com/photo/2017/08/07/14/02/man-2604149_1280.jpg',
    
    // Política e sociedade
    "politica": 'https://cdn.pixabay.com/photo/2012/04/24/13/49/parliament-40117_1280.jpg',
    "governo": 'https://cdn.pixabay.com/photo/2019/07/29/07/15/capitol-4369476_1280.jpg',
    "social": 'https://cdn.pixabay.com/photo/2019/11/15/10/05/infographic-4628594_1280.jpg',
    
    // Ciência e pesquisa
    "ciencia": 'https://cdn.pixabay.com/photo/2016/11/19/14/16/chemistry-1839751_1280.jpg',
    "pesquisa": 'https://cdn.pixabay.com/photo/2016/10/11/15/13/study-1731942_1280.jpg',
    "laboratorio": 'https://cdn.pixabay.com/photo/2012/02/28/10/22/lab-17841_1280.jpg',
    
    // Viagem e turismo
    "viagem": 'https://cdn.pixabay.com/photo/2016/01/09/18/27/journey-1130732_1280.jpg',
    "turismo": 'https://cdn.pixabay.com/photo/2016/01/19/17/57/car-1149997_1280.jpg',
    
    // Alimentação
    "alimento": 'https://cdn.pixabay.com/photo/2017/06/29/20/09/mexican-2456038_1280.jpg',
    "comida": 'https://cdn.pixabay.com/photo/2014/10/19/20/59/hamburger-494706_1280.jpg',
    
    // Países e locais
    "brasil": 'https://cdn.pixabay.com/photo/2014/06/30/11/40/rio-de-janeiro-380784_1280.jpg',
    "rio": 'https://cdn.pixabay.com/photo/2017/01/08/19/30/rio-de-janeiro-1963744_1280.jpg',
    "saopaulo": 'https://cdn.pixabay.com/photo/2015/10/29/17/07/sao-paulo-1012683_1280.jpg'
  };
  
  // Imagem padrão caso nenhuma categoria seja correspondente
  const defaultImage = 'https://cdn.pixabay.com/photo/2016/02/03/08/32/banner-1176676_1280.jpg';
  
  // Verifica se a consulta corresponde a alguma palavra-chave de categoria
  const lowerQuery = query.toLowerCase();
  
  for (const [category, imageUrl] of Object.entries(categoryMappings)) {
    if (lowerQuery.includes(category)) {
      return imageUrl;
    }
  }
  
  return defaultImage;
}