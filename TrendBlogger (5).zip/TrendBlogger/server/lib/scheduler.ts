import { storage } from '../storage';
import { updateTrendsDatabase } from './googleTrends';
import { generateBlogPost } from './openai';
import { searchImages } from './imageSearch';

/**
 * Initializes the scheduling system
 */
export function initScheduler() {
  // Run every minute to check for scheduled tasks
  const intervalId = setInterval(checkScheduledTasks, 60000);
  
  // Initial trends update
  setTimeout(updateTrendsDatabase, 1000);
  
  return intervalId;
}

/**
 * Checks if any scheduled tasks need to be run
 */
async function checkScheduledTasks() {
  try {
    const now = new Date();
    const activeSchedules = await storage.getActiveSchedules();
    
    for (const schedule of activeSchedules) {
      if (schedule.nextRun && new Date(schedule.nextRun) <= now) {
        await runScheduledTask(schedule.id);
      }
    }
  } catch (error) {
    console.error('Error checking scheduled tasks:', error);
  }
}

/**
 * Runs a specific scheduled task
 */
async function runScheduledTask(scheduleId: number) {
  try {
    const schedule = await storage.getSchedule(scheduleId);
    if (!schedule) return;
    
    console.log(`Running scheduled task: ${schedule.name}`);
    
    const now = new Date();
    let nextRun = calculateNextRun(schedule.frequency, now);
    
    // Execute the task based on schedule settings
    if (schedule.settings) {
      const settings = schedule.settings as any;
      
      if (settings.updateTrends) {
        // Escolher o modo de busca correto (trends ou news)
        const searchMode = settings.searchMode || 'trends';
        
        // Usar o período em dias definido no agendamento (padrão: 1 dia)
        const searchPeriod = settings.searchPeriod || 1;
        
        // Calcular datas de início e fim para o período especificado
        const endDate = new Date(); // Data atual
        const startDate = new Date(endDate.getTime() - (searchPeriod * 24 * 60 * 60 * 1000)); // X dias atrás
        
        console.log(`Buscando ${searchMode === 'trends' ? 'tendências' : 'notícias'} para os últimos ${searchPeriod} dias`);
        
        await updateTrendsDatabase(
          startDate.toISOString(), 
          endDate.toISOString(), 
          searchMode
        );
      }
      
      if (settings.generatePost) {
        const trends = await storage.getTrends(5);
        
        if (trends.length > 0) {
          // Pick a random trend from the top 5
          const trend = trends[Math.floor(Math.random() * trends.length)];
          
          // Generate post
          const generatedPost = await generateBlogPost({
            trend: trend.title,
            contentType: settings.contentType || 'Article',
            seoOptimization: settings.seoOptimization !== false,
            useRelatedKeywords: settings.useRelatedKeywords !== false,
            addMetaDescription: settings.addMetaDescription !== false,
            useRecentNews: settings.useRecentNews !== false,
            wordCount: settings.wordCount || 'medium'
          });
          
          // Search for image if enabled
          let imageUrl = null;
          if (settings.findImage !== false) {
            imageUrl = await searchImages(trend.title);
          }
          
          // Log da categoria identificada
          console.log("Tarefa agendada - Categoria identificada para o post:", generatedPost.category || "não definida");
          
          // Adicionar a keyword da categoria às keywords do post
          if (generatedPost.category && !generatedPost.keywords.includes(generatedPost.category)) {
            generatedPost.keywords.push(generatedPost.category);
          }
          
          // Create post in storage
          await storage.createPost({
            title: generatedPost.title,
            content: generatedPost.content,
            metaDescription: generatedPost.metaDescription,
            keywords: generatedPost.keywords,
            imageUrl: imageUrl || undefined,
            trendId: trend.id,
            status: settings.autoPublish ? 'published' : 'draft',
            wordCount: generatedPost.wordCount,
            category: generatedPost.category || "geral" // Adicionando a categoria explícita
          });
        }
      }
    }
    
    // Update schedule with new run information
    await storage.updateScheduleRunInfo(scheduleId, now, nextRun);
    
  } catch (error) {
    console.error(`Error running scheduled task ${scheduleId}:`, error);
  }
}

/**
 * Calculates the next run date based on frequency
 */
function calculateNextRun(frequency: string, currentDate: Date): Date {
  const nextRun = new Date(currentDate);
  
  switch (frequency) {
    case 'hourly':
      nextRun.setHours(nextRun.getHours() + 1);
      break;
    case 'daily':
      nextRun.setDate(nextRun.getDate() + 1);
      nextRun.setHours(9, 0, 0, 0); // 9 AM
      break;
    case 'weekly':
      nextRun.setDate(nextRun.getDate() + 7);
      nextRun.setHours(9, 0, 0, 0); // 9 AM
      break;
    case 'monthly':
      nextRun.setMonth(nextRun.getMonth() + 1);
      nextRun.setDate(1);
      nextRun.setHours(9, 0, 0, 0); // 9 AM on 1st
      break;
    default:
      nextRun.setDate(nextRun.getDate() + 1);
  }
  
  return nextRun;
}
