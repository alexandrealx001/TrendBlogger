import axios from 'axios';
import { JSDOM } from 'jsdom';

export interface NewsItem {
  title: string;
  link: string;
  pubDate: Date;
  source?: string;
}

/**
 * Busca notícias do Google News com base em uma consulta usando o método client-side
 * @param query Termo de busca
 * @param dateStart Data de início (opcional)
 * @param dateEnd Data de fim (opcional)
 * @param limit Limite de notícias a serem retornadas
 * @returns Array de notícias
 */
export async function fetchGoogleNews(
  query: string = 'brasil', 
  dateStart?: Date,
  dateEnd?: Date,
  limit: number = 30
): Promise<NewsItem[]> {
  try {
    console.log(`Buscando notícias para: "${query}"`);
    if (dateStart && dateEnd) {
      console.log(`Período: ${dateStart.toLocaleDateString()} a ${dateEnd.toLocaleDateString()}`);
    }
    
    // Constrói a URL do feed RSS do Google News
    const rssUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(query || 'brasil')}&hl=pt-BR&gl=BR&ceid=BR:pt-419`;
    
    // Usa o serviço AllOrigins para evitar problemas de CORS
    const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(rssUrl)}`;
    
    // Faz a requisição
    const response = await axios.get(proxyUrl);
    
    // Verifica se a resposta é válida
    if (!response.data || !response.data.contents) {
      console.error('Resposta inválida do serviço AllOrigins');
      return [];
    }
    
    // Parse do XML usando JSDOM
    const dom = new JSDOM(response.data.contents, { contentType: "text/xml" });
    const xml = dom.window.document;
    
    // Extrai os itens do feed
    const items = Array.from(xml.querySelectorAll('item'));
    
    // Mapeia os itens para o formato desejado e aplica filtros
    const newsItems: NewsItem[] = [];
    
    for (const item of items) {
      const title = item.querySelector('title')?.textContent || '';
      const link = item.querySelector('link')?.textContent || '';
      const pubDateStr = item.querySelector('pubDate')?.textContent || '';
      const source = item.querySelector('source')?.textContent || undefined;
      
      const pubDate = new Date(pubDateStr);
      
      // Aplica filtros de data
      if (dateStart && pubDate < dateStart) continue;
      if (dateEnd && pubDate > dateEnd) continue;
      
      newsItems.push({
        title,
        link,
        pubDate,
        source
      });
    }
    
    // Ordena por data (mais recente primeiro) e limita a quantidade
    const sortedNews = newsItems
      .sort((a, b) => b.pubDate.getTime() - a.pubDate.getTime())
      .slice(0, limit);
    
    console.log(`Encontradas ${sortedNews.length} notícias para: "${query}"`);
    return sortedNews;
    
  } catch (error) {
    console.error('Erro ao buscar notícias do Google News:', error);
    return [];
  }
}

/**
 * Busca notícias do Google News para múltiplos termos
 * @param queries Lista de termos de busca
 * @param dateStart Data de início (opcional)
 * @param dateEnd Data de fim (opcional)
 * @param limitPerQuery Limite de notícias por termo de busca
 * @returns Array de notícias para cada termo de busca
 */
export async function fetchMultipleNewsTopics(
  queries: string[],
  dateStart?: Date,
  dateEnd?: Date,
  limitPerQuery: number = 10
): Promise<Record<string, NewsItem[]>> {
  const results: Record<string, NewsItem[]> = {};
  
  console.log(`Buscando notícias para ${queries.length} termos: ${queries.join(', ')}`);
  
  // Cria um array de promessas para buscar as notícias em paralelo
  const promises = queries.map(async (query) => {
    const news = await fetchGoogleNews(query, dateStart, dateEnd, limitPerQuery);
    results[query] = news;
  });
  
  // Aguarda todas as buscas terminarem
  await Promise.all(promises);
  
  return results;
}