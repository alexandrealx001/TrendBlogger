import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

// Um valor fixo para o segredo da sessão (em produção, use variáveis de ambiente)
const SESSION_SECRET = process.env.SESSION_SECRET || "bloggen-secret-key-change-in-production";

// Hash de senhas usando scrypt (mais seguro que bcrypt para este caso)
export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// Comparação segura de senhas
async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Configuração do armazenamento de sessões com PostgreSQL
const PostgresSessionStore = connectPg(session);
const sessionStore = new PostgresSessionStore({
  pool,
  tableName: 'session', // nome da tabela para armazenar as sessões
  createTableIfMissing: true, // cria a tabela se não existir
});

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production", // em produção, deve usar HTTPS
      httpOnly: true,
      maxAge: 1000 * 60 * 60 * 24 * 7, // 1 semana
    },
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  // Estratégia de autenticação local (username/password)
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false);
        } else {
          return done(null, user);
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  // Serialização e desserialização de usuários para as sessões
  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user || undefined);
    } catch (error) {
      done(error);
    }
  });

  // Rota de registro (cria um novo usuário)
  app.post("/api/register", async (req, res, next) => {
    try {
      const existingUser = await storage.getUserByUsername(req.body.username);
      if (existingUser) {
        return res.status(400).json({ message: "Usuário já existe" });
      }

      // Hash da senha antes de armazenar
      const hashedPassword = await hashPassword(req.body.password);
      
      const user = await storage.createUser({
        username: req.body.username,
        password: hashedPassword,
      });

      // Login automático após o registro
      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json({ id: user.id, username: user.username });
      });
    } catch (error) {
      next(error);
    }
  });

  // Rota de login
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: Error, user: Express.User) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: "Credenciais inválidas" });
      }
      
      req.login(user, (err) => {
        if (err) return next(err);
        return res.json({ 
          id: user.id, 
          username: user.username,
          name: user.name,
          role: user.role,
          active: user.active
        });
      });
    })(req, res, next);
  });

  // Rota de logout
  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  // Rota para verificar se o usuário está autenticado
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Não autenticado" });
    }
    // Retorna informações do usuário (sem a senha)
    const user = req.user as Express.User;
    res.json({ 
      id: user.id, 
      username: user.username,
      name: user.name,
      role: user.role,
      active: user.active
    });
  });

  // Middleware de proteção de rotas administrativas
  app.use("/api/*", (req, res, next) => {
    // Rotas públicas que não precisam de autenticação
    const publicRoutes = [
      "/api/login", 
      "/api/register", 
      "/api/user",
      "/api/logout",
      // Rotas do blog público
      "/api/blog"
    ];
    
    // Verifica se a rota atual é uma rota pública
    const isPublicRoute = publicRoutes.some(route => 
      req.path === route || req.path.startsWith("/api/blog/")
    );
    
    // Se for uma rota do blog, permite o acesso
    if (req.path.startsWith("/api/posts") && req.method === "GET") {
      // Para GET em posts, apenas verifica se há um parâmetro "status=published"
      if (req.query.status === "published") {
        return next();
      }
    }
    
    // Se for uma rota pública ou o usuário estiver autenticado, permite o acesso
    if (isPublicRoute || req.isAuthenticated()) {
      return next();
    }
    
    // Caso contrário, retorna erro 401
    res.status(401).json({ message: "Acesso não autorizado" });
  });
}