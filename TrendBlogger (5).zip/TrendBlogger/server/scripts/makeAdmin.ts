import { db } from "../db";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";

async function makeUserAdmin(userId: number = 1) {
  try {
    const [updatedUser] = await db
      .update(users)
      .set({ role: "admin" })
      .where(eq(users.id, userId))
      .returning();
    
    if (updatedUser) {
      console.log(`Usuário ID ${userId} agora é administrador:`, updatedUser);
    } else {
      console.error(`Usuário ID ${userId} não encontrado`);
    }
  } catch (error) {
    console.error("Erro ao atualizar usuário:", error);
  } finally {
    process.exit(0);
  }
}

makeUserAdmin();