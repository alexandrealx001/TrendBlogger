import { pool, db } from "../db";
import { users } from "@shared/schema";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import { eq } from "drizzle-orm";

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function createAdminUser() {
  try {
    // Credenciais do administrador
    const adminUsername = "alexandrealx001@gmail.com";
    const adminPassword = "As142110$21"; // Esta senha será hasheada
    
    console.log("Verificando se o usuário administrador já existe...");
    
    // Verifica se o usuário já existe
    const existingUser = await db.select().from(users).where(eq(users.username, adminUsername));
    
    if (existingUser.length > 0) {
      console.log("Usuário administrador já existe.");
      
      // Atualiza a senha se o usuário já existir
      const hashedPassword = await hashPassword(adminPassword);
      await db.update(users)
        .set({ password: hashedPassword })
        .where(eq(users.username, adminUsername));
      
      console.log("Senha do usuário administrador atualizada.");
    } else {
      // Cria um novo usuário admin
      const hashedPassword = await hashPassword(adminPassword);
      
      await db.insert(users).values({
        username: adminUsername,
        password: hashedPassword
      });
      
      console.log("Usuário administrador criado com sucesso.");
    }
  } catch (error) {
    console.error("Erro ao criar/atualizar usuário administrador:", error);
  } finally {
    // Fecha a conexão com o banco de dados
    await pool.end();
  }
}

// Executa a função
createAdminUser();