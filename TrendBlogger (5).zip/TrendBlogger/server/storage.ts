import { 
  users, type User, type InsertUser,
  trends, type Trend, type InsertTrend,
  posts, type Post, type InsertPost,
  schedules, type Schedule, type InsertSchedule,
  apiKeys, type ApiKey, type InsertApiKey,
  visitors, type Visitor, type InsertVisitor,
  pageviews, type Pageview, type InsertPageview,
  uniqueVisitors, type UniqueVisitor, type InsertUniqueVisitor
} from "@shared/schema";
import { db, pool } from "./db";
import { eq, desc, sql, and } from "drizzle-orm";

// Storage interface for all entities
export interface IStorage {
  // User methods (kept from original)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getUsers(): Promise<User[]>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;

  // Trend methods
  getTrends(limit?: number): Promise<Trend[]>;
  getTrend(id: number): Promise<Trend | undefined>;
  createTrend(trend: InsertTrend): Promise<Trend>;
  updateTrend(id: number, trend: Partial<InsertTrend>): Promise<Trend | undefined>;
  deleteTrend(id: number): Promise<boolean>;

  // Post methods
  getPosts(limit?: number): Promise<Post[]>;
  getPost(id: number): Promise<Post | undefined>;
  getPostsByStatus(status: string, limit?: number): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  updatePost(id: number, post: Partial<InsertPost>): Promise<Post | undefined>;
  deletePost(id: number): Promise<boolean>;

  // Schedule methods
  getSchedules(): Promise<Schedule[]>;
  getSchedule(id: number): Promise<Schedule | undefined>;
  getActiveSchedules(): Promise<Schedule[]>;
  createSchedule(schedule: InsertSchedule): Promise<Schedule>;
  updateSchedule(id: number, schedule: Partial<InsertSchedule>): Promise<Schedule | undefined>;
  updateScheduleRunInfo(id: number, lastRun: Date, nextRun: Date): Promise<Schedule | undefined>;
  deleteSchedule(id: number): Promise<boolean>;

  // API Key methods
  getApiKeys(): Promise<ApiKey[]>;
  getApiKeyByService(service: string): Promise<ApiKey | undefined>;
  createApiKey(apiKey: InsertApiKey): Promise<ApiKey>;
  updateApiKey(id: number, apiKey: Partial<InsertApiKey>): Promise<ApiKey | undefined>;
  deleteApiKey(id: number): Promise<boolean>;

  // Visitor methods
  getVisitors(): Promise<Visitor[]>;
  getVisitorById(id: number): Promise<Visitor | undefined>;
  getVisitorByGoogleId(googleId: string): Promise<Visitor | undefined>;
  createVisitor(visitor: InsertVisitor): Promise<Visitor>;
  updateVisitor(id: number, visitor: Partial<InsertVisitor>): Promise<Visitor | undefined>;
  updateVisitorLoginInfo(id: number): Promise<Visitor | undefined>;
  deleteVisitor(id: number): Promise<boolean>;

  // Pageview methods - para contagem de visitantes
  getPageviews(): Promise<Pageview[]>;
  getPageview(path: string): Promise<Pageview | undefined>;
  incrementPageview(path: string, ipAddress: string, userAgent?: string): Promise<Pageview>;
  
  // Unique visitor methods - para contagem de IPs únicos
  getUniqueVisitors(pageviewId: number): Promise<UniqueVisitor[]>;
  getAllUniqueVisitors(): Promise<UniqueVisitor[]>;
  isUniqueVisitor(pageviewId: number, ipAddress: string): Promise<boolean>;
  addUniqueVisitor(pageviewId: number, ipAddress: string, userAgent?: string): Promise<UniqueVisitor>;
  
  // Metrics
  getMetrics(): Promise<{
    totalPosts: number;
    publishedPosts: number;
    processTrends: number;
    activeSchedules: number;
  }>;
}

export class MemStorage implements IStorage {
  private pageviewsMap: Map<number, Pageview>;
  private uniqueVisitorsMap: Map<number, UniqueVisitor[]>;
  private currentPageviewId: number;
  private currentUniqueVisitorId: number;
  private users: Map<number, User>;
  private trendsMap: Map<number, Trend>;
  private postsMap: Map<number, Post>;
  private schedulesMap: Map<number, Schedule>;
  private apiKeysMap: Map<number, ApiKey>;
  private visitorsMap: Map<number, Visitor>;
  
  private currentUserId: number;
  private currentTrendId: number;
  private currentPostId: number;
  private currentScheduleId: number;
  private currentApiKeyId: number;
  private currentVisitorId: number;

  constructor() {
    this.users = new Map();
    this.trendsMap = new Map();
    this.postsMap = new Map();
    this.schedulesMap = new Map();
    this.apiKeysMap = new Map();
    this.visitorsMap = new Map();
    this.pageviewsMap = new Map();
    this.uniqueVisitorsMap = new Map();
    
    this.currentUserId = 1;
    this.currentTrendId = 1;
    this.currentPostId = 1;
    this.currentScheduleId = 1;
    this.currentApiKeyId = 1;
    this.currentVisitorId = 1;
    this.currentPageviewId = 1;
    this.currentUniqueVisitorId = 1;

    // Initialize with sample API keys
    this.createApiKey({ 
      service: "openai", 
      key: process.env.OPENAI_API_KEY || "", 
      isActive: true 
    });
    this.createApiKey({ 
      service: "google_search", 
      key: process.env.GOOGLE_SEARCH_API_KEY || "", 
      isActive: true 
    });
  }

  // User methods (kept from original)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }
  
  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }
  
  async updateUser(id: number, userUpdate: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userUpdate };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  // Trend methods
  async getTrends(limit?: number): Promise<Trend[]> {
    const trends = Array.from(this.trendsMap.values());
    trends.sort((a, b) => (a.rank || 999) - (b.rank || 999));
    return limit ? trends.slice(0, limit) : trends;
  }

  async getTrend(id: number): Promise<Trend | undefined> {
    return this.trendsMap.get(id);
  }

  async createTrend(insertTrend: InsertTrend): Promise<Trend> {
    const id = this.currentTrendId++;
    const trend: Trend = { 
      ...insertTrend, 
      id, 
      createdAt: new Date() 
    };
    this.trendsMap.set(id, trend);
    return trend;
  }

  async updateTrend(id: number, trendUpdate: Partial<InsertTrend>): Promise<Trend | undefined> {
    const trend = this.trendsMap.get(id);
    if (!trend) return undefined;
    
    const updatedTrend = { ...trend, ...trendUpdate };
    this.trendsMap.set(id, updatedTrend);
    return updatedTrend;
  }

  async deleteTrend(id: number): Promise<boolean> {
    return this.trendsMap.delete(id);
  }

  // Post methods
  async getPosts(limit?: number): Promise<Post[]> {
    const posts = Array.from(this.postsMap.values());
    posts.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    return limit ? posts.slice(0, limit) : posts;
  }

  async getPost(id: number): Promise<Post | undefined> {
    return this.postsMap.get(id);
  }

  async getPostsByStatus(status: string, limit?: number): Promise<Post[]> {
    const posts = Array.from(this.postsMap.values()).filter(
      (post) => post.status === status
    );
    posts.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    return limit ? posts.slice(0, limit) : posts;
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = this.currentPostId++;
    const post: Post = {
      ...insertPost,
      id,
      createdAt: new Date(),
      keywords: insertPost.keywords || []
    };
    this.postsMap.set(id, post);
    return post;
  }

  async updatePost(id: number, postUpdate: Partial<InsertPost>): Promise<Post | undefined> {
    const post = this.postsMap.get(id);
    if (!post) return undefined;
    
    const updatedPost = { ...post, ...postUpdate };
    this.postsMap.set(id, updatedPost);
    return updatedPost;
  }

  async deletePost(id: number): Promise<boolean> {
    return this.postsMap.delete(id);
  }

  // Schedule methods
  async getSchedules(): Promise<Schedule[]> {
    return Array.from(this.schedulesMap.values());
  }

  async getSchedule(id: number): Promise<Schedule | undefined> {
    return this.schedulesMap.get(id);
  }

  async getActiveSchedules(): Promise<Schedule[]> {
    return Array.from(this.schedulesMap.values()).filter(
      (schedule) => schedule.active
    );
  }

  async createSchedule(insertSchedule: InsertSchedule): Promise<Schedule> {
    const id = this.currentScheduleId++;
    
    // Calculate next run date based on frequency
    const nextRun = this.calculateNextRunDate(insertSchedule.frequency);
    
    const schedule: Schedule = {
      ...insertSchedule,
      id,
      createdAt: new Date(),
      lastRun: undefined,
      nextRun
    };
    
    this.schedulesMap.set(id, schedule);
    return schedule;
  }

  async updateSchedule(id: number, scheduleUpdate: Partial<InsertSchedule>): Promise<Schedule | undefined> {
    const schedule = this.schedulesMap.get(id);
    if (!schedule) return undefined;
    
    let nextRun = schedule.nextRun;
    if (scheduleUpdate.frequency && scheduleUpdate.frequency !== schedule.frequency) {
      nextRun = this.calculateNextRunDate(scheduleUpdate.frequency);
    }
    
    const updatedSchedule = { 
      ...schedule, 
      ...scheduleUpdate,
      nextRun
    };
    
    this.schedulesMap.set(id, updatedSchedule);
    return updatedSchedule;
  }

  async updateScheduleRunInfo(id: number, lastRun: Date, nextRun: Date): Promise<Schedule | undefined> {
    const schedule = this.schedulesMap.get(id);
    if (!schedule) return undefined;
    
    const updatedSchedule = { 
      ...schedule, 
      lastRun, 
      nextRun 
    };
    
    this.schedulesMap.set(id, updatedSchedule);
    return updatedSchedule;
  }

  async deleteSchedule(id: number): Promise<boolean> {
    return this.schedulesMap.delete(id);
  }

  // API Key methods
  async getApiKeys(): Promise<ApiKey[]> {
    return Array.from(this.apiKeysMap.values());
  }

  async getApiKeyByService(service: string): Promise<ApiKey | undefined> {
    return Array.from(this.apiKeysMap.values()).find(
      (apiKey) => apiKey.service === service && apiKey.isActive
    );
  }

  async createApiKey(insertApiKey: InsertApiKey): Promise<ApiKey> {
    const id = this.currentApiKeyId++;
    const apiKey: ApiKey = {
      ...insertApiKey,
      id,
      createdAt: new Date()
    };
    this.apiKeysMap.set(id, apiKey);
    return apiKey;
  }

  async updateApiKey(id: number, apiKeyUpdate: Partial<InsertApiKey>): Promise<ApiKey | undefined> {
    const apiKey = this.apiKeysMap.get(id);
    if (!apiKey) return undefined;
    
    const updatedApiKey = { ...apiKey, ...apiKeyUpdate };
    this.apiKeysMap.set(id, updatedApiKey);
    return updatedApiKey;
  }

  async deleteApiKey(id: number): Promise<boolean> {
    return this.apiKeysMap.delete(id);
  }

  // Visitor methods
  async getVisitors(): Promise<Visitor[]> {
    return Array.from(this.visitorsMap.values());
  }

  async getVisitorById(id: number): Promise<Visitor | undefined> {
    return this.visitorsMap.get(id);
  }

  async getVisitorByGoogleId(googleId: string): Promise<Visitor | undefined> {
    return Array.from(this.visitorsMap.values()).find(
      (visitor) => visitor.googleId === googleId
    );
  }
  
  async getVisitorByEmail(email: string): Promise<Visitor | undefined> {
    return Array.from(this.visitorsMap.values()).find(
      (visitor) => visitor.email === email
    );
  }
  
  async getVisitorByCPF(cpf: string): Promise<Visitor | undefined> {
    return Array.from(this.visitorsMap.values()).find(
      (visitor) => visitor.cpf === cpf
    );
  }
  
  async getVisitorByResetToken(token: string): Promise<Visitor | undefined> {
    return Array.from(this.visitorsMap.values()).find(
      (visitor) => visitor.resetPasswordToken === token
    );
  }

  async createVisitor(insertVisitor: InsertVisitor): Promise<Visitor> {
    const id = this.currentVisitorId++;
    const visitor: Visitor = {
      ...insertVisitor,
      id,
      lastLogin: new Date(),
      loginCount: 1,
      createdAt: new Date()
    };
    this.visitorsMap.set(id, visitor);
    return visitor;
  }

  async updateVisitor(id: number, visitorUpdate: Partial<InsertVisitor>): Promise<Visitor | undefined> {
    const visitor = this.visitorsMap.get(id);
    if (!visitor) return undefined;
    
    const updatedVisitor = { ...visitor, ...visitorUpdate };
    this.visitorsMap.set(id, updatedVisitor);
    return updatedVisitor;
  }

  async updateVisitorLoginInfo(id: number): Promise<Visitor | undefined> {
    const visitor = this.visitorsMap.get(id);
    if (!visitor) return undefined;
    
    const updatedVisitor = { 
      ...visitor, 
      lastLogin: new Date(),
      loginCount: (visitor.loginCount || 0) + 1 
    };
    
    this.visitorsMap.set(id, updatedVisitor);
    return updatedVisitor;
  }

  async deleteVisitor(id: number): Promise<boolean> {
    return this.visitorsMap.delete(id);
  }

  // Pageview methods
  async getPageviews(): Promise<Pageview[]> {
    return Array.from(this.pageviewsMap.values());
  }

  async getPageview(path: string): Promise<Pageview | undefined> {
    return Array.from(this.pageviewsMap.values()).find(
      (pageview) => pageview.path === path
    );
  }

  async incrementPageview(path: string, ipAddress: string, userAgent?: string): Promise<Pageview> {
    const existingPageview = await this.getPageview(path);
    
    if (existingPageview) {
      // Verifica se é um visitante único
      const isUnique = await this.isUniqueVisitor(existingPageview.id, ipAddress);
      
      const updatedPageview = {
        ...existingPageview,
        count: existingPageview.count + 1,
        uniqueCount: isUnique ? existingPageview.uniqueCount + 1 : existingPageview.uniqueCount,
        lastVisit: new Date()
      };
      
      this.pageviewsMap.set(existingPageview.id, updatedPageview);
      
      // Se for um visitante único, registra o IP
      if (isUnique) {
        await this.addUniqueVisitor(existingPageview.id, ipAddress, userAgent);
      }
      
      return updatedPageview;
    } else {
      const id = this.currentPageviewId++;
      const pageview: Pageview = {
        id,
        path,
        count: 1,
        uniqueCount: 1, // Primeiro visitante é único
        lastVisit: new Date(),
        createdAt: new Date()
      };
      
      this.pageviewsMap.set(id, pageview);
      
      // Registra o primeiro visitante único
      await this.addUniqueVisitor(id, ipAddress, userAgent);
      
      return pageview;
    }
  }
  
  // Métodos para visitantes únicos
  async getUniqueVisitors(pageviewId: number): Promise<UniqueVisitor[]> {
    return this.uniqueVisitorsMap.get(pageviewId) || [];
  }
  
  async getAllUniqueVisitors(): Promise<UniqueVisitor[]> {
    // Concatenar todos os visitantes únicos de todas as páginas
    const allVisitors: UniqueVisitor[] = [];
    this.uniqueVisitorsMap.forEach(visitors => {
      allVisitors.push(...visitors);
    });
    return allVisitors;
  }
  
  async isUniqueVisitor(pageviewId: number, ipAddress: string): Promise<boolean> {
    const visitors = await this.getUniqueVisitors(pageviewId);
    return !visitors.some(visitor => visitor.ipAddress === ipAddress);
  }
  
  async addUniqueVisitor(pageviewId: number, ipAddress: string, userAgent?: string): Promise<UniqueVisitor> {
    const id = this.currentUniqueVisitorId++;
    const uniqueVisitor: UniqueVisitor = {
      id,
      pageviewId,
      ipAddress,
      userAgent: userAgent || null,
      visitDate: new Date()
    };
    
    const currentVisitors = await this.getUniqueVisitors(pageviewId);
    this.uniqueVisitorsMap.set(pageviewId, [...currentVisitors, uniqueVisitor]);
    
    return uniqueVisitor;
  }
  
  // Metrics
  async getMetrics(): Promise<{
    totalPosts: number;
    publishedPosts: number;
    processTrends: number;
    activeSchedules: number;
  }> {
    const publishedPosts = Array.from(this.postsMap.values()).filter(
      post => post.status === 'published'
    ).length;
    
    return {
      totalPosts: this.postsMap.size,
      publishedPosts,
      processTrends: this.trendsMap.size,
      activeSchedules: (await this.getActiveSchedules()).length
    };
  }

  // Helper methods
  private calculateNextRunDate(frequency: string): Date {
    const now = new Date();
    const nextRun = new Date(now);
    
    switch (frequency) {
      case 'hourly':
        nextRun.setHours(nextRun.getHours() + 1);
        break;
      case 'daily':
        nextRun.setDate(nextRun.getDate() + 1);
        nextRun.setHours(9, 0, 0, 0); // 9 AM
        break;
      case 'weekly':
        nextRun.setDate(nextRun.getDate() + 7);
        nextRun.setHours(9, 0, 0, 0); // 9 AM
        break;
      case 'monthly':
        nextRun.setMonth(nextRun.getMonth() + 1);
        nextRun.setDate(1);
        nextRun.setHours(9, 0, 0, 0); // 9 AM on 1st
        break;
      default:
        nextRun.setDate(nextRun.getDate() + 1);
    }
    
    return nextRun;
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  async getUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
  
  async updateUser(id: number, userUpdate: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db.update(users)
      .set(userUpdate)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }
  
  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return !!result;
  }

  async getTrends(limit?: number): Promise<Trend[]> {
    let query = db.select().from(trends).orderBy(trends.rank);
    
    if (limit) {
      query = query.limit(limit);
    }
    
    return await query;
  }

  async getTrend(id: number): Promise<Trend | undefined> {
    const [trend] = await db.select().from(trends).where(eq(trends.id, id));
    return trend;
  }

  async createTrend(insertTrend: InsertTrend): Promise<Trend> {
    const [trend] = await db.insert(trends).values({
      ...insertTrend,
      createdAt: new Date()
    }).returning();
    return trend;
  }

  async updateTrend(id: number, trendUpdate: Partial<InsertTrend>): Promise<Trend | undefined> {
    const [updatedTrend] = await db.update(trends)
      .set(trendUpdate)
      .where(eq(trends.id, id))
      .returning();
    return updatedTrend;
  }

  async deleteTrend(id: number): Promise<boolean> {
    const result = await db.delete(trends).where(eq(trends.id, id));
    return !!result;
  }

  async getPosts(limit?: number): Promise<Post[]> {
    // Selecionar todas as colunas exceto references, para compatibilidade
    let query = db.select({
      id: posts.id,
      title: posts.title,
      content: posts.content,
      metaDescription: posts.metaDescription,
      keywords: posts.keywords,
      imageUrl: posts.imageUrl,
      trendId: posts.trendId,
      status: posts.status,
      category: posts.category,
      createdAt: posts.createdAt,
      wordCount: posts.wordCount,
      // references não é incluído para manter compatibilidade com posts existentes
    }).from(posts).orderBy(desc(posts.createdAt));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    const results = await query;
    
    // Adicionar a propriedade references como um array vazio para cada post
    return results.map(post => ({
      ...post,
      references: [] // Valor padrão para posts existentes
    }));
  }

  async getPost(id: number): Promise<Post | undefined> {
    // Selecionar todas as colunas exceto references, para compatibilidade
    const [post] = await db.select({
      id: posts.id,
      title: posts.title,
      content: posts.content,
      metaDescription: posts.metaDescription,
      keywords: posts.keywords,
      imageUrl: posts.imageUrl,
      trendId: posts.trendId,
      status: posts.status,
      category: posts.category,
      createdAt: posts.createdAt,
      wordCount: posts.wordCount,
      // references não é incluído para manter compatibilidade com posts existentes
    }).from(posts).where(eq(posts.id, id));
    
    if (!post) return undefined;
    
    // Adicionar a propriedade references como um array vazio
    return {
      ...post,
      references: [] // Valor padrão para posts existentes
    };
  }

  async getPostsByStatus(status: string, limit?: number): Promise<Post[]> {
    // Selecionar todas as colunas exceto references, para compatibilidade
    let query = db.select({
      id: posts.id,
      title: posts.title,
      content: posts.content,
      metaDescription: posts.metaDescription,
      keywords: posts.keywords,
      imageUrl: posts.imageUrl,
      trendId: posts.trendId,
      status: posts.status,
      category: posts.category,
      createdAt: posts.createdAt,
      wordCount: posts.wordCount,
      // references não é incluído para manter compatibilidade com posts existentes
    })
      .from(posts)
      .where(eq(posts.status, status))
      .orderBy(desc(posts.createdAt));
    
    if (limit) {
      query = query.limit(limit);
    }
    
    const results = await query;
    
    // Adicionar a propriedade references como um array vazio para cada post
    return results.map(post => ({
      ...post,
      references: [] // Valor padrão para posts existentes
    }));
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const [post] = await db.insert(posts).values({
      ...insertPost,
      createdAt: new Date()
    }).returning();
    return post;
  }

  async updatePost(id: number, postUpdate: Partial<InsertPost>): Promise<Post | undefined> {
    const [updatedPost] = await db.update(posts)
      .set(postUpdate)
      .where(eq(posts.id, id))
      .returning();
    return updatedPost;
  }

  async deletePost(id: number): Promise<boolean> {
    const result = await db.delete(posts).where(eq(posts.id, id));
    return !!result;
  }

  async getSchedules(): Promise<Schedule[]> {
    return await db.select().from(schedules);
  }

  async getSchedule(id: number): Promise<Schedule | undefined> {
    const [schedule] = await db.select().from(schedules).where(eq(schedules.id, id));
    return schedule;
  }

  async getActiveSchedules(): Promise<Schedule[]> {
    return await db.select().from(schedules).where(eq(schedules.active, true));
  }

  async createSchedule(insertSchedule: InsertSchedule): Promise<Schedule> {
    const [schedule] = await db.insert(schedules).values({
      ...insertSchedule,
      createdAt: new Date(),
      nextRun: this.calculateNextRunDate(insertSchedule.frequency)
    }).returning();
    return schedule;
  }

  async updateSchedule(id: number, scheduleUpdate: Partial<InsertSchedule>): Promise<Schedule | undefined> {
    // If frequency changed, update next run
    const updateData = { ...scheduleUpdate };
    
    if (scheduleUpdate.frequency) {
      const [existingSchedule] = await db.select().from(schedules).where(eq(schedules.id, id));
      if (existingSchedule && scheduleUpdate.frequency !== existingSchedule.frequency) {
        updateData.nextRun = this.calculateNextRunDate(scheduleUpdate.frequency);
      }
    }
    
    const [updatedSchedule] = await db.update(schedules)
      .set(updateData)
      .where(eq(schedules.id, id))
      .returning();
    return updatedSchedule;
  }

  async updateScheduleRunInfo(id: number, lastRun: Date, nextRun: Date): Promise<Schedule | undefined> {
    const [updatedSchedule] = await db.update(schedules)
      .set({ lastRun, nextRun })
      .where(eq(schedules.id, id))
      .returning();
    return updatedSchedule;
  }

  async deleteSchedule(id: number): Promise<boolean> {
    const result = await db.delete(schedules).where(eq(schedules.id, id));
    return !!result;
  }

  async getApiKeys(): Promise<ApiKey[]> {
    return await db.select().from(apiKeys);
  }

  async getApiKeyByService(service: string): Promise<ApiKey | undefined> {
    try {
      const [apiKey] = await db.select().from(apiKeys).where(eq(apiKeys.service, service));
      return apiKey;
    } catch (error) {
      console.error(`Error getting API key for service ${service}:`, error);
      
      // Fallback para ambientes onde o banco de dados pode estar temporariamente indisponível
      // Lê diretamente das variáveis de ambiente como fallback
      if (service === "openai" && process.env.OPENAI_API_KEY) {
        return {
          id: 0, // ID temporário
          service: "openai",
          key: process.env.OPENAI_API_KEY,
          isActive: true,
          createdAt: new Date()
        };
      } else if (service === "google_search" && process.env.GOOGLE_SEARCH_API_KEY) {
        return {
          id: 0, // ID temporário
          service: "google_search",
          key: process.env.GOOGLE_SEARCH_API_KEY,
          isActive: true,
          createdAt: new Date()
        };
      }
      
      return undefined;
    }
  }

  async createApiKey(insertApiKey: InsertApiKey): Promise<ApiKey> {
    const [apiKey] = await db.insert(apiKeys).values({
      ...insertApiKey,
      createdAt: new Date()
    }).returning();
    return apiKey;
  }

  async updateApiKey(id: number, apiKeyUpdate: Partial<InsertApiKey>): Promise<ApiKey | undefined> {
    const [updatedApiKey] = await db.update(apiKeys)
      .set(apiKeyUpdate)
      .where(eq(apiKeys.id, id))
      .returning();
    return updatedApiKey;
  }

  async deleteApiKey(id: number): Promise<boolean> {
    const result = await db.delete(apiKeys).where(eq(apiKeys.id, id));
    return !!result;
  }

  async getMetrics(): Promise<{
    totalPosts: number;
    publishedPosts: number;
    processTrends: number;
    activeSchedules: number;
  }> {
    try {
      // Execute SQL simples para obter métricas
      const totalPostsResult = await pool.query('SELECT COUNT(*) FROM posts');
      const totalPosts = parseInt(totalPostsResult.rows[0].count, 10);
      
      const publishedPostsResult = await pool.query('SELECT COUNT(*) FROM posts WHERE status = $1', ['published']);
      const publishedPosts = parseInt(publishedPostsResult.rows[0].count, 10);
      
      const trendCountResult = await pool.query('SELECT COUNT(*) FROM trends');
      const processTrends = parseInt(trendCountResult.rows[0].count, 10);
      
      const activeSchedulesResult = await pool.query('SELECT COUNT(*) FROM schedules WHERE active = true');
      const activeSchedules = parseInt(activeSchedulesResult.rows[0].count, 10);
      
      return {
        totalPosts,
        publishedPosts,
        processTrends,
        activeSchedules
      };
    } catch (error) {
      console.error("Error getting metrics:", error);
      // Return zeros when database queries fail
      return {
        totalPosts: 0,
        publishedPosts: 0,
        processTrends: 0,
        activeSchedules: 0
      };
    }
  }

  private calculateNextRunDate(frequency: string): Date {
    const nextRun = new Date();
    
    switch (frequency) {
      case 'hourly':
        nextRun.setHours(nextRun.getHours() + 1);
        break;
      case 'daily':
        nextRun.setDate(nextRun.getDate() + 1);
        nextRun.setHours(9, 0, 0, 0); // 9 AM
        break;
      case 'weekly':
        nextRun.setDate(nextRun.getDate() + 7);
        nextRun.setHours(9, 0, 0, 0); // 9 AM
        break;
      case 'monthly':
        nextRun.setMonth(nextRun.getMonth() + 1);
        nextRun.setDate(1);
        nextRun.setHours(9, 0, 0, 0); // 9 AM on 1st
        break;
      default:
        nextRun.setDate(nextRun.getDate() + 1);
    }
    
    return nextRun;
  }
  // Visitor methods
  async getVisitors(): Promise<Visitor[]> {
    return await db.select().from(visitors).orderBy(desc(visitors.lastLogin));
  }

  async getVisitorById(id: number): Promise<Visitor | undefined> {
    const [visitor] = await db.select().from(visitors).where(eq(visitors.id, id));
    return visitor;
  }

  async getVisitorByGoogleId(googleId: string): Promise<Visitor | undefined> {
    const [visitor] = await db.select().from(visitors).where(eq(visitors.googleId, googleId));
    return visitor;
  }
  
  async getVisitorByEmail(email: string): Promise<Visitor | undefined> {
    const [visitor] = await db.select().from(visitors).where(eq(visitors.email, email));
    return visitor;
  }
  
  async getVisitorByCPF(cpf: string): Promise<Visitor | undefined> {
    const [visitor] = await db.select().from(visitors).where(eq(visitors.cpf, cpf));
    return visitor;
  }
  
  async getVisitorByResetToken(token: string): Promise<Visitor | undefined> {
    const [visitor] = await db.select().from(visitors).where(eq(visitors.resetPasswordToken, token));
    return visitor;
  }

  async createVisitor(insertVisitor: InsertVisitor): Promise<Visitor> {
    const [visitor] = await db.insert(visitors).values({
      ...insertVisitor,
      lastLogin: new Date(),
      loginCount: 1,
      createdAt: new Date()
    }).returning();
    return visitor;
  }

  async updateVisitor(id: number, visitorUpdate: Partial<InsertVisitor>): Promise<Visitor | undefined> {
    const [updatedVisitor] = await db.update(visitors)
      .set(visitorUpdate)
      .where(eq(visitors.id, id))
      .returning();
    return updatedVisitor;
  }

  async updateVisitorLoginInfo(id: number): Promise<Visitor | undefined> {
    const [visitor] = await db.select().from(visitors).where(eq(visitors.id, id));
    if (!visitor) return undefined;

    const [updatedVisitor] = await db.update(visitors)
      .set({
        lastLogin: new Date(),
        loginCount: (visitor.loginCount || 0) + 1
      })
      .where(eq(visitors.id, id))
      .returning();
    
    return updatedVisitor;
  }

  async deleteVisitor(id: number): Promise<boolean> {
    const result = await db.delete(visitors).where(eq(visitors.id, id));
    return !!result;
  }
  
  // Pageview methods
  async getPageviews(): Promise<Pageview[]> {
    return await db.select().from(pageviews).orderBy(desc(pageviews.count));
  }

  async getPageview(path: string): Promise<Pageview | undefined> {
    const [pageview] = await db.select().from(pageviews).where(eq(pageviews.path, path));
    return pageview;
  }

  async incrementPageview(path: string, ipAddress: string, userAgent?: string): Promise<Pageview> {
    // Primeiro, verifica se já existe um registro para este caminho
    const existingPageview = await this.getPageview(path);
    
    if (existingPageview) {
      // Verifica se é um visitante único (primeiro acesso deste IP nesta página)
      const isUnique = await this.isUniqueVisitor(existingPageview.id, ipAddress);
      
      // Se existir, incrementa o contador e atualiza a última visita
      const [updatedPageview] = await db.update(pageviews)
        .set({
          count: existingPageview.count + 1,
          uniqueCount: isUnique ? existingPageview.uniqueCount + 1 : existingPageview.uniqueCount,
          lastVisit: new Date()
        })
        .where(eq(pageviews.id, existingPageview.id))
        .returning();
      
      // Se for um visitante único, registra o IP
      if (isUnique) {
        await this.addUniqueVisitor(existingPageview.id, ipAddress, userAgent);
      }
      
      return updatedPageview;
    } else {
      // Se não existir, cria um novo registro
      const [newPageview] = await db.insert(pageviews)
        .values({
          path,
          count: 1,
          uniqueCount: 1, // O primeiro visitante é único
          lastVisit: new Date(),
          createdAt: new Date()
        })
        .returning();
      
      // Registra o primeiro visitante único
      await this.addUniqueVisitor(newPageview.id, ipAddress, userAgent);
      
      return newPageview;
    }
  }
  
  // Métodos para visitantes únicos
  async getUniqueVisitors(pageviewId: number): Promise<UniqueVisitor[]> {
    return await db.select()
      .from(uniqueVisitors)
      .where(eq(uniqueVisitors.pageviewId, pageviewId))
      .orderBy(desc(uniqueVisitors.visitDate));
  }
  
  async getAllUniqueVisitors(): Promise<UniqueVisitor[]> {
    return await db.select()
      .from(uniqueVisitors)
      .orderBy(desc(uniqueVisitors.visitDate));
  }
  
  async isUniqueVisitor(pageviewId: number, ipAddress: string): Promise<boolean> {
    const result = await db.select()
      .from(uniqueVisitors)
      .where(eq(uniqueVisitors.pageviewId, pageviewId))
      .where(eq(uniqueVisitors.ipAddress, ipAddress));
    
    return result.length === 0; // Retorna verdadeiro se não existirem visitantes
  }
  
  async addUniqueVisitor(pageviewId: number, ipAddress: string, userAgent?: string): Promise<UniqueVisitor> {
    const [uniqueVisitor] = await db.insert(uniqueVisitors)
      .values({
        pageviewId,
        ipAddress,
        userAgent: userAgent || null,
        visitDate: new Date()
      })
      .returning();
    
    return uniqueVisitor;
  }
}

export const storage = new DatabaseStorage();
