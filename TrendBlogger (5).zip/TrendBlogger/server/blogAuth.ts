import { Express, Request, Response } from "express";
import { storage } from "./storage";
import { insertVisitorSchema } from "@shared/schema";
import { randomBytes, scrypt, timingSafeEqual } from "crypto";
import { promisify } from "util";
import session from "express-session";

const scryptAsync = promisify(scrypt);

// Função para gerar hash de senha
export async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// Função para comparar senhas
async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

// Função para formatar CPF (adiciona pontos e traço)
function formatCPF(cpf: string): string {
  // Remove qualquer caractere não numérico
  const digits = cpf.replace(/\D/g, '');
  
  // Verifica se tem 11 dígitos
  if (digits.length !== 11) {
    return digits; // Retorna como está se não tiver 11 dígitos
  }
  
  // Formata com pontos e traço: XXX.XXX.XXX-XX
  return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9, 11)}`;
}

// Função para validar CPF
function isValidCPF(cpf: string): boolean {
  // Remove qualquer caractere não numérico
  const digits = cpf.replace(/\D/g, '');
  
  // Verifica se tem 11 dígitos
  if (digits.length !== 11) {
    return false;
  }
  
  // Verifica se todos os dígitos são iguais (caso inválido)
  if (/^(\d)\1+$/.test(digits)) {
    return false;
  }
  
  // Algoritmo de validação do CPF
  let sum = 0;
  let remainder;
  
  // Primeiro dígito verificador
  for (let i = 1; i <= 9; i++) {
    sum += parseInt(digits.substring(i - 1, i)) * (11 - i);
  }
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) {
    remainder = 0;
  }
  if (remainder !== parseInt(digits.substring(9, 10))) {
    return false;
  }
  
  // Segundo dígito verificador
  sum = 0;
  for (let i = 1; i <= 10; i++) {
    sum += parseInt(digits.substring(i - 1, i)) * (12 - i);
  }
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) {
    remainder = 0;
  }
  if (remainder !== parseInt(digits.substring(10, 11))) {
    return false;
  }
  
  return true;
}

// Função para validar data no formato DD/MM/AAAA
function isValidDate(date: string): boolean {
  // Verifica o formato básico
  if (!/^\d{2}\/\d{2}\/\d{4}$/.test(date)) {
    return false;
  }
  
  // Extrai os componentes da data
  const [day, month, year] = date.split('/').map(Number);
  
  // Cria uma data com os valores fornecidos
  const dateObj = new Date(year, month - 1, day);
  
  // Verifica se a data é válida
  return (
    dateObj.getDate() === day &&
    dateObj.getMonth() === month - 1 &&
    dateObj.getFullYear() === year
  );
}

// Configuração da autenticação do blog
export function setupBlogAuth(app: Express) {
  // Configuração do session para visitantes do blog
  const sessionOptions: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || 'blog-session-secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 30 * 24 * 60 * 60 * 1000, // 30 dias
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true
    },
    name: 'blog.sid'
  };
  
  // Middleware de sessão para o blog
  const blogSession = session(sessionOptions);
  
  // Rota para registro de visitantes
  app.post("/api/blog/register", async (req: Request, res: Response) => {
    try {
      const { email, name, password, cpf, birthDate } = req.body;
      
      // Valida os dados
      if (!email || !name || !password || !cpf || !birthDate) {
        return res.status(400).json({ message: "Todos os campos são obrigatórios" });
      }
      
      // Valida o CPF
      const formattedCPF = formatCPF(cpf);
      if (!isValidCPF(formattedCPF)) {
        return res.status(400).json({ message: "CPF inválido" });
      }
      
      // Valida a data de nascimento
      if (!isValidDate(birthDate)) {
        return res.status(400).json({ message: "Data de nascimento inválida" });
      }
      
      // Verifica se o email já está em uso
      const existingVisitorByEmail = await storage.getVisitorByEmail(email);
      if (existingVisitorByEmail) {
        return res.status(400).json({ message: "Este email já está em uso" });
      }
      
      // Verifica se o CPF já está em uso
      const existingVisitorByCPF = await storage.getVisitorByCPF(formattedCPF);
      if (existingVisitorByCPF) {
        return res.status(400).json({ message: "Este CPF já está cadastrado" });
      }
      
      // Validação com o schema de inserção
      const validatedData = insertVisitorSchema.parse({
        email,
        name,
        password: await hashPassword(password),
        cpf: formattedCPF,
        birthDate
      });
      
      // Cria o visitante
      const visitor = await storage.createVisitor(validatedData);
      
      // Inicia a sessão
      req.session.visitorId = visitor.id;
      
      // Responde com sucesso
      return res.status(201).json({ 
        message: "Cadastro realizado com sucesso", 
        visitor: {
          id: visitor.id,
          name: visitor.name,
          email: visitor.email,
          photoUrl: visitor.photoUrl,
          lastLogin: visitor.lastLogin,
          loginCount: visitor.loginCount,
          cpf: visitor.cpf,
          birthDate: visitor.birthDate
        } 
      });
    } catch (error) {
      console.error("Erro no registro de visitante:", error);
      return res.status(500).json({ message: "Erro ao processar o cadastro" });
    }
  });
  
  // Rota para login de visitantes
  app.post("/api/blog/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      
      // Valida os dados
      if (!email || !password) {
        return res.status(400).json({ message: "Email e senha são obrigatórios" });
      }
      
      // Busca o visitante pelo email
      const visitor = await storage.getVisitorByEmail(email);
      if (!visitor) {
        return res.status(401).json({ message: "Email ou senha incorretos" });
      }
      
      // Verifica a senha
      if (!visitor.password || !(await comparePasswords(password, visitor.password))) {
        return res.status(401).json({ message: "Email ou senha incorretos" });
      }
      
      // Atualiza informações de login
      const updatedVisitor = await storage.updateVisitorLoginInfo(visitor.id);
      
      // Inicia a sessão
      req.session.visitorId = visitor.id;
      
      // Responde com sucesso
      return res.status(200).json({ 
        message: "Login realizado com sucesso", 
        visitor: {
          id: updatedVisitor!.id,
          name: updatedVisitor!.name,
          email: updatedVisitor!.email,
          photoUrl: updatedVisitor!.photoUrl,
          lastLogin: updatedVisitor!.lastLogin,
          loginCount: updatedVisitor!.loginCount,
          cpf: updatedVisitor!.cpf,
          birthDate: updatedVisitor!.birthDate
        } 
      });
    } catch (error) {
      console.error("Erro no login de visitante:", error);
      return res.status(500).json({ message: "Erro ao processar o login" });
    }
  });
  
  // Rota para logout de visitantes
  app.post("/api/blog/logout", (req: Request, res: Response) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Erro ao fazer logout" });
      }
      res.clearCookie('blog.sid');
      return res.status(200).json({ message: "Logout realizado com sucesso" });
    });
  });
  
  // Rota para solicitar redefinição de senha
  app.post("/api/blog/reset-request", async (req: Request, res: Response) => {
    try {
      const { cpf, birthDate } = req.body;
      
      // Valida os dados
      if (!cpf || !birthDate) {
        return res.status(400).json({ message: "CPF e data de nascimento são obrigatórios" });
      }
      
      // Valida o CPF
      const formattedCPF = formatCPF(cpf);
      if (!isValidCPF(formattedCPF)) {
        return res.status(400).json({ message: "CPF inválido" });
      }
      
      // Valida a data de nascimento
      if (!isValidDate(birthDate)) {
        return res.status(400).json({ message: "Data de nascimento inválida" });
      }
      
      // Busca o visitante pelo CPF
      const visitor = await storage.getVisitorByCPF(formattedCPF);
      if (!visitor) {
        return res.status(404).json({ message: "Visitante não encontrado" });
      }
      
      // Verifica se a data de nascimento corresponde
      if (visitor.birthDate !== birthDate) {
        return res.status(401).json({ message: "Dados de verificação incorretos" });
      }
      
      // Gera um token de reset e define a expiração (1 hora)
      const resetToken = randomBytes(20).toString('hex');
      const resetExpires = new Date(Date.now() + 3600000); // 1 hora
      
      // Atualiza o visitor com o token
      await storage.updateVisitor(visitor.id, {
        resetPasswordToken: resetToken,
        resetPasswordExpires: resetExpires
      });
      
      // Responde com sucesso e retorna o token
      return res.status(200).json({ 
        message: "Verificação realizada com sucesso", 
        token: resetToken 
      });
    } catch (error) {
      console.error("Erro na solicitação de reset de senha:", error);
      return res.status(500).json({ message: "Erro ao processar a solicitação" });
    }
  });
  
  // Rota para redefinir a senha
  app.post("/api/blog/reset-password", async (req: Request, res: Response) => {
    try {
      const { token, password } = req.body;
      
      // Valida os dados
      if (!token || !password) {
        return res.status(400).json({ message: "Token e nova senha são obrigatórios" });
      }
      
      // Busca o visitante pelo token
      const visitor = await storage.getVisitorByResetToken(token);
      if (!visitor) {
        return res.status(400).json({ message: "Token inválido ou expirado" });
      }
      
      // Verifica se o token ainda é válido
      if (!visitor.resetPasswordExpires || new Date() > new Date(visitor.resetPasswordExpires)) {
        // Limpa o token expirado
        await storage.updateVisitor(visitor.id, {
          resetPasswordToken: null,
          resetPasswordExpires: null
        });
        return res.status(400).json({ message: "Token expirado. Solicite novamente." });
      }
      
      // Atualiza a senha e limpa o token
      await storage.updateVisitor(visitor.id, {
        password: await hashPassword(password),
        resetPasswordToken: null,
        resetPasswordExpires: null
      });
      
      // Responde com sucesso
      return res.status(200).json({ message: "Senha atualizada com sucesso" });
    } catch (error) {
      console.error("Erro na redefinição de senha:", error);
      return res.status(500).json({ message: "Erro ao redefinir a senha" });
    }
  });
  
  // Rota para obter o visitante atual
  app.get("/api/blog/visitor", (req: Request, res: Response) => {
    const visitorId = req.session.visitorId;
    
    if (!visitorId) {
      return res.status(401).json({ message: "Não autenticado" });
    }
    
    storage.getVisitorById(visitorId)
      .then((visitor) => {
        if (!visitor) {
          // Limpa a sessão inválida
          req.session.destroy((err) => {
            res.clearCookie('blog.sid');
            return res.status(401).json({ message: "Visitante não encontrado" });
          });
          return;
        }
        
        // Retorna os dados do visitante
        return res.status(200).json({
          id: visitor.id,
          name: visitor.name,
          email: visitor.email,
          photoUrl: visitor.photoUrl,
          lastLogin: visitor.lastLogin,
          loginCount: visitor.loginCount,
          cpf: visitor.cpf,
          birthDate: visitor.birthDate
        });
      })
      .catch((error) => {
        console.error("Erro ao buscar visitante:", error);
        return res.status(500).json({ message: "Erro ao buscar dados do visitante" });
      });
  });
  
  // Intercepta todas as requisições /api/blog/
  app.use('/api/blog', blogSession);
}