import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { updateTrendsDatabase } from "./lib/googleTrends";
import { generateBlogPost, GeneratePostOptions } from "./lib/openai";
import { searchImages } from "./lib/imageSearch";
import { initScheduler } from "./lib/scheduler";
import { setupAuth, hashPassword } from "./auth";
import { setupBlogAuth } from "./blogAuth";
import { fetchGoogleNews, fetchMultipleNewsTopics } from "./lib/googleNews";
import { 
  insertTrendSchema, 
  insertPostSchema, 
  insertScheduleSchema,
  insertApiKeySchema,
  Post
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Configurar autenticação
  setupAuth(app);
  
  // Configurar autenticação do blog
  setupBlogAuth(app);
  
  // Initialize scheduler
  initScheduler();

  // API routes
  // All routes are prefixed with /api
  
  // News routes
  
  // Trends routes
  app.get("/api/trends", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Acesso não autorizado" });
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const searchTerm = req.query.search as string | undefined;
      
      let trends = await storage.getTrends(limit);
      
      // Se tiver um termo de busca, filtra os resultados
      if (searchTerm && searchTerm.trim() !== '') {
        const lowerSearchTerm = searchTerm.toLowerCase();
        trends = trends.filter(trend => 
          trend.title.toLowerCase().includes(lowerSearchTerm)
        );
        
        console.log(`Filtrando tendências pelo termo: "${searchTerm}" - Encontradas: ${trends.length}`);
      }
      
      res.json(trends);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/trends/update", async (req: Request, res: Response) => {
    try {
      const { startDate, endDate, searchMode, searchPeriod } = req.body;
      // Verifica se o modo de busca é válido
      const mode = searchMode === 'news' ? 'news' : 'trends';
      
      // Se tiver período de dias especificado, calcula as datas com base nesse período
      let startDateValue = startDate;
      let endDateValue = endDate;
      
      if (searchPeriod && Number.isInteger(Number(searchPeriod)) && Number(searchPeriod) > 0) {
        const period = Number(searchPeriod);
        const end = new Date();
        const start = new Date(end.getTime() - (period * 24 * 60 * 60 * 1000));
        
        console.log(`Usando período de ${period} dias para busca de ${mode === 'news' ? 'notícias' : 'tendências'}`);
        
        startDateValue = start.toISOString();
        endDateValue = end.toISOString();
      }
      
      await updateTrendsDatabase(startDateValue, endDateValue, mode);
      const trends = await storage.getTrends();
      res.json(trends);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/trends", async (req: Request, res: Response) => {
    try {
      const trendData = insertTrendSchema.parse(req.body);
      const trend = await storage.createTrend(trendData);
      res.status(201).json(trend);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });
  
  // News routes
  app.get("/api/news", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Acesso não autorizado" });
    try {
      const query = req.query.query as string || 'brasil';
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      
      // Parâmetros de data opcionais
      let dateStart: Date | undefined;
      let dateEnd: Date | undefined;
      
      if (req.query.dateStart) {
        dateStart = new Date(req.query.dateStart as string);
      }
      
      if (req.query.dateEnd) {
        dateEnd = new Date(req.query.dateEnd as string);
      }
      
      // Se houver um período especificado em dias, calcular as datas com base nele
      if (req.query.period && !isNaN(Number(req.query.period))) {
        const periodDays = Number(req.query.period);
        dateEnd = new Date(); // Agora
        dateStart = new Date(dateEnd.getTime() - (periodDays * 24 * 60 * 60 * 1000));
      }
      
      console.log(`Buscando notícias para: "${query}"`);
      if (dateStart && dateEnd) {
        console.log(`Período: ${dateStart.toLocaleDateString()} a ${dateEnd.toLocaleDateString()}`);
      }
      
      const news = await fetchGoogleNews(query, dateStart, dateEnd, limit);
      res.json(news);
    } catch (error: any) {
      console.error("Erro ao buscar notícias:", error);
      res.status(500).json({ error: error.message });
    }
  });
  
  app.get("/api/news/multi", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Acesso não autorizado" });
    try {
      // Espera uma string de termos separados por vírgula
      const queriesString = req.query.queries as string || 'brasil';
      const queries = queriesString.split(',').map(q => q.trim());
      
      // Limita a quantidade de notícias por termo
      const limitPerQuery = req.query.limitPerQuery ? parseInt(req.query.limitPerQuery as string) : 5;
      
      // Parâmetros de data opcionais
      let dateStart: Date | undefined;
      let dateEnd: Date | undefined;
      
      if (req.query.dateStart) {
        dateStart = new Date(req.query.dateStart as string);
      }
      
      if (req.query.dateEnd) {
        dateEnd = new Date(req.query.dateEnd as string);
      }
      
      // Se houver um período especificado em dias, calcular as datas com base nele
      if (req.query.period && !isNaN(Number(req.query.period))) {
        const periodDays = Number(req.query.period);
        dateEnd = new Date(); // Agora
        dateStart = new Date(dateEnd.getTime() - (periodDays * 24 * 60 * 60 * 1000));
      }
      
      console.log(`Buscando notícias para os termos: ${queries.join(', ')}`);
      
      const results = await fetchMultipleNewsTopics(queries, dateStart, dateEnd, limitPerQuery);
      res.json(results);
    } catch (error: any) {
      console.error("Erro ao buscar múltiplas notícias:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Posts routes
  app.get("/api/posts", async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const status = req.query.status as string | undefined;
      
      let posts: Post[] = [];
      if (status) {
        console.log(`Buscando posts com status: ${status}`);
        posts = await storage.getPostsByStatus(status, limit);
        console.log(`Encontrados ${posts.length} posts com status ${status}`);
      } else {
        posts = await storage.getPosts(limit);
      }
      
      // Garantir que sempre retornamos um array
      if (!Array.isArray(posts)) {
        console.error("Posts não é um array:", posts);
        posts = [];
      }
      
      // Verifica e corrige URLs de imagens do Unsplash incompletas
      for (const post of posts) {
        if (post.imageUrl && post.imageUrl.includes('images.unsplash.com') && !post.imageUrl.includes('?')) {
          // Adiciona os parâmetros necessários à URL da imagem
          post.imageUrl = `${post.imageUrl}?q=85&w=1200&auto=format&fit=crop`;
          
          // Atualiza o post no banco de dados
          await storage.updatePost(post.id, { imageUrl: post.imageUrl });
        }
      }
      
      res.json(posts);
    } catch (error: any) {
      console.error("Erro ao buscar posts:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/posts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const post = await storage.getPost(id);
      
      if (!post) {
        return res.status(404).json({ error: "Post not found" });
      }
      
      // Corrige a URL da imagem se necessário
      if (post.imageUrl && post.imageUrl.includes('images.unsplash.com') && !post.imageUrl.includes('?')) {
        // Adiciona os parâmetros necessários se a URL do Unsplash estiver incompleta
        post.imageUrl = `${post.imageUrl}?q=85&w=1200&auto=format&fit=crop`;
        
        // Atualiza o post no banco de dados
        await storage.updatePost(post.id, { imageUrl: post.imageUrl });
      }
      
      res.json(post);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/posts", async (req: Request, res: Response) => {
    try {
      const postData = insertPostSchema.parse(req.body);
      const post = await storage.createPost(postData);
      res.status(201).json(post);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/posts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const postData = req.body;
      const post = await storage.updatePost(id, postData);
      
      if (!post) {
        return res.status(404).json({ error: "Post not found" });
      }
      
      res.json(post);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/posts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deletePost(id);
      
      if (!success) {
        return res.status(404).json({ error: "Post not found" });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Generate post route
  app.post("/api/generate", async (req: Request, res: Response) => {
    try {
      const generatePostSchema = z.object({
        trend: z.string(),
        contentType: z.string().default("Article"),
        seoOptimization: z.boolean().default(true),
        useRelatedKeywords: z.boolean().default(true),
        addMetaDescription: z.boolean().default(true),
        findRelevantImage: z.boolean().default(true),
        useRecentNews: z.boolean().default(true),
        wordCount: z.string().default("medium"),
        postAction: z.string().default("draft")
      });
      
      const options = generatePostSchema.parse(req.body);
      
      // Generate blog post
      const generatedPost = await generateBlogPost({
        trend: options.trend,
        contentType: options.contentType,
        seoOptimization: options.seoOptimization,
        useRelatedKeywords: options.useRelatedKeywords,
        addMetaDescription: options.addMetaDescription,
        useRecentNews: options.useRecentNews,
        wordCount: options.wordCount
      });
      
      // Find relevant image if enabled
      let imageUrl = null;
      if (options.findRelevantImage) {
        // Usar palavras-chave do post para encontrar imagens mais relevantes
        if (generatedPost.keywords && generatedPost.keywords.length > 0) {
          imageUrl = await searchImages(options.trend, generatedPost.keywords);
        } else {
          imageUrl = await searchImages(options.trend);
        }
      }
      
      // Determine post status based on postAction
      let status = "draft";
      if (options.postAction === "publish") {
        status = "published";
      }
      
      // Log da categoria identificada
      console.log("Categoria identificada para o post:", generatedPost.category || "não definida");
      
      // Adicionar a keyword da categoria às keywords do post
      if (generatedPost.category && !generatedPost.keywords.includes(generatedPost.category)) {
        generatedPost.keywords.push(generatedPost.category);
      }
      
      // Create post in storage
      const post = await storage.createPost({
        title: generatedPost.title,
        content: generatedPost.content,
        metaDescription: generatedPost.metaDescription,
        keywords: generatedPost.keywords,
        imageUrl: imageUrl || undefined,
        status,
        wordCount: generatedPost.wordCount,
        category: generatedPost.category || "geral", // Adicionando a categoria explícita
        references: generatedPost.references || [] // Adicionando as referências (links externos)
      });
      
      res.json(post);
    } catch (error: any) {
      console.error("Generate post error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Schedule routes
  app.get("/api/schedules", async (req: Request, res: Response) => {
    try {
      const schedules = await storage.getSchedules();
      res.json(schedules);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/schedules", async (req: Request, res: Response) => {
    try {
      const scheduleData = insertScheduleSchema.parse(req.body);
      const schedule = await storage.createSchedule(scheduleData);
      res.status(201).json(schedule);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/schedules/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const scheduleData = req.body;
      const schedule = await storage.updateSchedule(id, scheduleData);
      
      if (!schedule) {
        return res.status(404).json({ error: "Schedule not found" });
      }
      
      res.json(schedule);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/schedules/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteSchedule(id);
      
      if (!success) {
        return res.status(404).json({ error: "Schedule not found" });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // API Keys routes
  app.get("/api/settings/api-keys", async (req: Request, res: Response) => {
    try {
      const apiKeys = await storage.getApiKeys();
      res.json(apiKeys);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/settings/api-keys", async (req: Request, res: Response) => {
    try {
      const apiKeyData = insertApiKeySchema.parse(req.body);
      const apiKey = await storage.createApiKey(apiKeyData);
      res.status(201).json(apiKey);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/settings/api-keys/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const apiKeyData = req.body;
      const apiKey = await storage.updateApiKey(id, apiKeyData);
      
      if (!apiKey) {
        return res.status(404).json({ error: "API Key not found" });
      }
      
      res.json(apiKey);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Metrics route
  app.get("/api/metrics", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Acesso não autorizado" });
    try {
      const metrics = await storage.getMetrics();
      res.json(metrics);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // User management routes
  app.get("/api/users", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Acesso não autorizado" });
    try {
      const users = await storage.getUsers();
      // Remove password field for security
      const safeUsers = users.map(user => {
        const { password, ...safeUser } = user;
        return safeUser;
      });
      res.json(safeUsers);
    } catch (error: any) {
      console.error("Error fetching users:", error);
      res.status(500).json({ error: error.message });
    }
  });
  
  app.post("/api/users", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Acesso não autorizado" });
    try {
      // Verificar se o usuário atual é admin
      const currentUser = req.user as Express.User;
      if (!currentUser || currentUser.role !== 'admin') {
        return res.status(403).json({ error: "Apenas administradores podem adicionar usuários" });
      }
      
      const { username, password, name, role, active } = req.body;
      
      // Verificar se o usuário já existe
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ error: "Nome de usuário já existe" });
      }
      
      // Hash da senha
      const scrypt = await import('crypto');
      const util = await import('util');
      const scryptAsync = util.promisify(scrypt.scrypt);
      
      const salt = scrypt.randomBytes(16).toString('hex');
      const buf = (await scryptAsync(password, salt, 64)) as Buffer;
      const hashedPassword = `${buf.toString('hex')}.${salt}`;
      
      // Criar o usuário
      const user = await storage.createUser({
        username,
        password: hashedPassword,
        name,
        role: role || 'user',
        active: active !== undefined ? active : true
      });
      
      // Remover a senha antes de enviar a resposta
      const { password: _, ...safeUser } = user;
      
      res.status(201).json(safeUser);
    } catch (error: any) {
      console.error("Error creating user:", error);
      res.status(400).json({ error: error.message });
    }
  });
  
  app.patch("/api/users/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Acesso não autorizado" });
    }
    
    try {
      // Verificar se o usuário atual é admin
      const currentUser = req.user as Express.User;
      if (!currentUser || currentUser.role !== 'admin') {
        return res.status(403).json({ message: "Apenas administradores podem editar usuários" });
      }
      
      const id = parseInt(req.params.id);
      const { password, ...userData } = req.body;
      
      // Se a senha estiver sendo alterada, fazer o hash
      let updateData: any = { ...userData };
      
      if (password) {
        const { scrypt, randomBytes } = await import('crypto');
        const { promisify } = await import('util');
        const scryptAsync = promisify(scrypt);
        
        const salt = randomBytes(16).toString('hex');
        const buf = (await scryptAsync(password, salt, 64)) as Buffer;
        const hashedPassword = `${buf.toString('hex')}.${salt}`;
        
        updateData.password = hashedPassword;
      }
      
      const user = await storage.updateUser(id, updateData);
      
      if (!user) {
        return res.status(404).json({ message: "Usuário não encontrado" });
      }
      
      // Remover a senha antes de enviar a resposta
      const { password: _, ...safeUser } = user;
      
      return res.status(200).json(safeUser);
    } catch (error: any) {
      console.error("Error updating user:", error);
      return res.status(400).json({ message: error.message || "Erro ao atualizar usuário" });
    }
  });
  
  app.delete("/api/users/:id", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Acesso não autorizado" });
    try {
      // Verificar se o usuário atual é admin
      const currentUser = req.user as Express.User;
      if (!currentUser || currentUser.role !== 'admin') {
        return res.status(403).json({ error: "Apenas administradores podem excluir usuários" });
      }
      
      const id = parseInt(req.params.id);
      
      // Impedir exclusão do próprio usuário
      if (id === currentUser.id) {
        return res.status(400).json({ error: "Não é possível excluir seu próprio usuário" });
      }
      
      const success = await storage.deleteUser(id);
      
      if (!success) {
        return res.status(404).json({ error: "Usuário não encontrado" });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error("Error deleting user:", error);
      res.status(500).json({ error: error.message });
    }
  });
  
  // Rota para corrigir URLs de imagens
  app.post("/api/fix-images", async (req: Request, res: Response) => {
    try {
      // Busca todos os posts
      const posts = await storage.getPosts();
      let updatedCount = 0;
      let allCorrections: {id: number, before: string, after: string}[] = [];
      
      // URL de fallback segura caso nenhuma imagem esteja disponível
      const fallbackUrl = "https://cdn.pixabay.com/photo/2016/02/03/08/32/banner-1176676_1280.jpg";
      
      // Função de correção de URL mais robusta - similar à nova função do frontend
      const fixImageUrl = (url: string): string => {
        // Se a URL estiver vazia, retorna a fallback
        if (!url || url.trim() === '') return fallbackUrl;
        
        try {
          // Se é uma URL do Pixabay (nossa preferência)
          if (url.includes('cdn.pixabay.com')) {
            // Verifica o formato básico da URL
            const pixabayPattern = /cdn\.pixabay\.com\/photo\//;
            if (!pixabayPattern.test(url)) {
              console.warn("URL do Pixabay inválida:", url);
              return fallbackUrl;
            }
            
            // URLs do Pixabay já estão em formato correto
            return url;
          }
          
          // Se é uma URL do Unsplash (código original para compatibilidade)
          if (url.includes('images.unsplash.com')) {
            // Verifica o formato básico da URL
            const unsplashPattern = /images\.unsplash\.com\/photo-\d+/;
            if (!unsplashPattern.test(url)) {
              console.warn("URL do Unsplash inválida:", url);
              return fallbackUrl;
            }
            
            // Extrai a parte base da URL (antes dos parâmetros)
            let baseUrl = url;
            if (url.includes('?')) {
              baseUrl = url.split('?')[0];
            }
            
            // Adiciona os parâmetros necessários
            return `${baseUrl}?q=85&w=1200&auto=format&fit=crop`;
          }
          
          // Se não for uma URL conhecida mas parece ser uma URL válida
          if (url.startsWith('http')) {
            return url; // retorna como está
          }
          
          // Se chegou aqui, a URL não é reconhecível, usa fallback
          console.warn("URL não reconhecida como válida:", url);
          return fallbackUrl;
        } catch (error) {
          console.error("Erro ao processar URL de imagem:", error);
          return fallbackUrl;
        }
      };
      
      // Verifica e corrige cada post
      for (const post of posts) {
        if (post.imageUrl) {
          const fixedUrl = fixImageUrl(post.imageUrl);
          
          // Só atualiza se a URL foi modificada
          if (fixedUrl !== post.imageUrl) {
            // Atualiza o post no banco de dados
            await storage.updatePost(post.id, { imageUrl: fixedUrl });
            updatedCount++;
            console.log(`Post ${post.id} atualizado: ${post.imageUrl} -> ${fixedUrl}`);
            allCorrections.push({
              id: post.id, 
              before: post.imageUrl,
              after: fixedUrl
            });
          }
        } else if (post.id) {
          // Se o post não tem imagem, adiciona a fallback
          await storage.updatePost(post.id, { imageUrl: fallbackUrl });
          updatedCount++;
          console.log(`Post ${post.id} sem imagem recebeu fallback`);
          allCorrections.push({
            id: post.id, 
            before: "sem imagem",
            after: fallbackUrl
          });
        }
      }
      
      res.json({ 
        success: true, 
        message: `${updatedCount} posts com URLs de imagens corrigidos`,
        corrections: allCorrections
      });
    } catch (error: any) {
      console.error("Erro ao corrigir URLs de imagens:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Rotas para gestão de visitantes (autenticação Google)
  app.get("/api/visitors", async (req: Request, res: Response) => {
    try {
      // Autorização - apenas admin pode ver todos os visitantes
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Acesso não autorizado" });
      }
      
      const visitors = await storage.getVisitors();
      res.json(visitors);
    } catch (error) {
      console.error("Erro ao buscar visitantes:", error);
      res.status(500).json({ message: "Erro ao buscar visitantes" });
    }
  });
  
  app.get("/api/visitors/:id", async (req: Request, res: Response) => {
    try {
      // Autorização - apenas admin pode ver detalhes de visitantes
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Acesso não autorizado" });
      }
      
      const id = parseInt(req.params.id);
      const visitor = await storage.getVisitorById(id);
      
      if (!visitor) {
        return res.status(404).json({ message: "Visitante não encontrado" });
      }
      
      res.json(visitor);
    } catch (error) {
      console.error("Erro ao buscar visitante:", error);
      res.status(500).json({ message: "Erro ao buscar visitante" });
    }
  });
  
  app.get("/api/visitors/google/:googleId", async (req: Request, res: Response) => {
    try {
      const googleId = req.params.googleId;
      const visitor = await storage.getVisitorByGoogleId(googleId);
      
      if (!visitor) {
        return res.status(404).json({ message: "Visitante não encontrado" });
      }
      
      res.json(visitor);
    } catch (error) {
      console.error("Erro ao buscar visitante pelo googleId:", error);
      res.status(500).json({ message: "Erro ao buscar visitante" });
    }
  });
  
  app.post("/api/visitors", async (req: Request, res: Response) => {
    try {
      const { googleId, email, name, photoUrl } = req.body;
      
      // Validação básica
      if (!googleId || !email) {
        return res.status(400).json({ message: "GoogleId e email são obrigatórios" });
      }
      
      // Verificar se já existe um visitante com este googleId
      const existingVisitor = await storage.getVisitorByGoogleId(googleId);
      if (existingVisitor) {
        return res.status(400).json({ message: "Visitante já cadastrado" });
      }
      
      const visitor = await storage.createVisitor({
        googleId,
        email,
        name: name || null,
        photoUrl: photoUrl || null
      });
      
      res.status(201).json(visitor);
    } catch (error) {
      console.error("Erro ao criar visitante:", error);
      res.status(500).json({ message: "Erro ao criar visitante" });
    }
  });
  
  app.patch("/api/visitors/:id", async (req: Request, res: Response) => {
    try {
      // Autorização - apenas admin pode atualizar visitantes
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Acesso não autorizado" });
      }
      
      const id = parseInt(req.params.id);
      const updateData = req.body;
      
      // Não permitir atualização de googleId e email
      delete updateData.googleId;
      delete updateData.email;
      
      const updatedVisitor = await storage.updateVisitor(id, updateData);
      
      if (!updatedVisitor) {
        return res.status(404).json({ message: "Visitante não encontrado" });
      }
      
      res.json(updatedVisitor);
    } catch (error) {
      console.error("Erro ao atualizar visitante:", error);
      res.status(500).json({ message: "Erro ao atualizar visitante" });
    }
  });
  
  app.patch("/api/visitors/:id/login", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      const updatedVisitor = await storage.updateVisitorLoginInfo(id);
      
      if (!updatedVisitor) {
        return res.status(404).json({ message: "Visitante não encontrado" });
      }
      
      res.json(updatedVisitor);
    } catch (error) {
      console.error("Erro ao atualizar informações de login do visitante:", error);
      res.status(500).json({ message: "Erro ao atualizar informações de login" });
    }
  });
  
  app.delete("/api/visitors/:id", async (req: Request, res: Response) => {
    try {
      // Autorização - apenas admin pode excluir visitantes
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Acesso não autorizado" });
      }
      
      const id = parseInt(req.params.id);
      const success = await storage.deleteVisitor(id);
      
      if (!success) {
        return res.status(404).json({ message: "Visitante não encontrado" });
      }
      
      res.json({ message: "Visitante excluído com sucesso" });
    } catch (error) {
      console.error("Erro ao excluir visitante:", error);
      res.status(500).json({ message: "Erro ao excluir visitante" });
    }
  });
  
  // Pageviews - Contagem de visualizações de páginas
  app.get("/api/pageviews", async (req: Request, res: Response) => {
    try {
      // Autorização - apenas admin pode ver estatísticas de pageviews
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Acesso não autorizado" });
      }
      
      const pageviews = await storage.getPageviews();
      res.json(pageviews);
    } catch (error) {
      console.error("Erro ao buscar estatísticas de visualização:", error);
      res.status(500).json({ message: "Erro ao buscar estatísticas de visualização" });
    }
  });
  
  // Obter estatísticas de visitantes únicos por período (dia, mês, ano)
  app.get("/api/stats/unique-visitors", async (req: Request, res: Response) => {
    try {
      // Autorização - apenas admin pode ver estatísticas
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Acesso não autorizado" });
      }
      
      // Obter todos os visitantes únicos do banco de dados
      const uniqueVisitorsData = await storage.getAllUniqueVisitors();
      
      // Calcular estatísticas por período
      const today = new Date();
      const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      const startOfYear = new Date(today.getFullYear(), 0, 1);
      
      // Mapear IPs únicos por período
      const uniqueIpsDaily = new Set<string>();
      const uniqueIpsMonthly = new Set<string>();
      const uniqueIpsYearly = new Set<string>();
      
      uniqueVisitorsData.forEach((visitor: { visitDate: Date | string | null; ipAddress: string }) => {
        if (visitor.visitDate) {
          const visitDate = visitor.visitDate instanceof Date ? visitor.visitDate : new Date(visitor.visitDate);
          // Contagem anual
          if (visitDate >= startOfYear) {
            uniqueIpsYearly.add(visitor.ipAddress);
          }
          
          // Contagem mensal
          if (visitDate >= startOfMonth) {
            uniqueIpsMonthly.add(visitor.ipAddress);
          }
          
          // Contagem diária
          if (visitDate >= startOfDay) {
            uniqueIpsDaily.add(visitor.ipAddress);
          }
        }
      });
      
      res.json({
        daily: uniqueIpsDaily.size,
        monthly: uniqueIpsMonthly.size,
        yearly: uniqueIpsYearly.size,
        total: new Set(uniqueVisitorsData.map((v: { ipAddress: string }) => v.ipAddress)).size
      });
    } catch (error) {
      console.error("Erro ao buscar estatísticas de visitantes únicos:", error);
      res.status(500).json({ message: "Erro ao buscar estatísticas de visitantes únicos" });
    }
  });
  
  app.post("/api/pageviews", async (req: Request, res: Response) => {
    try {
      const { path } = req.body;
      
      if (!path) {
        return res.status(400).json({ message: "O caminho da página é obrigatório" });
      }

      // Captura o endereço IP do visitante
      const ipAddress = req.ip || req.socket.remoteAddress || '0.0.0.0';
      
      // Captura o user-agent do navegador
      const userAgent = req.get('User-Agent') || '';
      
      // Registra a visualização com IP e user-agent
      const pageview = await storage.incrementPageview(path, ipAddress, userAgent);
      res.json(pageview);
    } catch (error) {
      console.error("Erro ao registrar visualização da página:", error);
      res.status(500).json({ message: "Erro ao registrar visualização da página" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
