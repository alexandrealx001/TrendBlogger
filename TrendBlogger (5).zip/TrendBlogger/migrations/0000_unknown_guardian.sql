CREATE TABLE "api_keys" (
	"id" serial PRIMARY KEY NOT NULL,
	"service" text NOT NULL,
	"key" text NOT NULL,
	"is_active" boolean DEFAULT true,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "posts" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"content" text NOT NULL,
	"meta_description" text,
	"keywords" text[],
	"image_url" text,
	"trend_id" integer,
	"status" text DEFAULT 'draft',
	"created_at" timestamp DEFAULT now(),
	"word_count" integer
);
--> statement-breakpoint
CREATE TABLE "schedules" (
	"id" serial PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"frequency" text NOT NULL,
	"active" boolean DEFAULT true,
	"settings" json,
	"last_run" timestamp,
	"next_run" timestamp,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "trends" (
	"id" serial PRIMARY KEY NOT NULL,
	"title" text NOT NULL,
	"search_volume" text,
	"published_at" text,
	"rank" integer,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY NOT NULL,
	"username" text NOT NULL,
	"password" text NOT NULL,
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
