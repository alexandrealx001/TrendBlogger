# Checklist Pós-Instalação do TrendPulse

Use este checklist para verificar se tudo está funcionando corretamente após a implantação.

## 1. Verificação Inicial do Sistema

- [ ] Servidor está online e acessível via SSH
- [ ] Banco de dados PostgreSQL está em execução (`sudo systemctl status postgresql`)
- [ ] Nginx está em execução (`sudo systemctl status nginx`)
- [ ] PM2 está gerenciando o processo do TrendPulse (`pm2 status`)

## 2. Verificação da Aplicação

- [ ] O site está acessível pelo navegador (http://seu-dominio.com)
- [ ] HTTPS está funcionando corretamente (https://seu-dominio.com)
- [ ] Possível fazer login no painel administrativo
- [ ] A aplicação consegue acessar o banco de dados
- [ ] As APIs externas estão funcionando (OpenAI, Google Search)

## 3. Verificação de Funcionalidades Principais

- [ ] Geração de conteúdo está funcionando
- [ ] Agendamentos estão sendo executados
- [ ] Interface do blog está exibindo posts corretamente
- [ ] Sistema de estatísticas está registrando visualizações

## 4. Verificação de Segurança

- [ ] Firewall está ativo e configurado (`sudo ufw status`)
- [ ] Apenas portas necessárias estão abertas (22, 80, 443)
- [ ] Certificado SSL está válido e não expira em breve
- [ ] Arquivos de configuração têm permissões corretas

## 5. Monitoramento e Logs

- [ ] Logs da aplicação estão sendo gerados corretamente (`pm2 logs trendpulse`)
- [ ] Logs do Nginx estão acessíveis (`sudo tail -f /var/log/nginx/error.log`)
- [ ] Sistema de monitoramento está configurado (PM2, opcional)

## 6. Backup

- [ ] Estratégia de backup está implementada
- [ ] Primeiro backup foi executado com sucesso
- [ ] Processo de restauração testado

## 7. Configurações Específicas

- [ ] Domínio personalizado configurado no Nginx
- [ ] Variáveis de ambiente estão corretamente definidas
- [ ] Cron jobs para tarefas periódicas configurados (se necessário)

## 8. Documentação

- [ ] Senhas e credenciais armazenadas em local seguro
- [ ] Documentação da implantação arquivada para referência futura
- [ ] Procedimentos de manutenção documentados

## Solução de Problemas Comuns

### Aplicação não inicia
- Verifique os logs: `pm2 logs trendpulse`
- Verifique se as variáveis de ambiente estão corretas
- Verifique se o banco de dados está acessível

### Erros 502 Bad Gateway
- Verifique se a aplicação está rodando: `pm2 status`
- Verifique a configuração do Nginx: `sudo nginx -t`
- Reinicie o Nginx: `sudo systemctl restart nginx`

### Problemas de Banco de Dados
- Verifique se o PostgreSQL está rodando: `sudo systemctl status postgresql`
- Verifique a conexão: `psql -U trendpulse -h localhost -d trendpulse`
- Verifique as credenciais no arquivo .env