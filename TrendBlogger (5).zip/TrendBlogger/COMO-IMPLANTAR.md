# Como Implantar o TrendPulse via ZIP

Este documento explica o processo completo de implantação do TrendPulse usando um arquivo ZIP.

## 1. Preparação

### No ambiente de desenvolvimento:

1. **Edite o arquivo `.env.production`** com suas credenciais reais
   ```
   nano .env.production
   ```

2. **Torne o script de empacotamento executável**
   ```
   chmod +x criar-pacote.sh
   ```

3. **Execute o script para criar o pacote**
   ```
   ./criar-pacote.sh
   ```

4. **Baixe o arquivo ZIP gerado**
   - O arquivo `trendpulse.zip` será gerado na raiz do projeto

## 2. Implantação no Servidor

1. **Prepare o servidor** seguindo o guia `instrucoes-implantacao.md`

2. **Transfira o arquivo ZIP para o servidor**
   ```
   scp trendpulse.zip usuario@seu-servidor:/caminho/para/upload/
   ```

3. **Conecte-se ao servidor**
   ```
   ssh usuario@seu-servidor
   ```

4. **Descompacte o arquivo** no local apropriado
   ```
   mkdir -p /var/www/trendpulse
   unzip /caminho/para/upload/trendpulse.zip -d /var/www/trendpulse
   cd /var/www/trendpulse
   ```

5. **Configure as variáveis de ambiente** (se ainda não tiver feito no arquivo .env.production)
   ```
   nano .env.production
   cp .env.production .env
   ```

6. **Execute o script de inicialização**
   ```
   chmod +x start-server.sh
   ./start-server.sh
   ```

7. **Configure o Nginx**
   ```
   sudo cp nginx-trendpulse.conf /etc/nginx/sites-available/trendpulse
   sudo ln -s /etc/nginx/sites-available/trendpulse /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

8. **Configure HTTPS** (recomendado)
   ```
   sudo apt install -y certbot python3-certbot-nginx
   sudo certbot --nginx -d seu-dominio.com
   ```

## 3. Verificação

Use o arquivo `checklist-pos-instalacao.md` para verificar se tudo está funcionando corretamente.

## 4. Manutenção

### Para atualizar a aplicação:

1. Crie um novo pacote ZIP seguindo os passos da seção "Preparação"
2. Faça backup da versão atual no servidor
   ```
   cp -r /var/www/trendpulse /var/www/trendpulse_backup_$(date +%Y%m%d)
   ```
3. Transfira e descompacte a nova versão
4. Reinicie a aplicação
   ```
   pm2 restart trendpulse
   ```

### Para backup do banco de dados:

```
sudo -u postgres pg_dump trendpulse > /caminho/para/backups/trendpulse_$(date +%Y%m%d).sql
```

## 5. Solução de Problemas

Consulte a seção "Solução de Problemas Comuns" no arquivo `checklist-pos-instalacao.md`.