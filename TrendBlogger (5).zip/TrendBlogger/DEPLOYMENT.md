# Guia de Implantação do TrendPulse

Este documento fornece instruções detalhadas para implantar o TrendPulse em um ambiente de produção usando uma VPS (Virtual Private Server).

## Requisitos do Servidor

- Ubuntu 20.04 LTS ou superior
- Mínimo de 2GB de RAM (4GB recomendado)
- Mínimo de 10GB de espaço em disco
- Acesso root ou sudo

## 1. Preparando o Servidor

```bash
# Atualizar o sistema
sudo apt update && sudo apt upgrade -y

# Instalar dependências essenciais
sudo apt install -y curl git build-essential nginx software-properties-common
```

## 2. Instalando o Node.js

```bash
# Adicionar repositório NodeSource
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -

# Instalar Node.js
sudo apt install -y nodejs

# Verificar a instalação
node -v
npm -v
```

## 3. Instalando e Configurando o PostgreSQL

```bash
# Instalar PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Iniciar e habilitar o serviço
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Entrar no shell do PostgreSQL
sudo -u postgres psql

# No shell do PostgreSQL
CREATE USER trendpulse WITH PASSWORD 'sua_senha_segura';
CREATE DATABASE trendpulse;
GRANT ALL PRIVILEGES ON DATABASE trendpulse TO trendpulse;
\q
```

## 4. Configurando o Projeto

```bash
# Criar diretório para a aplicação
sudo mkdir -p /var/www/trendpulse
sudo chown -R $USER:$USER /var/www/trendpulse

# Clonar o repositório
git clone https://github.com/seu-usuario/trendpulse.git /var/www/trendpulse
cd /var/www/trendpulse

# Instalar dependências
npm install --production

# Criar arquivo de variáveis de ambiente
nano .env
```

Conteúdo do arquivo `.env`:

```
# Configuração do banco de dados
DATABASE_URL=postgres://trendpulse:sua_senha_segura@localhost:5432/trendpulse

# Configuração do servidor
PORT=5000
NODE_ENV=production

# Chaves de API
OPENAI_API_KEY=sua_chave_openai
GOOGLE_SEARCH_API_KEY=sua_chave_google_search

# Firebase (se necessário)
VITE_FIREBASE_API_KEY=sua_chave_firebase
VITE_FIREBASE_PROJECT_ID=seu_id_projeto
VITE_FIREBASE_APP_ID=seu_app_id
```

## 5. Construindo a Aplicação

```bash
# Construir o projeto para produção
npm run build
```

## 6. Configurando o PM2 para Gerenciamento de Processos

```bash
# Instalar PM2 globalmente
sudo npm install -g pm2

# Iniciar a aplicação com PM2
pm2 start dist/server/index.js --name "trendpulse"

# Configurar PM2 para iniciar automaticamente
pm2 startup
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp $HOME
pm2 save
```

## 7. Configurando o Nginx como Proxy Reverso

```bash
# Criar configuração do Nginx
sudo nano /etc/nginx/sites-available/trendpulse
```

Conteúdo do arquivo de configuração:

```nginx
server {
    listen 80;
    server_name seu-dominio.com www.seu-dominio.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    client_max_body_size 5M;
}
```

```bash
# Habilitar o site
sudo ln -s /etc/nginx/sites-available/trendpulse /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

## 8. Configurando SSL com Certbot

```bash
# Instalar Certbot
sudo apt install -y certbot python3-certbot-nginx

# Obter certificado SSL
sudo certbot --nginx -d seu-dominio.com -d www.seu-dominio.com

# Verificar renovação automática
sudo certbot renew --dry-run
```

## 9. Configurando o Firewall

```bash
# Instalar e configurar UFW
sudo apt install -y ufw
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable
```

## 10. Manutenção da Aplicação

### Atualizando o código:

```bash
cd /var/www/trendpulse
git pull
npm install --production
npm run build
pm2 restart trendpulse
```

### Backup do banco de dados:

```bash
# Criar backup
sudo -u postgres pg_dump trendpulse > /path/to/backup/trendpulse_$(date +%Y%m%d).sql

# Restaurar backup (se necessário)
sudo -u postgres psql trendpulse < backup_file.sql
```

### Monitoramento com PM2:

```bash
# Ver status dos processos
pm2 status

# Ver logs
pm2 logs trendpulse

# Monitoramento em tempo real
pm2 monit
```

## 11. Solução de Problemas

### Verificar logs do Nginx:
```bash
sudo tail -f /var/log/nginx/error.log
```

### Verificar logs da aplicação:
```bash
pm2 logs trendpulse
```

### Reiniciar serviços:
```bash
sudo systemctl restart postgresql
sudo systemctl restart nginx
pm2 restart trendpulse
```

## 12. Considerações de Segurança

- Implemente uma política de senhas fortes
- Configure backups automatizados
- Atualize regularmente o sistema e dependências
- Considere adicionar um WAF (Web Application Firewall) como ModSecurity
- Restrinja o acesso ao painel administrativo por IP, se possível