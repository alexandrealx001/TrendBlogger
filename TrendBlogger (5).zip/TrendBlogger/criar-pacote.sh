#!/bin/bash

# Script para preparar o pacote ZIP para implantação

echo "Preparando pacote de implantação do TrendPulse..."

# Criar pasta temporária para os arquivos
mkdir -p ./tmp/trendpulse

# Construir o projeto
echo "Construindo o projeto..."
npm run build

# Copiar arquivos necessários
echo "Copiando arquivos..."
cp -r ./client ./server ./shared ./migrations ./drizzle.config.ts ./package.json ./package-lock.json ./tmp/trendpulse/
cp .env.production ./tmp/trendpulse/
cp .env.example ./tmp/trendpulse/
cp start-server.sh ./tmp/trendpulse/
cp nginx-trendpulse.conf ./tmp/trendpulse/
cp instrucoes-implantacao.md ./tmp/trendpulse/
cp tsconfig.json ./tmp/trendpulse/
cp tailwind.config.ts ./tmp/trendpulse/
cp postcss.config.js ./tmp/trendpulse/
cp vite.config.ts ./tmp/trendpulse/

# Se o diretório dist existir, copiá-lo também
if [ -d "./dist" ]; then
    cp -r ./dist ./tmp/trendpulse/
fi

# Criar arquivo ZIP
echo "Criando arquivo ZIP..."
cd ./tmp
zip -r ../trendpulse.zip trendpulse

# Limpar arquivos temporários
echo "Limpando arquivos temporários..."
cd ..
rm -rf ./tmp

echo "Pacote criado com sucesso: trendpulse.zip"
echo "Este arquivo está pronto para ser transferido para sua VPS."
echo "Siga as instruções em instrucoes-implantacao.md para completar a implantação."