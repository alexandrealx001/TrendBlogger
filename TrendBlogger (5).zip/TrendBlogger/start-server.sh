#!/bin/bash

# Script de inicialização do servidor TrendPulse

# Verificar se o Node.js está instalado
if ! command -v node &> /dev/null; then
    echo "Node.js não está instalado. Por favor, instale-o primeiro."
    exit 1
fi

# Verificar se o npm está instalado
if ! command -v npm &> /dev/null; then
    echo "npm não está instalado. Por favor, instale-o primeiro."
    exit 1
fi

# Verificar se o PM2 está instalado
if ! command -v pm2 &> /dev/null; then
    echo "PM2 não está instalado. Instalando..."
    npm install -g pm2
fi

# Verificar se o arquivo .env.production existe e copiá-lo para .env
if [ -f .env.production ]; then
    echo "Usando configurações de produção..."
    cp .env.production .env
else
    echo "Arquivo .env.production não encontrado. Por favor, crie-o primeiro."
    exit 1
fi

# Instalar dependências
echo "Instalando dependências..."
npm install --production

# Construir o projeto
echo "Construindo o projeto..."
npm run build

# Iniciar o servidor com PM2
echo "Iniciando o servidor com PM2..."
pm2 start dist/server/index.js --name "trendpulse"

# Configurar PM2 para iniciar com o sistema
echo "Configurando PM2 para iniciar com o sistema..."
pm2 save

echo "Servidor TrendPulse iniciado com sucesso!"
echo "Para verificar o status: pm2 status"
echo "Para ver os logs: pm2 logs trendpulse"