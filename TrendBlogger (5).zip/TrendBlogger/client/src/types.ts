// Tipos comuns usados em toda a aplicação

export interface User {
  id: number;
  username: string;
  name?: string | null;
  role?: string | null;
  active?: boolean | null;
  createdAt?: Date | null;
}

export interface Trend {
  id: number;
  title: string;
  searchVolume?: string | null;
  publishedAt?: string | null;
  rank?: number | null;
  createdAt?: Date | null;
}

export interface Post {
  id: number;
  title: string;
  content: string;
  status?: string | null;
  metaDescription?: string | null;
  keywords: string[];
  imageUrl?: string | null;
  trendId?: number | null;
  wordCount?: number | null;
  createdAt?: Date | null;
}

export interface Schedule {
  id: number;
  name: string;
  frequency: string;
  active: boolean;
  settings: ScheduleSettings;
  lastRun?: Date | null;
  nextRun?: Date | null;
  createdAt?: Date | null;
}

export interface ScheduleSettings {
  updateTrends?: boolean;
  searchMode?: string;
  periodDays?: number;
  generatePost?: boolean;
  contentType?: string;
  seoOptimization?: boolean;
  useRelatedKeywords?: boolean;
  addMetaDescription?: boolean;
  useRecentNews?: boolean;
  findImage?: boolean;
  wordCount?: string;
  autoPublish?: boolean;
}

export interface ApiKey {
  id: number;
  service: string;
  key: string;
  isActive?: boolean | null;
  createdAt?: Date | null;
}

export interface Metrics {
  totalPosts: number;
  publishedPosts: number;
  processTrends: number;
  activeSchedules: number;
}

export interface Visitor {
  id: number;
  googleId: string;
  email: string;
  name: string | null;
  photoUrl: string | null;
  lastLogin: Date | null;
  loginCount: number | null;
  createdAt: Date | null;
}