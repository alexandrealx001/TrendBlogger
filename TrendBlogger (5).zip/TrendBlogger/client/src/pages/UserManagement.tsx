import { useEffect } from "react";
import UserManagementComponent from "@/components/users/UserManagement";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";

export default function UserManagementPage() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Verifica se o usuário é administrador
    if (!isLoading && user) {
      if (user.role !== "admin") {
        toast({
          title: "Acesso negado",
          description: "Apenas administradores podem acessar esta página",
          variant: "destructive",
        });
        setLocation("/");
      }
    }
  }, [user, isLoading, toast, setLocation]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Verificando permissões...</span>
      </div>
    );
  }

  // Se o usuário não for admin, não mostra o conteúdo
  if (!user || user.role !== "admin") {
    return null;
  }

  return (
    <div className="container py-6">
      <UserManagementComponent />
    </div>
  );
}