import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useSchedules, useDeleteSchedule } from "@/hooks/useSchedules";
import { useToast } from "@/hooks/use-toast";
import { Schedule } from "@shared/schema";
import AddScheduleModal from "@/components/scheduler/AddScheduleModal";
import EditScheduleModal from "@/components/scheduler/EditScheduleModal";
import { Plus, Edit, Trash } from "lucide-react";

export default function Scheduler() {
  const { toast } = useToast();
  const { data: schedules, isLoading } = useSchedules();
  const deleteScheduleMutation = useDeleteSchedule();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedSchedule, setSelectedSchedule] = useState<Schedule | null>(null);

  const handleAddSchedule = () => {
    setIsAddModalOpen(true);
  };

  const handleEditSchedule = (schedule: Schedule) => {
    setSelectedSchedule(schedule);
    setIsEditModalOpen(true);
  };

  const handleDeleteSchedule = async (schedule: Schedule) => {
    if (!confirm(`Tem certeza que deseja excluir o agendamento "${schedule.name}"?`)) {
      return;
    }

    try {
      await deleteScheduleMutation.mutateAsync(schedule.id);
      
      toast({
        title: "Agendamento excluído",
        description: "O agendamento foi excluído com sucesso.",
      });
    } catch (error: any) {
      toast({
        title: "Erro ao excluir agendamento",
        description: error.message || "Ocorreu um erro ao excluir o agendamento. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  const formatNextRun = (dateString: string | undefined) => {
    if (!dateString) return "Não agendado";
    
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getFrequencyText = (frequency: string) => {
    switch (frequency) {
      case "hourly":
        return "A cada hora";
      case "daily":
        return "Diariamente";
      case "weekly":
        return "Semanalmente";
      case "monthly":
        return "Mensalmente";
      default:
        return frequency;
    }
  };

  const getSettingsTasks = (settings: any) => {
    if (!settings) return [];

    const tasks = [];
    if (settings.updateTrends) {
      tasks.push("Atualizar tendências");
    }
    if (settings.generatePost) {
      tasks.push("Gerar posts");
    }
    return tasks;
  };

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-neutral-900">Agendamentos</h1>
        <Button onClick={handleAddSchedule}>
          <Plus className="h-4 w-4 mr-2" />
          Novo Agendamento
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Agendamentos</CardTitle>
          <CardDescription>
            Configure quando e com que frequência o sistema irá gerar conteúdo automaticamente.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {Array(3)
                .fill(0)
                .map((_, i) => (
                  <div key={i} className="animate-pulse p-4 border rounded-md">
                    <div className="h-6 bg-neutral-200 rounded w-1/4 mb-3"></div>
                    <div className="h-4 bg-neutral-200 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-neutral-200 rounded w-1/2"></div>
                  </div>
                ))}
            </div>
          ) : schedules && schedules.length > 0 ? (
            <div className="space-y-4">
              {schedules.map((schedule) => (
                <div key={schedule.id} className="border border-neutral-200 rounded-md p-4 hover:border-neutral-300 transition-colors">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div className="mb-4 md:mb-0">
                      <div className="flex items-center space-x-2">
                        <h3 className="text-lg font-medium text-neutral-900">{schedule.name}</h3>
                        {schedule.active ? (
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                            Ativo
                          </span>
                        ) : (
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-neutral-100 text-neutral-800">
                            Inativo
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-neutral-500 mt-1">
                        Frequência: {getFrequencyText(schedule.frequency)}
                      </p>
                      {schedule.nextRun && (
                        <p className="text-sm text-neutral-500">
                          Próxima execução: {formatNextRun(schedule.nextRun.toString())}
                        </p>
                      )}
                      <div className="flex flex-wrap gap-2 mt-2">
                        {getSettingsTasks(schedule.settings).map((task, index) => (
                          <span 
                            key={index} 
                            className="px-2 py-1 text-xs rounded-full bg-primary-100 text-primary-700"
                          >
                            {task}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleEditSchedule(schedule)}
                      >
                        <Edit className="h-4 w-4 mr-1" />
                        Editar
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-red-600 border-red-200 hover:bg-red-50"
                        onClick={() => handleDeleteSchedule(schedule)}
                        disabled={deleteScheduleMutation.isPending}
                      >
                        <Trash className="h-4 w-4 mr-1" />
                        Excluir
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-neutral-500">
              <p>Nenhum agendamento configurado.</p>
              <p className="mt-2">Crie seu primeiro agendamento para automatizar a geração de conteúdo.</p>
              <Button 
                onClick={handleAddSchedule}
                variant="outline"
                className="mt-4"
              >
                <Plus className="h-4 w-4 mr-2" />
                Criar Agendamento
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add Schedule Modal */}
      <AddScheduleModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />

      {/* Edit Schedule Modal */}
      {selectedSchedule && (
        <EditScheduleModal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          schedule={selectedSchedule}
        />
      )}
    </>
  );
}
