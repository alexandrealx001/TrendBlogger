import MetricsSection from "@/components/metrics/MetricsSection";
import QuickActions from "@/components/actions/QuickActions";
import TrendsSection from "@/components/trends/TrendsSection";
import RecentPosts from "@/components/posts/RecentPosts";

export default function Dashboard() {
  return (
    <>
      {/* Metrics Section */}
      <MetricsSection />
      
      {/* Quick Actions Section */}
      <QuickActions />
      
      {/* Trends & Recent Posts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <TrendsSection />
        <RecentPosts />
      </div>
    </>
  );
}
