import { useState } from "react";
import { usePosts } from "@/hooks/usePosts";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Post } from "@shared/schema";
import GeneratePostModal from "@/components/modals/GeneratePostModal";
import EditPostModal from "@/components/modals/EditPostModal";
import { Plus, Eye, CheckCircle, AlertCircle, Trash, FileEdit, PenTool } from "lucide-react";

// Mapeamento de categorias para cores
const getCategoryColor = (category: string): string => {
  const colorMap: Record<string, string> = {
    tecnologia: "bg-blue-100 text-blue-700",
    negocios: "bg-indigo-100 text-indigo-700",
    financas: "bg-green-100 text-green-700",
    saude: "bg-red-100 text-red-700",
    politica: "bg-purple-100 text-purple-700",
    esportes: "bg-yellow-100 text-yellow-700",
    sustentabilidade: "bg-emerald-100 text-emerald-700",
    educacao: "bg-orange-100 text-orange-700"
  };
  
  return colorMap[category?.toLowerCase()] || "bg-blue-100 text-blue-700";
};

export default function AllPosts() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string | undefined>(undefined);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [viewModalOpen, setViewModalOpen] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  
  const { data: posts, isLoading } = usePosts(undefined, statusFilter);

  const handleGeneratePost = () => {
    setIsModalOpen(true);
  };

  const handleViewPost = (post: Post) => {
    setSelectedPost(post);
    setViewModalOpen(true);
  };
  
  const handleEditPost = (post: Post) => {
    setSelectedPost(post);
    setEditModalOpen(true);
  };

  const handleUpdateStatus = async (post: Post, newStatus: string) => {
    try {
      await apiRequest("PATCH", `/api/posts/${post.id}`, {
        status: newStatus
      });
      
      // Atualiza os dados no painel administrativo
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
      
      // Importante: invalidar as queries do blog para que os posts sejam atualizados lá também
      queryClient.invalidateQueries({ queryKey: ["blog-posts"] });
      queryClient.invalidateQueries({ queryKey: ["blog-post", post.id] });
      
      const isPublishing = newStatus === "published";
      
      toast({
        title: "Status atualizado",
        description: isPublishing 
          ? "O post foi publicado com sucesso e já está disponível no blog!"
          : "O post foi movido para rascunho e removido do blog público.",
      });
      
      // Se foi publicado, mostrar link para o blog
      if (isPublishing) {
        setTimeout(() => {
          toast({
            title: "Post publicado no blog",
            description: (
              <div className="flex flex-col gap-2">
                <p>Seu conteúdo já está disponível para leitura no blog público.</p>
                <a
                  href={`/blog/post/${post.id}`}
                  className="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Visualizar no blog
                  <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                </a>
              </div>
            ),
            duration: 10000,
          });
        }, 1000);
      }
    } catch (error) {
      toast({
        title: "Erro ao atualizar status",
        description: "Ocorreu um erro ao atualizar o status do post.",
        variant: "destructive",
      });
    }
  };

  const handleDeletePost = async (post: Post) => {
    if (!confirm("Tem certeza que deseja excluir este post?")) return;
    
    try {
      await apiRequest("DELETE", `/api/posts/${post.id}`, {});
      
      // Invalidar queries administrativas
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
      
      // Importante: invalidar as queries do blog também
      queryClient.invalidateQueries({ queryKey: ["blog-posts"] });
      queryClient.invalidateQueries({ queryKey: ["blog-post", post.id] });
      
      toast({
        title: "Post excluído",
        description: "O post foi excluído com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao excluir post",
        description: "Ocorreu um erro ao excluir o post.",
        variant: "destructive",
      });
    }
  };

  // Filter posts based on search term
  const filteredPosts = posts
    ? posts.filter(post => 
        post.title.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "published":
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
            Publicado
          </span>
        );
      case "draft":
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
            Rascunho
          </span>
        );
      case "error":
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
            Erro
          </span>
        );
      default:
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-neutral-100 text-neutral-800">
            {status}
          </span>
        );
    }
  };

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold text-neutral-900 mb-4 md:mb-0">Posts Gerados</h1>
        <div className="flex flex-col sm:flex-row gap-3">
          <Button 
            onClick={handleGeneratePost}
            className="inline-flex items-center justify-center"
          >
            <Plus className="h-4 w-4 mr-2" />
            Gerar Novo Post
          </Button>
        </div>
      </div>

      <div className="mb-6 flex flex-col sm:flex-row gap-4">
        <Input
          placeholder="Buscar posts..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full sm:w-64"
        />
        <Select
          value={statusFilter || ""}
          onValueChange={(value) => setStatusFilter(value === "" ? undefined : value)}
        >
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filtrar por status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="published">Publicados</SelectItem>
            <SelectItem value="draft">Rascunhos</SelectItem>
            <SelectItem value="error">Com erro</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Lista de Posts</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {Array(5)
                .fill(0)
                .map((_, i) => (
                  <div key={i} className="animate-pulse flex items-center p-4 border-b border-neutral-200">
                    <div className="flex-shrink-0 w-12 h-12 bg-neutral-200 rounded mr-4"></div>
                    <div className="flex-1 min-w-0 space-y-2">
                      <div className="h-5 bg-neutral-200 rounded w-3/4"></div>
                      <div className="h-4 bg-neutral-200 rounded w-1/4"></div>
                    </div>
                    <div className="flex-shrink-0 ml-4">
                      <div className="h-8 w-20 bg-neutral-200 rounded"></div>
                    </div>
                  </div>
                ))}
            </div>
          ) : filteredPosts.length > 0 ? (
            <div className="divide-y divide-neutral-200">
              {filteredPosts.map((post) => (
                <div key={post.id} className="flex flex-col md:flex-row md:items-center py-4 hover:bg-neutral-50">
                  <div className="flex items-center flex-1 min-w-0 mb-3 md:mb-0">
                    <div className="flex-shrink-0 w-12 h-12 bg-neutral-200 rounded overflow-hidden mr-4">
                      {post.imageUrl ? (
                        <img
                          src={post.imageUrl}
                          alt={post.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-primary-100 text-primary-600">
                          <FileEdit className="h-4 w-4" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-neutral-900 truncate">
                        {post.title}
                      </p>
                      <div className="flex flex-wrap items-center gap-2 mt-1">
                        {getStatusBadge(post.status || "draft")}
                        {post.category && (
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getCategoryColor(post.category)}`}>
                            {post.category}
                          </span>
                        )}
                        <span className="text-xs text-neutral-500">
                          {post.createdAt ? formatDate(post.createdAt.toString()) : ''}
                        </span>
                        {post.wordCount && (
                          <span className="text-xs text-neutral-500">
                            {post.wordCount} palavras
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleViewPost(post)}
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      Ver
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="text-blue-600 border-blue-200 hover:bg-blue-50"
                      onClick={() => handleEditPost(post)}
                    >
                      <PenTool className="h-4 w-4 mr-1" />
                      Editar
                    </Button>
                    {post.status === "draft" ? (
                      <Button 
                        size="sm" 
                        variant="outline"
                        className="text-green-600 border-green-200 hover:bg-green-50"
                        onClick={() => handleUpdateStatus(post, "published")}
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Publicar
                      </Button>
                    ) : post.status === "published" ? (
                      <Button 
                        size="sm" 
                        variant="outline"
                        className="text-yellow-600 border-yellow-200 hover:bg-yellow-50"
                        onClick={() => handleUpdateStatus(post, "draft")}
                      >
                        <AlertCircle className="h-4 w-4 mr-1" />
                        Despublicar
                      </Button>
                    ) : null}
                    <Button 
                      size="sm" 
                      variant="outline"
                      className="text-red-600 border-red-200 hover:bg-red-50"
                      onClick={() => handleDeletePost(post)}
                    >
                      <Trash className="h-4 w-4 mr-1" />
                      Excluir
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-neutral-500">
              {searchTerm || statusFilter ? (
                <p>Nenhum post encontrado com os filtros aplicados.</p>
              ) : (
                <p>Nenhum post gerado. Clique em "Gerar Novo Post" para começar.</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Generate Post Modal */}
      <GeneratePostModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        initialTrend=""
      />

      {/* View Post Modal */}
      {selectedPost && (
        <Dialog open={viewModalOpen} onOpenChange={setViewModalOpen}>
          <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selectedPost.title}</DialogTitle>
              <DialogDescription>
                <div className="flex items-center gap-2 mt-2">
                  {getStatusBadge(selectedPost.status || "draft")}
                  <span className="text-xs text-neutral-500">
                    {selectedPost.createdAt ? formatDate(selectedPost.createdAt.toString()) : ''}
                  </span>
                  {selectedPost.wordCount && (
                    <span className="text-xs text-neutral-500">
                      {selectedPost.wordCount} palavras
                    </span>
                  )}
                </div>
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="content">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="content">Conteúdo</TabsTrigger>
                <TabsTrigger value="meta">Meta Dados</TabsTrigger>
                <TabsTrigger value="image">Imagem</TabsTrigger>
              </TabsList>
              
              <TabsContent value="content" className="mt-4">
                <div 
                  className="prose max-w-none"
                  dangerouslySetInnerHTML={{ __html: selectedPost.content }}
                />
              </TabsContent>
              
              <TabsContent value="meta" className="mt-4">
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Categoria</h3>
                    <div className="mt-1 text-sm text-neutral-900 flex items-center">
                      <span className={`px-2 py-1 text-xs rounded-full font-semibold ${getCategoryColor(selectedPost.category || "tecnologia")}`}>
                        {selectedPost.category || "tecnologia"}
                      </span>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Meta Description</h3>
                    <p className="mt-1 text-sm text-neutral-900">
                      {selectedPost.metaDescription || "Nenhuma meta description gerada."}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-neutral-500">Palavras-chave</h3>
                    {selectedPost.keywords && selectedPost.keywords.length > 0 ? (
                      <div className="mt-1 flex flex-wrap gap-2">
                        {selectedPost.keywords.map((keyword, index) => (
                          <span key={index} className="px-2 py-1 text-xs rounded-full bg-primary-100 text-primary-700">
                            {keyword}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="mt-1 text-sm text-neutral-900">Nenhuma palavra-chave gerada.</p>
                    )}
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="image" className="mt-4">
                {selectedPost.imageUrl ? (
                  <div className="mt-1">
                    <img 
                      src={selectedPost.imageUrl} 
                      alt={selectedPost.title}
                      className="max-w-full max-h-96 object-contain mx-auto"
                    />
                    <p className="mt-2 text-center text-sm text-neutral-500">
                      URL da imagem: <a href={selectedPost.imageUrl} target="_blank" rel="noopener noreferrer" className="text-primary-600 hover:underline">{selectedPost.imageUrl}</a>
                    </p>
                  </div>
                ) : (
                  <p className="mt-1 text-sm text-neutral-900">Nenhuma imagem gerada para este post.</p>
                )}
              </TabsContent>
            </Tabs>
          </DialogContent>
        </Dialog>
      )}

      {/* Edit Post Modal */}
      {selectedPost && (
        <EditPostModal
          isOpen={editModalOpen}
          onClose={() => setEditModalOpen(false)}
          post={selectedPost}
        />
      )}
    </>
  );
}
