import { useParams } from "wouter";
import BlogLayout from "@/components/blog/BlogLayout";
import PostCard from "@/components/blog/PostCard";
import { useBlogPosts, categorizePosts } from "@/hooks/useBlogPosts";

export default function BlogCategory() {
  const params = useParams();
  const categorySlug = params.slug || "";
  const { data: posts = [], isLoading, error } = useBlogPosts();

  // Mapeamento entre slug e nome formatado da categoria
  const categoryNames: Record<string, string> = {
    "tecnologia": "Tecnologia",
    "negocios": "Negócios",
    "financas": "Finanças",
    "saude": "Saúde",
    "politica": "Política",
    "esportes": "Esportes",
    "sustentabilidade": "Sustentabilidade",
    "educacao": "Educação",
    "geral": "Geral"
  };

  const categoryName = categoryNames[categorySlug] || categorySlug;

  if (isLoading) {
    return (
      <BlogLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
        </div>
      </BlogLayout>
    );
  }

  if (error) {
    return (
      <BlogLayout>
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            Erro ao carregar os posts
          </h2>
          <p className="text-gray-600 max-w-lg mx-auto">
            Houve um problema ao buscar os posts. Por favor, tente novamente mais tarde.
          </p>
        </div>
      </BlogLayout>
    );
  }

  const categorizedPosts = categorizePosts(posts);
  const categoryPosts = categorizedPosts[categorySlug] || [];

  return (
    <BlogLayout>
      {/* Category Header */}
      <section className="mb-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          {categoryName}
        </h1>
        <p className="text-gray-600">
          {categoryPosts.length === 0
            ? `Nenhum post na categoria ${categoryName}`
            : categoryPosts.length === 1
            ? `1 post na categoria ${categoryName}`
            : `${categoryPosts.length} posts na categoria ${categoryName}`}
        </p>
      </section>

      {/* Posts Grid */}
      {categoryPosts.length === 0 ? (
        <div className="text-center py-8 bg-gray-50 rounded-lg">
          <p className="text-gray-600">Nenhum post encontrado nesta categoria</p>
          <p className="text-gray-500 mt-2">Tente explorar outras categorias ou volte mais tarde para novidades!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categoryPosts.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      )}

      {/* Category Description - Opcional, poderia ser adicionado dependendo das categorias */}
      {categoryPosts.length > 0 && (
        <section className="mt-12 pt-8 border-t border-gray-200">
          <h2 className="text-2xl font-bold mb-4">Sobre {categoryName}</h2>
          <p className="text-gray-700">
            {getCategoryDescription(categorySlug)}
          </p>
        </section>
      )}
    </BlogLayout>
  );
}

// Descrições de categorias para exibição na página
function getCategoryDescription(categorySlug: string): string {
  const descriptions: Record<string, string> = {
    "tecnologia": "Explore os avanços mais recentes em tecnologia, com artigos sobre IA, software, computação, 5G e muito mais. Nossa cobertura de tecnologia destaca como as inovações tecnológicas estão moldando o futuro e afetando o mercado brasileiro.",
    "negocios": "Acompanhe as tendências mais importantes do mundo corporativo e do empreendedorismo. Nossa seção de negócios traz informações sobre startups, mercado, gestão empresarial e histórias de sucesso no Brasil.",
    "financas": "Mantenha-se informado sobre o mundo financeiro, investimentos, mercado de capitais, economia e as últimas novidades em bancos digitais, PIX e criptomoedas. Artigos que ajudam a entender melhor o cenário econômico brasileiro.",
    "saude": "Artigos sobre bem-estar, medicina, tratamentos inovadores e dicas para manter uma vida saudável. Cobrimos os avanços na área da saúde e as principais tendências de cuidados médicos no Brasil.",
    "politica": "Análises e informações sobre o cenário político brasileiro, eleições, projetos de lei, governança e o impacto das decisões políticas na sociedade e na economia do país.",
    "esportes": "Cobertura das principais competições, atletas e modalidades esportivas. Análises táticas, resultados, e as histórias mais interessantes do universo esportivo nacional e internacional.",
    "sustentabilidade": "Artigos sobre meio ambiente, mudanças climáticas, energia renovável e práticas sustentáveis. Conheça iniciativas de preservação ambiental e como empresas e indivíduos estão contribuindo para um futuro mais sustentável no Brasil.",
    "educacao": "Informações sobre o sistema educacional, tendências pedagógicas, cursos, universidades e aprendizado contínuo. Artigos que exploram os desafios e oportunidades da educação brasileira.",
    "geral": "Uma variedade de tópicos interessantes que não se encaixam em categorias específicas. Explore nossa coleção diversificada de artigos sobre cultura, sociedade, curiosidades e muito mais."
  };

  return descriptions[categorySlug] || "Explore nossa coleção de artigos sobre os mais variados assuntos e tendências atuais.";
}