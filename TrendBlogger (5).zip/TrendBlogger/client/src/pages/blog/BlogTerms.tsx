import { Link } from "wouter";
import BlogLayout from "@/components/blog/BlogLayout";

export default function BlogTerms() {
  return (
    <BlogLayout>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6 text-center">Termos de Uso</h1>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Introdução</h2>
          <p className="text-gray-700 mb-4">
            Bem-vindo ao TrendPulsee. Estes termos e condições descrevem as regras e regulamentos para o uso do site TrendPulsee.
          </p>
          <p className="text-gray-700 mb-4">
            Ao acessar este site, assumimos que você aceita estes termos e condições na íntegra. Não continue a usar o site TrendPulsee se você não aceitar todos os termos e condições estabelecidos nesta página.
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Propriedade Intelectual</h2>
          <p className="text-gray-700 mb-4">
            A menos que indicado em contrário, o TrendPulsee e/ou seus licenciados detêm os direitos de propriedade intelectual de todo o material no TrendPulsee. Todos os direitos de propriedade intelectual são reservados. Você pode acessar este material do TrendPulsee para seu uso pessoal, sujeito às restrições estabelecidas nestes termos e condições.
          </p>
          
          <h3 className="text-xl font-bold mt-6 mb-3 text-gray-800">Você não deve:</h3>
          <ul className="list-disc pl-6 mb-4 text-gray-700 space-y-2">
            <li>Republicar material do TrendPulsee</li>
            <li>Vender, alugar ou sublicenciar material do TrendPulsee</li>
            <li>Reproduzir, duplicar ou copiar material do TrendPulsee</li>
            <li>Redistribuir conteúdo do TrendPulsee</li>
          </ul>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Comentários e Conteúdo do Usuário</h2>
          <p className="text-gray-700 mb-4">
            Partes deste site podem oferecer aos usuários a oportunidade de publicar e trocar opiniões e informações. O TrendPulsee não filtra, edita, publica ou revisa os comentários antes de sua presença no site. Os comentários não refletem os pontos de vista e opiniões do TrendPulsee, seus agentes e/ou afiliados.
          </p>
          <p className="text-gray-700 mb-4">
            O TrendPulsee reserva-se o direito de monitorar todos os comentários e remover quaisquer comentários que possam ser considerados inadequados, ofensivos ou causem violação destes Termos e Condições.
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Responsabilidade pelo Conteúdo</h2>
          <p className="text-gray-700 mb-4">
            Não seremos responsáveis por qualquer conteúdo que apareça em seu site. Você concorda em nos proteger e nos defender contra todas as reivindicações que estão surgindo em seu site. Nenhum link(s) deve aparecer em qualquer site que possa ser interpretado como difamatório, obsceno ou criminoso, ou que infrinja, de outra forma viole, ou defenda a violação ou outra violação de quaisquer direitos de terceiros.
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Reserva de Direitos</h2>
          <p className="text-gray-700 mb-4">
            Reservamos o direito de solicitar que você remova todos os links ou qualquer link específico para nosso site. Você aprova a remoção imediata de todos os links para nosso site, sob solicitação. Também nos reservamos o direito de alterar estes termos e condições e sua política de vinculação a qualquer momento. Ao conectar-se continuamente ao nosso site, você concorda em estar vinculado e seguir estes termos e condições de vinculação.
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Remoção de links do nosso site</h2>
          <p className="text-gray-700 mb-4">
            Se você encontrar algum link em nosso site que seja ofensivo por qualquer motivo, você pode entrar em contato e nos informar a qualquer momento. Consideraremos solicitações para remover links, mas não somos obrigados a fazê-lo ou a responder diretamente a você.
          </p>
        </div>
        
        <div className="text-center mb-10">
          <Link href="/blog">
            <a className="text-blue-600 hover:text-blue-800 transition duration-200">
              &larr; Voltar para a página inicial
            </a>
          </Link>
        </div>
      </div>
    </BlogLayout>
  );
}