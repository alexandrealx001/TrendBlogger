import BlogLayout from "@/components/blog/BlogLayout";
import { VisitorInfo } from "@/components/blog/VisitorInfo";
import { LoginForm } from "@/components/blog/LoginForm";
import { useState, useEffect } from "react";
import { Visitor } from "@/components/blog/LoginForm";
import axios from "axios";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function PerfilVisitante() {
  const [visitor, setVisitor] = useState<Visitor | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  useEffect(() => {
    async function fetchVisitor() {
      try {
        setIsLoading(true);
        const response = await axios.get('/api/blog/visitor');
        if (response.status === 200) {
          setVisitor(response.data);
        }
      } catch (error) {
        // Não está logado, não é um erro
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchVisitor();
  }, []);

  // Função para lidar com o login bem-sucedido
  const handleLoginSuccess = (visitor: Visitor) => {
    setVisitor(visitor);
    toast({
      title: "Login realizado com sucesso!",
      description: `Bem-vindo(a) ${visitor.name}!`
    });
  };

  // Função para lidar com o logout
  const handleLogout = () => {
    setVisitor(null);
    // Redireciona para a home do blog após o logout
    setLocation('/blog');
  };

  return (
    <BlogLayout>
      <div className="max-w-4xl mx-auto py-10">
        <h1 className="text-3xl font-bold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-700">
          Área do Visitante
        </h1>
        
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="mb-6">
            <h2 className="text-xl font-semibold mb-2">
              {visitor ? "Seu Perfil" : "Acesso ao Blog"}
            </h2>
            <p className="text-muted-foreground">
              {visitor 
                ? "Veja suas informações de acesso e gerencie sua conta" 
                : "Faça login ou crie uma conta para ter acesso completo ao blog"
              }
            </p>
          </div>
          
          <div className="mt-6">
            {isLoading ? (
              <div className="flex justify-center py-10">
                <div className="animate-pulse h-24 w-full max-w-md flex items-center justify-center">
                  <p className="text-muted-foreground">Carregando informações...</p>
                </div>
              </div>
            ) : visitor ? (
              <VisitorInfo onLogout={handleLogout} />
            ) : (
              <LoginForm onSuccess={handleLoginSuccess} />
            )}
          </div>
        </div>
        
        <div className="bg-blue-50 rounded-xl p-6 border border-blue-100">
          <h3 className="text-lg font-medium mb-3 text-blue-700">Porque criar uma conta?</h3>
          <ul className="space-y-2 text-blue-600">
            <li className="flex items-start">
              <span className="mr-2 mt-1">•</span>
              <span>Comente nos artigos e interaja com outros leitores</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2 mt-1">•</span>
              <span>Salve seus artigos favoritos para leitura posterior</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2 mt-1">•</span>
              <span>Receba notificações sobre novos conteúdos de seu interesse</span>
            </li>
            <li className="flex items-start">
              <span className="mr-2 mt-1">•</span>
              <span>Suas informações são usadas apenas para autenticação</span>
            </li>
          </ul>
        </div>
      </div>
    </BlogLayout>
  );
}