import { Link } from "wouter";
import BlogLayout from "@/components/blog/BlogLayout";
import { useBlogPosts, categorizePosts } from "@/hooks/useBlogPosts";

export default function BlogCategories() {
  const { data: posts = [], isLoading, error } = useBlogPosts();

  const categories = [
    { slug: "tecnologia", name: "Tecnologia", icon: "📱", color: "bg-blue-500" },
    { slug: "negocios", name: "Negócios", icon: "💼", color: "bg-indigo-500" },
    { slug: "financas", name: "Finanças", icon: "💰", color: "bg-green-500" },
    { slug: "saude", name: "Saúde", icon: "🏥", color: "bg-red-500" },
    { slug: "politica", name: "Política", icon: "🏛️", color: "bg-purple-500" },
    { slug: "esportes", name: "Esportes", icon: "⚽", color: "bg-yellow-500" },
    { slug: "sustentabilidade", name: "Sustentabilidade", icon: "🌱", color: "bg-emerald-500" },
    { slug: "educacao", name: "Educação", icon: "📚", color: "bg-orange-500" },
    { slug: "geral", name: "Geral", icon: "📰", color: "bg-gray-500" }
  ];

  if (isLoading) {
    return (
      <BlogLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
        </div>
      </BlogLayout>
    );
  }

  if (error) {
    return (
      <BlogLayout>
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            Erro ao carregar as categorias
          </h2>
          <p className="text-gray-600 max-w-lg mx-auto">
            Houve um problema ao buscar as categorias. Por favor, tente novamente mais tarde.
          </p>
        </div>
      </BlogLayout>
    );
  }

  const categorizedPosts = categorizePosts(posts);

  return (
    <BlogLayout>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">Categorias</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => {
            const categoryPosts = categorizedPosts[category.slug] || [];
            const postCount = categoryPosts.length;
            
            return (
              <Link key={category.slug} href={`/blog/categoria/${category.slug}`}>
                <a className="block transition transform hover:scale-105 duration-200">
                  <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg">
                    <div className={`${category.color} text-white p-6 flex items-center justify-between`}>
                      <h2 className="text-xl font-bold">{category.name}</h2>
                      <span className="text-3xl">{category.icon}</span>
                    </div>
                    <div className="p-6">
                      <p className="text-gray-600 mb-4">
                        {postCount === 0
                          ? "Nenhum post disponível"
                          : postCount === 1
                          ? "1 post disponível"
                          : `${postCount} posts disponíveis`}
                      </p>
                      <p className="text-blue-600 font-medium">Ver todos &rarr;</p>
                    </div>
                  </div>
                </a>
              </Link>
            );
          })}
        </div>
        
        <div className="mt-12 text-center">
          <Link href="/blog">
            <a className="text-blue-600 hover:text-blue-800 transition duration-200">
              &larr; Voltar para a página inicial
            </a>
          </Link>
        </div>
      </div>
    </BlogLayout>
  );
}