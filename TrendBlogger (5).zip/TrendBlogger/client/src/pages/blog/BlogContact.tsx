import { Link } from "wouter";
import BlogLayout from "@/components/blog/BlogLayout";
import { useState } from "react";

export default function BlogContact() {
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    subject: "",
    message: ""
  });
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormState({
      ...formState,
      [e.target.name]: e.target.value
    });
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulação de envio de formulário
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      setFormState({
        name: "",
        email: "",
        subject: "",
        message: ""
      });
    }, 1500);
  };
  
  return (
    <BlogLayout>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6 text-center">Entre em Contato</h1>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/3">
              <h2 className="text-2xl font-bold mb-4 text-blue-600">Informações de Contato</h2>
              <div className="space-y-4 text-gray-700">
                <p className="flex items-start">
                  <span className="mr-3">📍</span> 
                  <span>Av. Paulista, 1000<br />São Paulo, SP, 01310-100</span>
                </p>
                <p className="flex items-center">
                  <span className="mr-3">📞</span> 
                  <span>(11) 3456-7890</span>
                </p>
                <p className="flex items-center">
                  <span className="mr-3">✉️</span> 
                  <span>contato@trendpulse.com.br</span>
                </p>
              </div>
              
              <div className="mt-8">
                <h3 className="text-xl font-semibold mb-3 text-gray-800">Horário de Atendimento</h3>
                <p className="text-gray-700 mb-2">Segunda a Sexta: 9h às 18h</p>
                <p className="text-gray-700">Sábado: 9h às 13h</p>
              </div>
            </div>
            
            <div className="md:w-2/3">
              {submitted ? (
                <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
                  <h3 className="text-xl font-bold text-green-600 mb-3">Mensagem Enviada!</h3>
                  <p className="text-gray-700 mb-4">
                    Agradecemos pelo seu contato. Nossa equipe responderá o mais breve possível.
                  </p>
                  <button 
                    onClick={() => setSubmitted(false)}
                    className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition duration-200"
                  >
                    Enviar outra mensagem
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label htmlFor="name" className="block text-gray-700 font-medium mb-1">Nome</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formState.name}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
                      required
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-gray-700 font-medium mb-1">Email</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formState.email}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
                      required
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="subject" className="block text-gray-700 font-medium mb-1">Assunto</label>
                    <select
                      id="subject"
                      name="subject"
                      value={formState.subject}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
                      required
                    >
                      <option value="">Selecione um assunto</option>
                      <option value="geral">Informações Gerais</option>
                      <option value="parcerias">Propostas de Parceria</option>
                      <option value="suporte">Suporte Técnico</option>
                      <option value="feedback">Feedback</option>
                      <option value="outro">Outro</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="message" className="block text-gray-700 font-medium mb-1">Mensagem</label>
                    <textarea
                      id="message"
                      name="message"
                      value={formState.message}
                      onChange={handleChange}
                      rows={5}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-600"
                      required
                    ></textarea>
                  </div>
                  
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className={`w-full py-3 ${isSubmitting ? 'bg-blue-400' : 'bg-blue-600 hover:bg-blue-700'} text-white rounded-md transition duration-200 flex items-center justify-center`}
                  >
                    {isSubmitting ? (
                      <>
                        <span className="animate-spin h-5 w-5 mr-3 border-2 border-white border-t-transparent rounded-full"></span>
                        Enviando...
                      </>
                    ) : 'Enviar Mensagem'}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
        
        <div className="text-center mb-10">
          <Link href="/blog">
            <a className="text-blue-600 hover:text-blue-800 transition duration-200">
              &larr; Voltar para a página inicial
            </a>
          </Link>
        </div>
      </div>
    </BlogLayout>
  );
}