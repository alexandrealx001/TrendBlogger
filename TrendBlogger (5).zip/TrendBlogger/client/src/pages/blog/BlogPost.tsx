import { useEffect, useState } from "react";
import { useParams, Link } from "wouter";
import { useBlogPost } from "@/hooks/useBlogPosts";
import BlogLayout from "@/components/blog/BlogLayout";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { fixImageUrl } from "@/lib/utils";

// Mapeamento de categorias para cores com gradientes
const getCategoryColor = (category: string): string => {
  const colorMap: Record<string, string> = {
    tecnologia: "bg-gradient-to-r from-blue-600 to-blue-700",
    negocios: "bg-gradient-to-r from-indigo-600 to-indigo-700",
    financas: "bg-gradient-to-r from-green-600 to-green-700",
    saude: "bg-gradient-to-r from-red-600 to-red-700",
    politica: "bg-gradient-to-r from-purple-600 to-purple-700",
    esportes: "bg-gradient-to-r from-yellow-600 to-yellow-700",
    sustentabilidade: "bg-gradient-to-r from-emerald-600 to-emerald-700",
    educacao: "bg-gradient-to-r from-orange-600 to-orange-700",
    geral: "bg-gradient-to-r from-gray-600 to-gray-700"
  };
  
  return colorMap[category] || "bg-gradient-to-r from-blue-600 to-blue-700";
};

export default function BlogPost() {
  const params = useParams();
  const postId = params.id ? parseInt(params.id, 10) : undefined;
  const { data: post, isLoading, error } = useBlogPost(postId);
  
  // Estado para gerenciar a URL da imagem e seus fallbacks
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [imageError, setImageError] = useState(false);
  
  // Lista de fallbacks para tentar quando a imagem original falha
  const fallbackUrls = [
    "https://images.unsplash.com/photo-1432821596592-e2c18b78144f?q=85&w=1200&auto=format&fit=crop",
    "https://cdn.pixabay.com/photo/2016/02/03/08/32/banner-1176676_1280.jpg",
    "https://cdn.pixabay.com/photo/2015/01/21/13/20/business-606807_1280.jpg",
    "https://cdn.pixabay.com/photo/2019/01/24/08/13/arrows-3952128_1280.jpg"
  ];
  
  // Atualiza a URL da imagem quando o post mudar
  useEffect(() => {
    if (post?.imageUrl) {
      setImageUrl(fixImageUrl(post.imageUrl));
      setImageError(false);
    }
  }, [post]);

  // Gerenciador de erro de imagem que tenta diferentes URLs
  const handleImageError = () => {
    console.log("Imagem do post falhou ao carregar:", imageUrl);
    
    // Se já estamos usando uma URL de fallback, tente outra
    if (imageError) {
      // Escolhe uma URL aleatória de fallback
      const randomIndex = Math.floor(Math.random() * fallbackUrls.length);
      setImageUrl(fallbackUrls[randomIndex]);
      return;
    }
    
    // Se a URL for do Pixabay, tente os espelhos alternativos
    if (imageUrl && imageUrl.includes('pixabay.com')) {
      try {
        const parsedUrl = new URL(imageUrl);
        
        if (parsedUrl.hostname === 'cdn.pixabay.com') {
          // Tenta usar um espelho alternativo
          const match = parsedUrl.pathname.match(/\/photo\/(.*)/);
          if (match && match[1]) {
            const photoPath = match[1];
            // Tenta outras URLs de espelho
            setImageUrl(`https://i.pixabay.com/photo/${photoPath}`);
            setImageError(true);
            return;
          }
        }
      } catch (e) {
        // Se falhar na análise da URL, use um fallback
        const randomIndex = Math.floor(Math.random() * fallbackUrls.length);
        setImageUrl(fallbackUrls[randomIndex]);
        return;
      }
    }
    
    // Se não for URL do Pixabay ou não conseguir criar espelho, use fallback aleatório
    const randomIndex = Math.floor(Math.random() * fallbackUrls.length);
    setImageUrl(fallbackUrls[randomIndex]);
    setImageError(true);
  };

  // Atualização do título da página com base no post
  useEffect(() => {
    if (post?.title) {
      document.title = `${post.title} | TrendPulse`;
    }
    
    return () => {
      document.title = "TrendPulse | Blog";
    };
  }, [post]);

  if (isLoading) {
    return (
      <BlogLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600"></div>
        </div>
      </BlogLayout>
    );
  }

  if (error || !post) {
    return (
      <BlogLayout>
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">
            {error ? "Erro ao carregar o post" : "Post não encontrado"}
          </h2>
          <p className="text-gray-600 max-w-lg mx-auto mb-6">
            {error 
              ? "Houve um problema ao buscar este post. Por favor, tente novamente mais tarde."
              : "O post que você está procurando não existe ou foi removido."}
          </p>
          <Link href="/blog">
            <a className="text-blue-600 hover:text-blue-800 transition duration-200">
              &larr; Voltar para a página inicial
            </a>
          </Link>
        </div>
      </BlogLayout>
    );
  }

  const formattedDate = post.createdAt
    ? formatDistanceToNow(new Date(post.createdAt), {
        addSuffix: true,
        locale: ptBR,
      })
    : "";

  // Função para identificar a categoria do post baseada nas palavras-chave
  const getCategoryFromKeywords = (keywords: string[] | null): string => {
    if (!keywords || keywords.length === 0) return "Geral";
    
    const categoryMap: Record<string, string[]> = {
      "Tecnologia": ["tecnologia", "digital", "software", "app", "programação", "computação", "ia", "inteligência artificial", "chatgpt", "5g", "iot"],
      "Negócios": ["negócios", "empresa", "empreendedorismo", "startups", "mercado", "corporativo"],
      "Finanças": ["finanças", "dinheiro", "investimento", "banco", "pix", "criptomoedas", "financeiro"],
      "Saúde": ["saúde", "bem-estar", "médico", "medicina", "hospital", "clínica", "tratamento", "doença"],
      "Política": ["política", "governo", "eleição", "congresso", "lei", "legislação", "democracia"],
      "Esportes": ["esporte", "futebol", "copa", "olimpíada", "jogo", "atletismo", "atleta", "competição"],
      "Sustentabilidade": ["sustentabilidade", "meio ambiente", "clima", "ecologia", "verde", "biodiversidade"],
      "Educação": ["educação", "escola", "universidade", "faculdade", "ensino", "aprendizado", "professor"]
    };
    
    for (const [category, categoryKeywords] of Object.entries(categoryMap)) {
      if (keywords.some(keyword => 
        categoryKeywords.some(catKey => 
          keyword.toLowerCase().includes(catKey.toLowerCase())
        )
      )) {
        return category;
      }
    }
    
    return "Geral";
  };

  // Usar a categoria explícita do post ou inferir das keywords se não existir
  const category = post.category || getCategoryFromKeywords(post.keywords);
  const categoryColor = getCategoryColor(category);

  return (
    <BlogLayout>
      <article className="max-w-4xl mx-auto">
        {/* Header */}
        <header className="mb-8">
          {(post.imageUrl || imageUrl) && (
            <div className="relative mb-6">
              <img 
                src={imageUrl || ""} 
                alt={post.title}
                onError={handleImageError}
                className="w-full h-80 object-cover rounded-lg shadow-md" 
              />
              <div className="absolute top-4 left-4">
                <span className={`${categoryColor} text-white text-sm uppercase font-bold rounded-full px-3 py-1 shadow-md`}>
                  {category}
                </span>
              </div>
              <div className="absolute bottom-0 left-0 right-0 bg-black/70 text-xs text-white p-1 font-mono overflow-hidden truncate hidden md:block">
                URL original: {post.imageUrl}
                {imageError && imageUrl !== post.imageUrl && (
                  <div className="text-yellow-400">
                    Usando URL alternativa: {imageUrl}
                  </div>
                )}
              </div>
            </div>
          )}
          
          <h1 className="text-4xl font-bold text-gray-900 mb-4">{post.title}</h1>
          
          <div className="flex items-center text-gray-600 mb-6">
            <span className="mr-4">{formattedDate}</span>
            <span>•</span>
            <span className="ml-4">{post.wordCount} palavras</span>
          </div>
          
          {post.metaDescription && (
            <div className="text-xl text-gray-600 italic border-l-4 border-blue-600 pl-4 py-2 bg-blue-50 rounded-r-md mb-6">
              {post.metaDescription}
            </div>
          )}
        </header>

        {/* Content */}
        <div className="prose prose-lg max-w-none text-gray-800">
          <div dangerouslySetInnerHTML={{ __html: post.content }} />
        </div>

        {/* Tags */}
        {post.keywords && post.keywords.length > 0 && (
          <div className="mt-12 pt-6 border-t border-gray-200">
            <h3 className="text-lg font-medium text-gray-900 mb-3">Tags</h3>
            <div className="flex flex-wrap gap-2">
              {post.keywords.map((keyword, index) => (
                <span 
                  key={index} 
                  className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm"
                >
                  {keyword}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Navigation */}
        <div className="mt-12 pt-6 border-t border-gray-200">
          <Link href="/blog">
            <a className="text-blue-600 hover:text-blue-800 transition duration-200">
              &larr; Voltar para todos os posts
            </a>
          </Link>
        </div>
      </article>

      {/* Related Articles Section - Could be implemented if we had related posts functionality */}
    </BlogLayout>
  );
}