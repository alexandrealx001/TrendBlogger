import { Link } from "wouter";
import BlogLayout from "@/components/blog/BlogLayout";

export default function BlogAbout() {
  return (
    <BlogLayout>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6 text-center">Sobre o TrendPulsee</h1>
        
        <section className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Nossa Missão</h2>
          <p className="text-gray-700 mb-4">
            O TrendPulsee nasceu com uma missão clara: trazer conteúdo relevante, atualizado e de qualidade sobre os temas que estão em alta no Brasil. Utilizamos tecnologia avançada de análise de tendências para identificar os assuntos mais relevantes do momento e produzir artigos informativos que agregam valor para nossos leitores.
          </p>
          <p className="text-gray-700 mb-4">
            Acreditamos que a informação de qualidade é essencial para tomadas de decisão e para manter-se atualizado em um mundo em constante transformação. Por isso, nos dedicamos a criar conteúdo que seja ao mesmo tempo informativo, acessível e interessante.
          </p>
        </section>
        
        <section className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Como Funciona</h2>
          <p className="text-gray-700 mb-4">
            Nosso sistema utiliza algoritmos avançados para monitorar e identificar as tendências mais relevantes no Brasil. Analisamos dados de busca, redes sociais e fontes confiáveis para capturar os temas que estão gerando maior interesse.
          </p>
          <p className="text-gray-700 mb-4">
            A partir dessas tendências, nossa equipe editorial trabalha para produzir conteúdo de alta qualidade, que passa por um rigoroso processo de verificação e edição antes de ser publicado. Assim, garantimos que você tenha acesso a informações confiáveis e relevantes sobre os assuntos do momento.
          </p>
        </section>
        
        <section className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Nossos Valores</h2>
          <ul className="space-y-4 text-gray-700 list-disc pl-5">
            <li>
              <strong>Qualidade:</strong> Comprometemo-nos com a excelência em cada artigo que publicamos.
            </li>
            <li>
              <strong>Relevância:</strong> Focamos nos temas que realmente importam para nossos leitores.
            </li>
            <li>
              <strong>Atualidade:</strong> Mantemos nosso conteúdo sempre atualizado com as últimas tendências.
            </li>
            <li>
              <strong>Confiabilidade:</strong> Baseamos nossos artigos em fontes verificáveis e de confiança.
            </li>
            <li>
              <strong>Acessibilidade:</strong> Escrevemos de forma clara e acessível para todos os públicos.
            </li>
          </ul>
        </section>
        
        <section className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Entre em Contato</h2>
          <p className="text-gray-700 mb-6">
            Temos prazer em ouvir sua opinião, sugestões ou dúvidas sobre o TrendPulsee. Entre em contato conosco através de um dos canais abaixo:
          </p>
          <div className="space-y-2 text-gray-700">
            <p><strong>Email:</strong> contato@trendpulsee.com.br</p>
            <p><strong>Telefone:</strong> (11) 3456-7890</p>
            <p><strong>Endereço:</strong> Av. Paulista, 1000 - São Paulo, SP</p>
          </div>
        </section>
        
        <div className="text-center mb-10">
          <Link href="/blog">
            <a className="text-blue-600 hover:text-blue-800 transition duration-200">
              &larr; Voltar para a página inicial
            </a>
          </Link>
        </div>
      </div>
    </BlogLayout>
  );
}