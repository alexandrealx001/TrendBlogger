import { useState, useRef, useEffect } from "react";
import BlogLayout from "@/components/blog/BlogLayout";
import PostCard from "@/components/blog/PostCard";
import { useBlogPosts, categorizePosts, getRecentPosts } from "@/hooks/useBlogPosts";
import { Post } from "@shared/schema";
import { 
  Home, 
  Cpu, 
  Briefcase, 
  DollarSign, 
  Heart, 
  LandPlot,
  Dumbbell, 
  Leaf, 
  GraduationCap,
  Globe,
  ChevronLeft,
  ChevronRight
} from "lucide-react";

export default function BlogHome() {
  const { data: posts = [], isLoading, error } = useBlogPosts();
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const categoriesContainerRef = useRef<HTMLDivElement>(null);
  
  // Verificar se precisa mostrar as setas de navegação
  useEffect(() => {
    const checkScroll = () => {
      if (categoriesContainerRef.current) {
        const { scrollLeft, scrollWidth, clientWidth } = categoriesContainerRef.current;
        setShowLeftArrow(scrollLeft > 0);
        setShowRightArrow(scrollLeft + clientWidth < scrollWidth - 10); // margem de erro
      }
    };
    
    // Verificar ao carregar
    checkScroll();
    
    // Adicionar event listener para scrolling
    const container = categoriesContainerRef.current;
    if (container) {
      container.addEventListener('scroll', checkScroll);
      // Também verificar após um pequeno atraso para garantir que o layout está completo
      setTimeout(checkScroll, 500);
    }
    
    // Remover event listener quando o componente for desmontado
    return () => {
      if (container) {
        container.removeEventListener('scroll', checkScroll);
      }
    };
  }, []);
  
  // Funções para rolar para a esquerda e direita
  const scrollLeft = () => {
    if (categoriesContainerRef.current) {
      categoriesContainerRef.current.scrollBy({ left: -300, behavior: 'smooth' });
    }
  };
  
  const scrollRight = () => {
    if (categoriesContainerRef.current) {
      categoriesContainerRef.current.scrollBy({ left: 300, behavior: 'smooth' });
    }
  };
  
  if (isLoading) {
    return (
      <BlogLayout>
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-pulse flex flex-col items-center">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mb-4"></div>
            <p className="text-blue-600 font-medium">Carregando conteúdo...</p>
          </div>
        </div>
      </BlogLayout>
    );
  }

  if (error || !posts || posts.length === 0) {
    return (
      <BlogLayout>
        <div className="text-center py-12 bg-white rounded-xl shadow-md">
          <div className="max-w-lg mx-auto p-8">
            <div className="mb-6 text-blue-600">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-4">
              {error ? "Erro ao carregar os posts" : "Nenhum post disponível no momento"}
            </h2>
            <p className="text-gray-600">
              {error 
                ? "Houve um problema ao buscar os posts. Por favor, tente novamente mais tarde."
                : "Não há conteúdo publicado disponível. Volte em breve para novidades!"}
            </p>
          </div>
        </div>
      </BlogLayout>
    );
  }

  // Garantir que posts é sempre um array
  const postsArray = Array.isArray(posts) ? posts : [];
  
  const categorizedPosts = categorizePosts(postsArray);
  const featuredPost = postsArray.length > 0 ? postsArray[0] : null;
  const recentPosts = postsArray.length > 1 ? getRecentPosts(postsArray.slice(1), 6) : [];
  
  const categories = [
    { id: "all", name: "Todos" },
    { id: "tecnologia", name: "Tecnologia" },
    { id: "negocios", name: "Negócios" },
    { id: "financas", name: "Finanças" },
    { id: "saude", name: "Saúde" },
    { id: "politica", name: "Política" },
    { id: "esportes", name: "Esportes" },
    { id: "sustentabilidade", name: "Sustentabilidade" },
    { id: "educacao", name: "Educação" }
  ];

  const filteredPosts = selectedCategory === "all" 
    ? postsArray 
    : categorizedPosts[selectedCategory] || [];

  // Encontrar posts para carrossel de categorias
  const getTrendingCategoryPosts = (): { category: string, posts: Post[] }[] => {
    const result: { category: string, posts: Post[] }[] = [];
    let remainingCategories = [...Object.keys(categorizedPosts)];
    
    // Adicionar apenas categorias que têm posts
    while (result.length < 3 && remainingCategories.length > 0) {
      const category = remainingCategories.shift();
      if (category && categorizedPosts[category]?.length > 0) {
        result.push({
          category,
          posts: categorizedPosts[category].slice(0, 4)
        });
      }
    }
    
    return result;
  };

  const trendingCategories = getTrendingCategoryPosts();

  return (
    <BlogLayout>
      {/* Hero Section with Featured Post */}
      <section className="mb-10">
        {featuredPost && <PostCard post={featuredPost} featured={true} />}
      </section>

      {/* Category Filters */}
      <section className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Explorar Conteúdo</h2>
        </div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 relative h-[320px]">
          {/* Botão seta esquerda */}
          {showLeftArrow && (
            <button 
              onClick={scrollLeft}
              className="absolute left-2 top-1/2 transform -translate-y-1/2 w-10 h-10 bg-white rounded-full shadow-lg z-10 flex items-center justify-center text-blue-600 hover:bg-blue-50"
            >
              <ChevronLeft size={20} />
            </button>
          )}
          
          {/* Botão seta direita */}
          {showRightArrow && (
            <button 
              onClick={scrollRight}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 w-10 h-10 bg-white rounded-full shadow-lg z-10 flex items-center justify-center text-blue-600 hover:bg-blue-50"
            >
              <ChevronRight size={20} />
            </button>
          )}
          
          {/* Container com scroll horizontal */}
          <div 
            ref={categoriesContainerRef}
            className="flex gap-16 overflow-x-auto scrollbar-hide py-32 px-4 scroll-smooth min-h-[240px] items-center justify-center"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`w-[80px] h-[80px] flex items-center justify-center rounded-full text-sm font-medium overflow-visible group relative ${
                  selectedCategory === category.id
                    ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg"
                    : "bg-blue-100 text-blue-700 hover:bg-blue-200"
                } transition-all duration-300 hover:scale-[1.5] transform origin-center hover:z-10`}
              >
                <span className={`relative z-10 ${
                  selectedCategory === category.id
                    ? "text-white"
                    : "text-blue-700 group-hover:text-blue-800"
                  } transition-colors duration-300`}
                >
                  {category.id === "all" && <Home size={40} strokeWidth={1.5} />}
                  {category.id === "tecnologia" && <Cpu size={40} strokeWidth={1.5} />}
                  {category.id === "negocios" && <Briefcase size={40} strokeWidth={1.5} />}
                  {category.id === "financas" && <DollarSign size={40} strokeWidth={1.5} />}
                  {category.id === "saude" && <Heart size={40} strokeWidth={1.5} />}
                  {category.id === "politica" && <LandPlot size={40} strokeWidth={1.5} />}
                  {category.id === "esportes" && <Dumbbell size={40} strokeWidth={1.5} />}
                  {category.id === "sustentabilidade" && <Leaf size={40} strokeWidth={1.5} />}
                  {category.id === "educacao" && <GraduationCap size={40} strokeWidth={1.5} />}
                </span>
                
                {/* Efeito glow estático para o item selecionado */}
                {selectedCategory === category.id && (
                  <div className="absolute inset-0 -m-1 rounded-full bg-blue-500 opacity-30 blur-md"></div>
                )}
                
                {/* Efeito glow ao passar o mouse */}
                <div className={`absolute inset-0 rounded-full ${
                  selectedCategory === category.id
                    ? "shadow-[0_0_20px_5px_rgba(59,130,246,0.7)]"
                    : "shadow-none group-hover:shadow-[0_0_15px_3px_rgba(59,130,246,0.6)]"
                } transition-shadow duration-300`}></div>
                <div className="absolute top-[-40px] opacity-0 group-hover:opacity-100 group-hover:top-[-55px] transition-all duration-300 text-lg font-bold text-blue-800 whitespace-nowrap bg-white/80 px-3 py-1 rounded-full shadow-md">
                  {category.name}
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Banner promocional */}
      
      {/* Destaque Banner */}
      <section className="mb-10 relative overflow-hidden">
        <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl p-8 shadow-lg">
          <div className="absolute top-0 right-0 w-64 h-64 opacity-20">
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <path fill="#FFFFFF" d="M37.9,-48.2C51.1,-34.3,65.2,-24,73.2,-7.8C81.3,8.3,83.2,30.3,73.4,42.6C63.6,54.8,42.1,57.3,23.4,63.9C4.7,70.5,-11.2,81.1,-25.4,78.9C-39.6,76.7,-52.1,61.7,-57.9,45.8C-63.7,29.9,-62.9,13.1,-60.2,-2.7C-57.5,-18.5,-52.9,-33.3,-43.1,-47.4C-33.3,-61.5,-18.1,-74.9,-1.5,-73.1C15,-71.4,24.8,-62.1,37.9,-48.2Z" transform="translate(100 100)" />
            </svg>
          </div>

          <div className="relative flex flex-col md:flex-row items-center gap-8 z-10">
            <div className="flex-1">
              <span className="inline-block px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-medium mb-3">Tendência da Semana</span>
              <h2 className="text-3xl font-bold text-white mb-4">Descubra as Últimas Tendências do Brasil</h2>
              <p className="text-blue-100 mb-6">
                Nosso blog analisa as tendências mais quentes em tecnologia, negócios, finanças e mais. Acompanhe nosso conteúdo para ficar sempre à frente.
              </p>
              <div className="flex flex-wrap gap-2">
                {["Tecnologia", "Negócios", "5G", "Inteligência Artificial", "Transformação Digital"].map((tag) => (
                  <span key={tag} className="px-3 py-1 rounded-full bg-white/20 text-white text-xs">{tag}</span>
                ))}
              </div>
            </div>
            <div className="md:w-1/3 flex-shrink-0">
              <div className="relative h-60 w-60 md:h-72 md:w-72 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center overflow-hidden shadow-xl">
                <div className="absolute inset-2 rounded-full overflow-hidden bg-gradient-to-tr from-blue-400 to-indigo-500 p-1">
                  <div className="absolute inset-0 rounded-full overflow-hidden bg-blue-900 flex items-center justify-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 text-white opacity-90" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Banner promocional no meio da página */}
      {selectedCategory === "all" && (
        <section className="mb-10">
          <div className="bg-gradient-to-r from-indigo-600 via-blue-600 to-purple-600 rounded-2xl overflow-hidden shadow-xl">
            <div className="relative px-6 py-8 md:p-10 text-white">
              {/* Padrão de círculos decorativos */}
              <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-white opacity-10 -mt-20 -mr-20" />
              <div className="absolute bottom-0 left-0 w-40 h-40 rounded-full bg-white opacity-10 -mb-10 -ml-10" />
              
              <div className="relative z-10 flex flex-col md:flex-row items-center">
                <div className="md:w-2/3 mb-6 md:mb-0 md:pr-8">
                  <h3 className="text-2xl md:text-3xl font-bold mb-2">Fique por dentro das novidades no Brasil</h3>
                  <p className="text-blue-100 mb-4">
                    Acompanhe as tendências do momento e receba insights estratégicos sobre o que está acontecendo no país. 
                  </p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    <span className="bg-white/20 text-white px-3 py-1 rounded-full text-sm">#TendênciasBrasileiras</span>
                    <span className="bg-white/20 text-white px-3 py-1 rounded-full text-sm">#ConteúdoAtualizado</span>
                    <span className="bg-white/20 text-white px-3 py-1 rounded-full text-sm">#InformaçãoDeQualidade</span>
                  </div>
                  <button className="inline-flex items-center px-5 py-2.5 bg-white text-indigo-700 font-medium rounded-lg hover:bg-blue-50 transition-colors">
                    Ver artigos recentes
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                    </svg>
                  </button>
                </div>
                <div className="md:w-1/3">
                  <div className="h-44 w-44 md:h-56 md:w-56 mx-auto relative">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-36 h-36 md:w-48 md:h-48 rounded-full bg-white/30 flex items-center justify-center backdrop-blur-sm">
                        <div className="w-32 h-32 md:w-44 md:h-44 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 md:h-20 md:w-20 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} 
                                  d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                          </svg>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Post Grid */}
      <section className="mb-16">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            {selectedCategory === "all" ? "Conteúdo em Destaque" : `Posts em ${categories.find(c => c.id === selectedCategory)?.name}`}
          </h2>
          
          {filteredPosts.length > 6 && selectedCategory !== "all" && (
            <button className="text-blue-600 hover:text-blue-800 font-medium flex items-center">
              Ver todos
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          )}
        </div>
        
        {filteredPosts.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="max-w-md mx-auto">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-gray-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
              <p className="text-gray-600 mb-2">Nenhum post encontrado nesta categoria</p>
              <p className="text-gray-500 text-sm">Tente selecionar outra categoria ou volte mais tarde para novos conteúdos.</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {(selectedCategory === "all" ? recentPosts : filteredPosts).slice(0, 6).map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        )}
      </section>

      {/* Newsletter Section */}
      <section className="mb-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl p-8 text-center shadow-lg">
        <div className="max-w-2xl mx-auto">
          <h3 className="text-2xl font-bold mb-4 text-white">Não perca nenhuma tendência!</h3>
          <p className="text-blue-100 mb-6">
            Inscreva-se em nossa newsletter e receba as últimas tendências e conteúdos diretamente em seu e-mail.
          </p>
          <div className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
            <input
              type="email"
              placeholder="Seu melhor e-mail"
              className="flex-grow px-4 py-3 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-300"
            />
            <button 
              onClick={() => {
                // Usa o contexto global para abrir o modal na aba de registro
                import('@/contexts/LoginContext').then(module => {
                  // Chama a função global para abrir o modal na aba de registro
                  module.globalLogin.openLoginModal('register');
                });
              }}
              className="bg-white text-blue-700 px-6 py-3 rounded-r-md hover:bg-blue-50 transition duration-200 font-medium"
            >
              Inscrever-se
            </button>
          </div>
          <p className="text-blue-200 text-sm mt-3">
            Você pode cancelar sua inscrição a qualquer momento. Não enviamos spam!
          </p>
        </div>
      </section>

      {/* Category Carousels */}
      {selectedCategory === "all" && trendingCategories.length > 0 && (
        <section className="mb-16">
          {trendingCategories.map(({ category, posts }) => (
            <div key={category} className="mb-10">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  Em {categories.find(c => c.id === category)?.name || category}
                </h2>
                <button 
                  onClick={() => setSelectedCategory(category)}
                  className="text-blue-600 hover:text-blue-800 font-medium flex items-center"
                >
                  Ver mais
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {posts.map((post) => (
                  <PostCard key={post.id} post={post} />
                ))}
              </div>
            </div>
          ))}
        </section>
      )}
    </BlogLayout>
  );
}