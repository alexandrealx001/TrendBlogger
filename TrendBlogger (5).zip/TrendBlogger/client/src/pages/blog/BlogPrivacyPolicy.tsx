import { Link } from "wouter";
import BlogLayout from "@/components/blog/BlogLayout";

export default function BlogPrivacyPolicy() {
  return (
    <BlogLayout>
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6 text-center">Política de Privacidade</h1>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Introdução</h2>
          <p className="text-gray-700 mb-4">
            O TrendPulsee está comprometido em proteger sua privacidade. Esta Política de Privacidade explica como coletamos, usamos e protegemos suas informações pessoais quando você visita nosso site ou utiliza nossos serviços.
          </p>
          <p className="text-gray-700 mb-4">
            Ao utilizar o TrendPulsee, você concorda com a coleta e uso de informações de acordo com esta política. As informações pessoais que coletamos são utilizadas apenas para fornecer e melhorar nosso serviço. Não compartilharemos suas informações com ninguém, exceto conforme descrito nesta Política de Privacidade.
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Coleta e Uso de Informações</h2>
          <p className="text-gray-700 mb-4">
            Para uma melhor experiência durante o uso do nosso serviço, podemos solicitar que você nos forneça certas informações pessoalmente identificáveis, incluindo, mas não se limitando a seu nome e endereço de e-mail. As informações que solicitamos serão retidas por nós e usadas conforme descrito nesta política de privacidade.
          </p>
          
          <h3 className="text-xl font-bold mt-6 mb-3 text-gray-800">Dados de Uso</h3>
          <p className="text-gray-700 mb-4">
            Também coletamos informações sobre como o serviço é acessado e usado. Esses dados podem incluir informações como o endereço IP do seu computador, tipo de navegador, páginas visitadas, tempo gasto em cada página, horário e data da visita, e outras estatísticas.
          </p>
          
          <h3 className="text-xl font-bold mt-6 mb-3 text-gray-800">Cookies</h3>
          <p className="text-gray-700 mb-4">
            Cookies são arquivos com pequena quantidade de dados que são armazenados em seu navegador e comumente usados como identificadores anônimos. Utilizamos cookies para coletar informações a fim de melhorar nossos serviços.
          </p>
          <p className="text-gray-700 mb-4">
            Você tem a opção de aceitar ou recusar esses cookies. A maioria dos navegadores aceita cookies automaticamente, mas você pode modificar as configurações do seu navegador para recusar cookies, se preferir.
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Segurança</h2>
          <p className="text-gray-700 mb-4">
            Valorizamos sua confiança em nos fornecer suas informações pessoais, portanto, estamos nos esforçando para usar meios comercialmente aceitáveis de protegê-las. Mas lembre-se que nenhum método de transmissão pela internet, ou método de armazenamento eletrônico é 100% seguro e confiável, e não podemos garantir sua segurança absoluta.
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Alterações nesta Política de Privacidade</h2>
          <p className="text-gray-700 mb-4">
            Podemos atualizar nossa Política de Privacidade de tempos em tempos. Assim, recomendamos que você revise esta página periodicamente para quaisquer alterações. Notificaremos você sobre quaisquer alterações, publicando a nova Política de Privacidade nesta página. Essas alterações são efetivas imediatamente após serem publicadas.
          </p>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <h2 className="text-2xl font-bold mb-4 text-blue-600">Contato</h2>
          <p className="text-gray-700 mb-4">
            Se você tiver alguma dúvida ou sugestão sobre nossa Política de Privacidade, não hesite em nos contatar em contato@trendpulsee.com.br.
          </p>
        </div>
        
        <div className="text-center mb-10">
          <Link href="/blog">
            <a className="text-blue-600 hover:text-blue-800 transition duration-200">
              &larr; Voltar para a página inicial
            </a>
          </Link>
        </div>
      </div>
    </BlogLayout>
  );
}