import { useState, useEffect } from "react";
import { usePageviews, type Pageview } from "@/hooks/usePageviews";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip,
  Legend, ResponsiveContainer, PieChart, Pie, Cell
} from "recharts";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Loader2 } from "lucide-react";
import axios from "axios";

// Interface para estatísticas de visitantes únicos por período
interface UniqueVisitorStats {
  daily: number;
  monthly: number;
  yearly: number;
  total: number;
}

// Interface para os dados de posts
interface Post {
  id: number;
  title: string;
  category: string;
}

export default function PageviewStats() {
  const { pageviews, isLoading } = usePageviews();
  const [searchTerm, setSearchTerm] = useState("");
  const [posts, setPosts] = useState<Post[]>([]);
  const [loadingPosts, setLoadingPosts] = useState(false);
  const [uniqueVisitorStats, setUniqueVisitorStats] = useState<UniqueVisitorStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(false);

  // Buscar informações dos posts para exibir os títulos
  useEffect(() => {
    const fetchPosts = async () => {
      try {
        setLoadingPosts(true);
        const response = await axios.get('/api/posts', { withCredentials: true });
        setPosts(response.data);
      } catch (error) {
        console.error("Erro ao buscar posts:", error);
      } finally {
        setLoadingPosts(false);
      }
    };

    fetchPosts();
  }, []);
  
  // Buscar estatísticas de visitantes únicos por período
  useEffect(() => {
    const fetchUniqueVisitorStats = async () => {
      try {
        setLoadingStats(true);
        const response = await axios.get('/api/stats/unique-visitors', { withCredentials: true });
        setUniqueVisitorStats(response.data);
      } catch (error) {
        console.error("Erro ao buscar estatísticas de visitantes únicos:", error);
      } finally {
        setLoadingStats(false);
      }
    };

    fetchUniqueVisitorStats();
  }, []);

  // Função para obter o título do post com base no caminho
  const getPostTitle = (path: string): string => {
    if (!path.includes("/blog/post/")) return path;
    
    const postIdMatch = path.match(/\/blog\/post\/(\d+)/);
    if (!postIdMatch) return path;
    
    const postId = parseInt(postIdMatch[1]);
    const post = posts.find(p => p.id === postId);
    
    return post ? `${post.title} (${post.category})` : path;
  };

  // Filtrar as pageviews com base no termo de busca
  const filteredPageviews = searchTerm
    ? pageviews.filter(
        (pageview) =>
          pageview.path.toLowerCase().includes(searchTerm.toLowerCase()) ||
          getPostTitle(pageview.path).toLowerCase().includes(searchTerm.toLowerCase())
      )
    : pageviews;
    
  // Ordenar pageviews por contagem (maior para menor)
  const sortedPageviews = [...filteredPageviews].sort((a, b) => b.count - a.count);

  // Preparar dados para o gráfico de barras - Top 10 páginas mais visitadas
  const top10Pages = sortedPageviews.slice(0, 10).map((pageview) => {
    const displayName = getPostTitle(pageview.path);
    return {
      name: displayName.length > 40 ? `${displayName.substring(0, 40)}...` : displayName,
      visits: pageview.count,
      uniqueVisits: pageview.uniqueCount,
      path: pageview.path
    };
  });
  
  // Preparar dados para o gráfico de barras comparando visitas totais vs únicas
  const pagesWithUniqueVisitors = sortedPageviews
    .filter(pageview => pageview.uniqueCount > 0)
    .slice(0, 10)
    .map((pageview) => {
      const displayName = getPostTitle(pageview.path);
      return {
        name: displayName.length > 35 ? `${displayName.substring(0, 35)}...` : displayName,
        totalVisits: pageview.count,
        uniqueVisits: pageview.uniqueCount,
        path: pageview.path
      };
    });

  // Agrupar visualizações por categoria (totais e únicos)
  const categoryDataTotal: {[key: string]: number} = {};
  const categoryDataUnique: {[key: string]: number} = {};
  
  pageviews.forEach(pageview => {
    let category = "Outros";
    
    if (pageview.path === "/blog") {
      category = "Home";
    } else if (pageview.path.includes("/blog/categoria/")) {
      const parts = pageview.path.split("/");
      category = parts[parts.length - 1].charAt(0).toUpperCase() + parts[parts.length - 1].slice(1);
    } else if (pageview.path.includes("/blog/post/")) {
      const postIdMatch = pageview.path.match(/\/blog\/post\/(\d+)/);
      if (postIdMatch) {
        const postId = parseInt(postIdMatch[1]);
        const post = posts.find(p => p.id === postId);
        if (post && post.category) {
          category = post.category.charAt(0).toUpperCase() + post.category.slice(1);
        } else {
          category = "Posts";
        }
      } else {
        category = "Posts";
      }
    }
    
    // Acumular visualizações totais
    categoryDataTotal[category] = (categoryDataTotal[category] || 0) + pageview.count;
    
    // Acumular visitantes únicos
    categoryDataUnique[category] = (categoryDataUnique[category] || 0) + pageview.uniqueCount;
  });

  // Converter dados agrupados para formato adequado para o gráfico de pizza (total)
  const pieChartData = Object.entries(categoryDataTotal).map(([name, value]) => ({ name, value }));
  
  // Converter dados agrupados para formato adequado para o gráfico comparativo de barras (total vs único)
  const categoryComparisonData = Object.keys(categoryDataTotal).map(category => ({
    name: category,
    total: categoryDataTotal[category],
    unique: categoryDataUnique[category] || 0
  })).sort((a, b) => b.total - a.total);

  // Cores para o gráfico de pizza
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#83a6ed', '#8dd1e1', '#82ca9d', '#a4de6c', '#d0ed57'];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6">
      <div className="flex flex-col space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold text-gray-900">Estatísticas de Visualização</h1>
          <div className="flex space-x-2 w-1/3">
            <Input
              placeholder="Buscar por caminho..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full"
            />
            {searchTerm && (
              <Button
                variant="outline"
                onClick={() => setSearchTerm("")}
              >
                Limpar
              </Button>
            )}
          </div>
        </div>

        {/* Cards com estatísticas gerais */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl">Total de Páginas</CardTitle>
              <CardDescription>Número de páginas diferentes visitadas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-blue-600">{pageviews.length}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl">Total de Visualizações</CardTitle>
              <CardDescription>Soma de todas as visualizações</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-blue-600">
                {pageviews.reduce((total, page) => total + page.count, 0)}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl">Total de Visitantes Únicos</CardTitle>
              <CardDescription>Soma de todos IPs únicos registrados</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-green-600">
                {pageviews.reduce((total, page) => total + page.uniqueCount, 0)}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl">Páginas com Visitantes Únicos</CardTitle>
              <CardDescription>Páginas com pelo menos um visitante único</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-indigo-600">
                {pageviews.filter(page => page.uniqueCount > 0).length}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-2xl">Última Visita</CardTitle>
              <CardDescription>Data e hora da visita mais recente</CardDescription>
            </CardHeader>
            <CardContent>
              {pageviews.length > 0 ? (
                <div className="text-2xl font-bold text-blue-600">
                  {format(
                    new Date(
                      Math.max(...pageviews.map(p => new Date(p.lastVisit).getTime()))
                    ),
                    "dd/MM/yyyy HH:mm",
                    { locale: ptBR }
                  )}
                </div>
              ) : (
                <div className="text-xl text-gray-400">Sem visitas</div>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Cards com estatísticas de visitantes únicos por período */}
        <Card>
          <CardHeader>
            <CardTitle>Visitantes Únicos por Período</CardTitle>
            <CardDescription>Contagem de IPs únicos por diferentes períodos</CardDescription>
          </CardHeader>
          <CardContent>
            {loadingStats ? (
              <div className="flex justify-center items-center py-4">
                <Loader2 className="h-8 w-8 animate-spin text-blue-500" />
              </div>
            ) : uniqueVisitorStats ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
                <div className="bg-blue-50 border border-blue-100 p-4 rounded-lg">
                  <h3 className="text-lg font-semibold text-blue-800 mb-2">Hoje</h3>
                  <div className="text-3xl font-bold text-blue-600">{uniqueVisitorStats.daily}</div>
                  <p className="text-sm text-blue-600 mt-1">visitantes únicos nas últimas 24h</p>
                </div>
                
                <div className="bg-green-50 border border-green-100 p-4 rounded-lg">
                  <h3 className="text-lg font-semibold text-green-800 mb-2">Este Mês</h3>
                  <div className="text-3xl font-bold text-green-600">{uniqueVisitorStats.monthly}</div>
                  <p className="text-sm text-green-600 mt-1">visitantes únicos nos últimos 30 dias</p>
                </div>
                
                <div className="bg-purple-50 border border-purple-100 p-4 rounded-lg">
                  <h3 className="text-lg font-semibold text-purple-800 mb-2">Este Ano</h3>
                  <div className="text-3xl font-bold text-purple-600">{uniqueVisitorStats.yearly}</div>
                  <p className="text-sm text-purple-600 mt-1">visitantes únicos nos últimos 365 dias</p>
                </div>
                
                <div className="bg-gray-50 border border-gray-100 p-4 rounded-lg">
                  <h3 className="text-lg font-semibold text-gray-800 mb-2">Total</h3>
                  <div className="text-3xl font-bold text-gray-700">{uniqueVisitorStats.total}</div>
                  <p className="text-sm text-gray-600 mt-1">visitantes únicos de todos os tempos</p>
                </div>
              </div>
            ) : (
              <div className="text-center py-4 text-gray-500">
                Não foi possível carregar as estatísticas de visitantes únicos
              </div>
            )}
          </CardContent>
        </Card>

        {/* Gráficos */}
        <Tabs defaultValue="bar">
          <TabsList className="grid w-full grid-cols-4 mb-6">
            <TabsTrigger value="bar">Top 10 Páginas</TabsTrigger>
            <TabsTrigger value="unique">Visitantes Únicos</TabsTrigger>
            <TabsTrigger value="category">Categorias</TabsTrigger>
            <TabsTrigger value="pie">Gráfico Pizza</TabsTrigger>
          </TabsList>
          
          <TabsContent value="bar" className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Top 10 Páginas Mais Visitadas</h2>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={top10Pages}
                  margin={{ top: 20, right: 30, left: 20, bottom: 120 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name" 
                    angle={-45} 
                    textAnchor="end" 
                    height={120}
                    interval={0}
                  />
                  <YAxis />
                  <RechartsTooltip 
                    formatter={(value: any) => [value, 'Visualizações']}
                    labelFormatter={(label: any, props: any) => {
                      const item = props[0]?.payload;
                      return item?.path || label;
                    }}
                  />
                  <Bar dataKey="visits" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          <TabsContent value="unique" className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Páginas com Visitantes Únicos</h2>
            {pagesWithUniqueVisitors.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-[400px] text-gray-500">
                <p className="text-lg">Nenhuma página com visitantes únicos registrados</p>
                <p className="text-sm mt-2">A contagem de IPs únicos começará a aparecer com novas visitas</p>
              </div>
            ) : (
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={pagesWithUniqueVisitors}
                    margin={{ top: 20, right: 30, left: 20, bottom: 120 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="name" 
                      angle={-45} 
                      textAnchor="end" 
                      height={120}
                      interval={0}
                    />
                    <YAxis />
                    <RechartsTooltip 
                      formatter={(value: any, name: any) => {
                        return [value, name === 'totalVisits' ? 'Visualizações Totais' : 'Visitantes Únicos'];
                      }}
                      labelFormatter={(label: any, props: any) => {
                        const item = props[0]?.payload;
                        return item?.path || label;
                      }}
                    />
                    <Legend formatter={(value) => value === 'totalVisits' ? 'Visualizações Totais' : 'Visitantes Únicos'} />
                    <Bar dataKey="totalVisits" name="totalVisits" fill="#3b82f6" />
                    <Bar dataKey="uniqueVisits" name="uniqueVisits" fill="#10b981" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="category" className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Visualizações por Categoria - Total vs Único</h2>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={categoryComparisonData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="name" 
                    angle={-45} 
                    textAnchor="end" 
                    height={80}
                    interval={0}
                  />
                  <YAxis />
                  <RechartsTooltip 
                    formatter={(value: any, name: any) => {
                      return [value, name === 'total' ? 'Visualizações Totais' : 'Visitantes Únicos'];
                    }}
                  />
                  <Legend formatter={(value) => value === 'total' ? 'Visualizações Totais' : 'Visitantes Únicos'} />
                  <Bar dataKey="total" name="total" fill="#3b82f6" />
                  <Bar dataKey="unique" name="unique" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
          
          <TabsContent value="pie" className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Visualizações por Categoria</h2>
            <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieChartData}
                    cx="50%"
                    cy="50%"
                    labelLine={true}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={150}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {pieChartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <RechartsTooltip formatter={(value: any) => [`${value} visualizações`, 'Quantidade']} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>
        </Tabs>

        {/* Tabela com dados detalhados */}
        <Card>
          <CardHeader>
            <CardTitle>Detalhamento de Visualizações por Página</CardTitle>
            <CardDescription>
              {filteredPageviews.length} {filteredPageviews.length === 1 ? 'página encontrada' : 'páginas encontradas'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Caminho</TableHead>
                  <TableHead className="text-right">Visualizações</TableHead>
                  <TableHead className="text-right">Visitantes Únicos</TableHead>
                  <TableHead className="text-right">Última Visita</TableHead>
                  <TableHead className="text-right">Primeira Visita</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedPageviews.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-4 text-gray-500">
                      Nenhuma visualização encontrada
                    </TableCell>
                  </TableRow>
                ) : (
                  sortedPageviews.map((pageview) => (
                    <TableRow key={pageview.id}>
                      <TableCell className="font-medium">
                        <div className="flex flex-col">
                          <span className="text-sm font-semibold">
                            {getPostTitle(pageview.path)}
                          </span>
                          <span className="text-xs text-gray-500 mt-1">
                            {pageview.path}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right">
                        <span className="font-bold text-blue-600">{pageview.count}</span>
                      </TableCell>
                      <TableCell className="text-right">
                        <span className="font-bold text-green-600">{pageview.uniqueCount}</span>
                      </TableCell>
                      <TableCell className="text-right">
                        {format(new Date(pageview.lastVisit), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                      </TableCell>
                      <TableCell className="text-right">
                        {format(new Date(pageview.createdAt), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}