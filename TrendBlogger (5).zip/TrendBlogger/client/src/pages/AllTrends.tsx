import { useState } from "react";
import { useTrends } from "@/hooks/useTrends";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import GeneratePostModal from "@/components/modals/GeneratePostModal";
import { Trend } from "@shared/schema";
import { RefreshCw, Sparkles, Calendar, Search, TrendingUp, Newspaper } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function AllTrends() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [refreshing, setRefreshing] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTrend, setSelectedTrend] = useState<string>("");
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);
  
  // Estados para seleção de período e modo de busca
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);
  const [searchMode, setSearchMode] = useState<'trends' | 'news'>('trends');

  // Usando o termo de busca como parte da query para o backend
  const { data: trends, isLoading, isRefetching } = useTrends(undefined, debouncedSearchTerm);

  // Debounce para a busca
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchTerm(value);
    
    // Cancela o timeout anterior se existir
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }
    
    // Define um novo timeout para fazer a busca depois de 500ms
    const timeout = setTimeout(() => {
      console.log(`Buscando por: "${value}"`);
      setDebouncedSearchTerm(value);
    }, 500);
    
    setSearchTimeout(timeout);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      // Se temos datas selecionadas, usamos elas
      // Caso contrário, calculamos baseado no período em dias
      let payload: any = {
        searchMode: searchMode
      };
      
      // Primeiro verificamos se temos ambas as datas definidas
      if (startDate && endDate) {
        payload.startDate = startDate.toISOString();
        payload.endDate = endDate.toISOString();
      } else {
        // Caso contrário, usamos um período padrão de 1 dia
        payload.searchPeriod = 1;
      }
      
      // Envia as datas selecionadas e o modo de busca para o backend
      await apiRequest("POST", "/api/trends/update", payload);
      
      queryClient.invalidateQueries({ queryKey: ["/api/trends"] });
      
      toast({
        title: searchMode === 'trends' ? "Tendências atualizadas" : "Notícias atualizadas",
        description: `Os ${searchMode === 'trends' ? 'tópicos em tendência' : 'tópicos de notícias'} foram atualizados com sucesso para o período selecionado.`,
      });
    } catch (error) {
      toast({
        title: `Erro ao atualizar ${searchMode === 'trends' ? 'tendências' : 'notícias'}`,
        description: `Ocorreu um erro ao atualizar os ${searchMode === 'trends' ? 'tópicos em tendência' : 'tópicos de notícias'}. Tente novamente.`,
        variant: "destructive",
      });
    } finally {
      setRefreshing(false);
    }
  };

  const handleGenerateFromTrend = (trend: Trend) => {
    console.log("Gerando post da tendência:", trend);
    setSelectedTrend(trend.title);
    console.log("Tendência selecionada:", trend.title);
    setIsModalOpen(true);
    console.log("Modal aberto:", true);
  };

  // Não precisamos mais filtrar os resultados, pois isso já é feito no servidor
  const filteredTrends = trends || [];

  return (
    <>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h1 className="text-2xl font-bold text-neutral-900 mb-4 md:mb-0">Tendências</h1>
        <div className="flex flex-col sm:flex-row gap-3">
          <Input
            placeholder="Buscar tendências..."
            value={searchTerm}
            onChange={handleSearchChange}
            className="w-full sm:w-64"
          />
          
          {/* Seletor de Data de Início */}
          <div className="flex items-center">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-[180px] justify-start text-left font-normal",
                    !startDate && "text-muted-foreground"
                  )}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {startDate ? (
                    format(startDate, "PPP", { locale: ptBR })
                  ) : (
                    <span>Data Inicial</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={startDate}
                  onSelect={setStartDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
          
          {/* Seletor de Data de Fim */}
          <div className="flex items-center">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-[180px] justify-start text-left font-normal",
                    !endDate && "text-muted-foreground"
                  )}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {endDate ? (
                    format(endDate, "PPP", { locale: ptBR })
                  ) : (
                    <span>Data Final</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={endDate}
                  onSelect={setEndDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
          
          <Button
            onClick={handleRefresh}
            disabled={refreshing || isRefetching}
            className="inline-flex items-center justify-center"
          >
            {refreshing || isRefetching ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Atualizando...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4 mr-2" />
                Atualizar {searchMode === 'trends' ? 'Tendências' : 'Notícias'}
              </>
            )}
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <CardTitle>{searchMode === 'trends' ? 'Tendências Atuais' : 'Notícias Atuais'}</CardTitle>
            
            {/* Seletor de Modo de Busca */}
            <Tabs defaultValue={searchMode} className="w-full sm:w-auto" onValueChange={(value) => setSearchMode(value as 'trends' | 'news')}>
              <TabsList className="grid w-full sm:w-[200px] grid-cols-2">
                <TabsTrigger value="trends" className="flex items-center">
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Tendências
                </TabsTrigger>
                <TabsTrigger value="news" className="flex items-center">
                  <Newspaper className="h-4 w-4 mr-2" />
                  Notícias
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
          
          <p className="text-sm text-muted-foreground">
            {searchMode === 'trends' 
              ? 'Tópicos em alta baseados em volume de busca no Google.'
              : 'Notícias recentes relevantes para o período selecionado.'}
          </p>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {Array(10)
                .fill(0)
                .map((_, i) => (
                  <div key={i} className="animate-pulse flex items-center justify-between p-3 border-b border-neutral-200">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 mr-3 text-neutral-500">
                        <div className="h-5 w-5 bg-neutral-200 rounded"></div>
                      </div>
                      <div className="space-y-1">
                        <div className="h-5 w-40 bg-neutral-200 rounded"></div>
                        <div className="h-3 w-20 bg-neutral-200 rounded"></div>
                      </div>
                    </div>
                    <div className="h-8 w-24 bg-neutral-200 rounded"></div>
                  </div>
                ))}
            </div>
          ) : filteredTrends.length > 0 ? (
            <div className="divide-y divide-neutral-200">
              {filteredTrends.map((trend: Trend) => (
                <div key={trend.id} className="flex items-center justify-between p-3 hover:bg-neutral-50">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 mr-3 text-neutral-500">
                      <span className="text-sm font-medium">#{trend.rank || "-"}</span>
                    </div>
                    <div>
                      <div className="text-sm font-medium text-primary-600">{trend.title}</div>
                      <div className="text-xs text-neutral-500">
                        {searchMode === 'trends' 
                          ? (trend.searchVolume ? `${trend.searchVolume} buscas` : '-')
                          : (trend.publishedAt ? `Publicado: ${trend.publishedAt}` : '-')}
                      </div>
                    </div>
                  </div>
                  <div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleGenerateFromTrend(trend)}
                      className="inline-flex items-center text-primary-700 bg-primary-100 hover:bg-primary-200 focus:ring-primary-500"
                    >
                      <Sparkles className="h-4 w-4 mr-1" />
                      Gerar Post
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-neutral-500">
              {searchTerm ? (
                <p>Nenhuma tendência encontrada com o termo "{searchTerm}".</p>
              ) : (
                <p>Nenhuma tendência encontrada. Tente atualizar.</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Generate Post Modal */}
      <GeneratePostModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        initialTrend={selectedTrend}
      />
    </>
  );
}
