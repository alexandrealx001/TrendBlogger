import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Sparkles, Newspaper, Lightbulb, Briefcase, Code, Heart, Globe, Coffee, Gamepad2 } from "lucide-react";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { useToast } from "@/hooks/use-toast";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

interface NewsItem {
  title: string;
  link: string;
  pubDate: string;
  source?: string;
}

interface Category {
  name: string;
  query: string;
  icon: React.ReactNode;
  color: string;
}

const NewsPage = () => {
  const [search, setSearch] = useState('');
  const [news, setNews] = useState<NewsItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [dateStart, setDateStart] = useState('');
  const [dateEnd, setDateEnd] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedNews, setSelectedNews] = useState<NewsItem | null>(null);
  const [generateOptions, setGenerateOptions] = useState({
    contentType: "Artigo informativo",
    seoOptimization: true,
    useRelatedKeywords: true,
    addMetaDescription: true,
    useRecentNews: true,
    findImage: true,
    wordCount: "medium",
    postAction: "draft"
  });
  
  const { toast } = useToast();
  
  // Categorias disponíveis para busca rápida
  const categories: Category[] = [
    { name: "Tecnologia", query: "tecnologia brasil", icon: <Code className="w-4 h-4" />, color: "bg-blue-100 text-blue-800 hover:bg-blue-200" },
    { name: "Negócios", query: "negócios brasil", icon: <Briefcase className="w-4 h-4" />, color: "bg-amber-100 text-amber-800 hover:bg-amber-200" },
    { name: "Saúde", query: "saúde brasil", icon: <Heart className="w-4 h-4" />, color: "bg-red-100 text-red-800 hover:bg-red-200" },
    { name: "Educação", query: "educação brasil", icon: <Lightbulb className="w-4 h-4" />, color: "bg-green-100 text-green-800 hover:bg-green-200" },
    { name: "Viagens", query: "viagem turismo brasil", icon: <Globe className="w-4 h-4" />, color: "bg-indigo-100 text-indigo-800 hover:bg-indigo-200" },
    { name: "Esportes", query: "esportes brasil", icon: <Gamepad2 className="w-4 h-4" />, color: "bg-orange-100 text-orange-800 hover:bg-orange-200" },
    { name: "Entretenimento", query: "entretenimento brasil", icon: <Coffee className="w-4 h-4" />, color: "bg-purple-100 text-purple-800 hover:bg-purple-200" },
  ];
  
  const carregarNoticias = async (categoryQuery?: string) => {
    setIsLoading(true);
    try {
      // Montar parâmetros de consulta
      const params: any = {
        query: categoryQuery || search || '',
        limit: 30
      };
      
      if (dateStart) params.dateStart = dateStart;
      if (dateEnd) params.dateEnd = dateEnd;
      
      // Usando a API que acabamos de criar
      const response = await axios.get('/api/news', { params });
      
      setNews(response.data);
      
      if (response.data.length === 0) {
        toast({
          title: "Nenhuma notícia encontrada",
          description: "Tente modificar os termos de busca ou o período.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Erro ao carregar notícias:", error);
      toast({
        title: "Erro ao carregar notícias",
        description: "Não foi possível obter notícias no momento. Tente novamente mais tarde.",
        variant: "destructive"
      });
      setNews([]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleCategoryClick = (category: Category) => {
    // Atualizar busca
    setSearch(category.query);
    setSelectedCategory(category.name);
    carregarNoticias(category.query);
  };
  
  // Função para gerar post a partir de uma notícia
  const generatePost = async (noticia: NewsItem) => {
    setIsGenerating(true);
    try {
      const response = await axios.post('/api/generate', {
        trend: noticia.title,
        contentType: generateOptions.contentType,
        seoOptimization: generateOptions.seoOptimization,
        useRelatedKeywords: generateOptions.useRelatedKeywords,
        addMetaDescription: generateOptions.addMetaDescription,
        useRecentNews: generateOptions.useRecentNews,
        findRelevantImage: generateOptions.findImage,
        wordCount: generateOptions.wordCount,
        postAction: generateOptions.postAction
      });
      
      toast({
        title: "Post gerado com sucesso!",
        description: `O post "${response.data.title}" foi ${generateOptions.postAction === 'publish' ? 'publicado' : 'salvo como rascunho'}.`,
        variant: "default"
      });
      
      // Fechar o diálogo
      setIsDialogOpen(false);
      
    } catch (error) {
      console.error("Erro ao gerar post:", error);
      toast({
        title: "Erro ao gerar post",
        description: "Não foi possível gerar o post. Tente novamente mais tarde.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };
  
  // Abrir diálogo para gerar post
  const openGenerateDialog = (noticia: NewsItem) => {
    setSelectedNews(noticia);
    setIsDialogOpen(true);
  };
  
  // Carregar notícias ao montar o componente
  useEffect(() => {
    carregarNoticias();
  }, []);
  
  // Formatar data para exibição
  const formatarData = (dateString: string): string => {
    try {
      return format(new Date(dateString), "dd 'de' MMMM 'de' yyyy, HH:mm", { locale: ptBR });
    } catch (error) {
      return dateString;
    }
  };
  
  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <h1 className="text-3xl font-bold">Notícias em Tempo Real</h1>
        <Button 
          variant="outline" 
          className="border-2 border-primary/50 hover:border-primary/80"
          onClick={() => carregarNoticias()}
        >
          <Sparkles className="mr-2 h-4 w-4 text-primary" />
          Atualizar Notícias
        </Button>
      </div>
      
      {/* Categorias */}
      <div className="flex flex-wrap gap-2 py-2">
        {categories.map((category) => (
          <Badge 
            key={category.name}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-full cursor-pointer ${
              selectedCategory === category.name ? "ring-2 ring-primary/80" : ""
            } ${category.color}`}
            onClick={() => handleCategoryClick(category)}
          >
            {category.icon}
            {category.name}
          </Badge>
        ))}
      </div>
      
      <div className="bg-muted/50 p-6 rounded-lg shadow-sm">
        <h2 className="text-xl font-semibold mb-4">Buscar Notícias</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="col-span-2">
            <Label htmlFor="busca">Termo de Busca</Label>
            <Input 
              id="busca" 
              placeholder="Digite o termo de busca..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full"
            />
          </div>
          
          <div>
            <Label htmlFor="dataInicio">Data Início</Label>
            <Input 
              id="dataInicio" 
              type="date" 
              value={dateStart}
              onChange={(e) => setDateStart(e.target.value)}
              className="w-full"
            />
          </div>
          
          <div>
            <Label htmlFor="dataFim">Data Fim</Label>
            <Input 
              id="dataFim" 
              type="date" 
              value={dateEnd}
              onChange={(e) => setDateEnd(e.target.value)}
              className="w-full"
            />
          </div>
        </div>
        
        <div className="mt-4 flex justify-end">
          <Button 
            onClick={() => carregarNoticias()}
            disabled={isLoading}
            className="bg-primary text-white px-6"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Buscando...
              </>
            ) : (
              <>
                <Newspaper className="mr-2 h-4 w-4" />
                Buscar Notícias
              </>
            )}
          </Button>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Resultados da Busca</h2>
          {selectedCategory && (
            <Badge variant="outline" className="px-3 py-1.5">
              Categoria: {selectedCategory}
              <button 
                className="ml-2 text-muted-foreground hover:text-foreground" 
                onClick={() => {
                  setSelectedCategory(null);
                  setSearch('');
                }}
              >
                ×
              </button>
            </Badge>
          )}
        </div>
        
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2 text-lg">Carregando notícias...</span>
          </div>
        ) : (
          <>
            {news.length === 0 ? (
              <p className="text-center py-12 text-muted-foreground">
                Nenhuma notícia encontrada. Tente modificar sua busca.
              </p>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {news.map((noticia, index) => (
                  <Card key={index} className="overflow-hidden">
                    <CardHeader className="bg-muted/30 pb-2">
                      <CardTitle className="text-lg line-clamp-2">
                        {noticia.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <p className="text-sm text-muted-foreground mb-2">
                        Fonte: {noticia.source || 'Google News'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Publicado em: {formatarData(noticia.pubDate)}
                      </p>
                    </CardContent>
                    <CardFooter className="bg-muted/20 pt-2 flex justify-between">
                      <a 
                        href={noticia.link} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary hover:underline text-sm"
                      >
                        Leia a notícia completa →
                      </a>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-xs border-primary/50 hover:border-primary" 
                        onClick={() => openGenerateDialog(noticia)}
                      >
                        <Sparkles className="mr-1 h-3 w-3 text-primary" />
                        Gerar Post
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            )}
          </>
        )}
      </div>
      
      {/* Dialog para geração de post */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>Gerar Post a partir da Notícia</DialogTitle>
            <DialogDescription>
              {selectedNews?.title}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="contentType">Tipo de Conteúdo</Label>
              <Select 
                value={generateOptions.contentType}
                onValueChange={(value) => setGenerateOptions({...generateOptions, contentType: value})}
              >
                <SelectTrigger id="contentType">
                  <SelectValue placeholder="Selecione o tipo de conteúdo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Artigo informativo">Artigo informativo</SelectItem>
                  <SelectItem value="Artigo de opinião">Artigo de opinião</SelectItem>
                  <SelectItem value="Tutorial">Tutorial</SelectItem>
                  <SelectItem value="Notícia">Notícia</SelectItem>
                  <SelectItem value="Análise de mercado">Análise de mercado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="wordCount">Tamanho do Post</Label>
              <Select
                value={generateOptions.wordCount}
                onValueChange={(value) => setGenerateOptions({...generateOptions, wordCount: value})}
              >
                <SelectTrigger id="wordCount">
                  <SelectValue placeholder="Selecione o tamanho" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="short">Curto (500 palavras)</SelectItem>
                  <SelectItem value="medium">Médio (800 palavras)</SelectItem>
                  <SelectItem value="long">Longo (1200 palavras)</SelectItem>
                  <SelectItem value="in-depth">Aprofundado (2000+ palavras)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="postAction">Ação após geração</Label>
              <Select
                value={generateOptions.postAction}
                onValueChange={(value) => setGenerateOptions({...generateOptions, postAction: value})}
              >
                <SelectTrigger id="postAction">
                  <SelectValue placeholder="Selecione a ação" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Salvar como Rascunho</SelectItem>
                  <SelectItem value="publish">Publicar Imediatamente</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="seoOptimization"
                checked={generateOptions.seoOptimization}
                onCheckedChange={(checked) => 
                  setGenerateOptions({...generateOptions, seoOptimization: !!checked})
                }
              />
              <Label htmlFor="seoOptimization">Otimizar para SEO</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="useRelatedKeywords"
                checked={generateOptions.useRelatedKeywords}
                onCheckedChange={(checked) => 
                  setGenerateOptions({...generateOptions, useRelatedKeywords: !!checked})
                }
              />
              <Label htmlFor="useRelatedKeywords">Usar palavras-chave relacionadas</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="addMetaDescription"
                checked={generateOptions.addMetaDescription}
                onCheckedChange={(checked) => 
                  setGenerateOptions({...generateOptions, addMetaDescription: !!checked})
                }
              />
              <Label htmlFor="addMetaDescription">Incluir meta descrição</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="useRecentNews"
                checked={generateOptions.useRecentNews}
                onCheckedChange={(checked) => 
                  setGenerateOptions({...generateOptions, useRecentNews: !!checked})
                }
              />
              <Label htmlFor="useRecentNews">Incluir informações recentes</Label>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox 
                id="findImage"
                checked={generateOptions.findImage}
                onCheckedChange={(checked) => 
                  setGenerateOptions({...generateOptions, findImage: !!checked})
                }
              />
              <Label htmlFor="findImage">Buscar imagem relacionada</Label>
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsDialogOpen(false)}
            >
              Cancelar
            </Button>
            <Button 
              onClick={() => selectedNews && generatePost(selectedNews)}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Gerando...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Gerar Post
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default NewsPage;