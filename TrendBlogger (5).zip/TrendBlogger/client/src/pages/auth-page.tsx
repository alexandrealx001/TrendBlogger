import { useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, LockKeyhole, User, Mail } from "lucide-react";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";

// Schema de validação para o formulário de login
const loginSchema = z.object({
  username: z.string().email({ message: "E-mail inválido" }),
  password: z.string().min(6, { message: "A senha deve ter pelo menos 6 caracteres" }),
});

type LoginFormData = z.infer<typeof loginSchema>;

export default function AuthPage() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  // Configuração do formulário com react-hook-form
  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onSubmit = async (data: LoginFormData) => {
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/login", data);
      const userData = await response.json();
      
      toast({
        title: "Login realizado com sucesso",
        description: `Bem-vindo, ${userData.username}!`,
      });
      
      // Redireciona para a página inicial após o login
      navigate("/");
    } catch (error) {
      toast({
        title: "Erro ao fazer login",
        description: "Credenciais inválidas. Por favor, tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-50 p-4">
      <div className="max-w-6xl w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        {/* Seção do formulário */}
        <Card className="w-full max-w-md mx-auto shadow-lg">
          <CardHeader className="space-y-1">
            <div className="flex items-center justify-center mb-2">
              <div className="w-10 h-10 rounded-md bg-primary flex items-center justify-center">
                <LockKeyhole className="h-6 w-6 text-white" />
              </div>
            </div>
            <CardTitle className="text-2xl text-center">Acesso ao Painel</CardTitle>
            <CardDescription className="text-center">
              Digite suas credenciais para acessar o painel administrativo
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Mail className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input 
                            placeholder="seu.email@exemplo.com" 
                            className="pl-10" 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Senha</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <User className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground" />
                          <Input 
                            type="password" 
                            placeholder="••••••••" 
                            className="pl-10" 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={isLoading}
                >
                  {isLoading ? "Entrando..." : "Entrar"}
                </Button>
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-sm text-muted-foreground">
              Acesso restrito a administradores
            </p>
          </CardFooter>
        </Card>

        {/* Seção Hero */}
        <div className="hidden md:flex flex-col items-start justify-center space-y-4">
          <div className="flex items-center space-x-2 mb-2">
            <div className="w-10 h-10 rounded-md bg-primary flex items-center justify-center">
              <Sparkles className="h-6 w-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold">BlogGen</h2>
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight">
            Geração de Conteúdo Inteligente
          </h1>
          <p className="text-xl text-neutral-600 max-w-md">
            Plataforma de criação automatizada de conteúdo baseada em tendências e otimizada para SEO.
          </p>
          <div className="grid grid-cols-2 gap-4 mt-6">
            <div className="bg-primary-50 p-4 rounded-lg border border-primary-100">
              <h3 className="font-medium text-primary-700 mb-1">Tendências</h3>
              <p className="text-sm text-neutral-600">
                Conteúdo baseado nas pesquisas mais populares do momento
              </p>
            </div>
            <div className="bg-primary-50 p-4 rounded-lg border border-primary-100">
              <h3 className="font-medium text-primary-700 mb-1">SEO</h3>
              <p className="text-sm text-neutral-600">
                Otimização automática para resultados de busca
              </p>
            </div>
            <div className="bg-primary-50 p-4 rounded-lg border border-primary-100">
              <h3 className="font-medium text-primary-700 mb-1">Imagens</h3>
              <p className="text-sm text-neutral-600">
                Seleção inteligente de imagens para o seu conteúdo
              </p>
            </div>
            <div className="bg-primary-50 p-4 rounded-lg border border-primary-100">
              <h3 className="font-medium text-primary-700 mb-1">Agendamento</h3>
              <p className="text-sm text-neutral-600">
                Automatize a publicação de conteúdo em horários estratégicos
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}