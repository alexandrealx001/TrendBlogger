import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useApiKeys } from "@/hooks/useApiKeys";
import { useToast } from "@/hooks/use-toast";
import ApiKeyForm from "@/components/settings/ApiKeyForm";
import { apiRequest } from "@/lib/queryClient";

export default function Settings() {
  const { data: apiKeys, isLoading } = useApiKeys();
  const { toast } = useToast();
  const [isFixingImages, setIsFixingImages] = useState(false);
  const [fixResult, setFixResult] = useState<{count: number, corrections: Array<{id: number, before: string, after: string}>} | null>(null);

  const getApiKeyByService = (service: string) => {
    if (!apiKeys) return undefined;
    return apiKeys.find((key: { service: string }) => key.service === service);
  };
  
  // Função para corrigir URLs de imagens
  const handleFixImageUrls = async () => {
    try {
      setIsFixingImages(true);
      setFixResult(null);
      
      const result = await apiRequest("POST", "/api/fix-images");
      
      toast({
        title: "Urls de imagens corrigidas",
        description: result.message || `${result.corrections?.length || 0} URLs de imagem foram corrigidas.`,
      });
      
      setFixResult({
        count: result.corrections?.length || 0,
        corrections: result.corrections || []
      });
    } catch (error) {
      console.error("Erro ao corrigir URLs:", error);
      toast({
        title: "Erro",
        description: "Não foi possível corrigir as URLs de imagens.",
        variant: "destructive"
      });
    } finally {
      setIsFixingImages(false);
    }
  };

  return (
    <>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-neutral-900">Configurações</h1>
        <p className="text-neutral-500 mt-1">
          Configure as chaves de API e preferências do sistema.
        </p>
      </div>

      <Tabs defaultValue="api-keys" className="w-full">
        <TabsList className="grid w-full grid-cols-3 md:w-[600px]">
          <TabsTrigger value="api-keys">Chaves de API</TabsTrigger>
          <TabsTrigger value="preferences">Preferências</TabsTrigger>
          <TabsTrigger value="maintenance">Manutenção</TabsTrigger>
        </TabsList>
        
        <TabsContent value="api-keys" className="space-y-6 mt-6">
          <ApiKeyForm
            apiKey={getApiKeyByService("openai")}
            service="openai"
            title="OpenAI API"
            description="API utilizada para geração de conteúdo de blog usando modelos como GPT-4o."
            placeholder="sk-..."
          />

          <ApiKeyForm
            apiKey={getApiKeyByService("google_search")}
            service="google_search"
            title="Google Search API"
            description="API utilizada para encontrar imagens relevantes para os posts de blog."
            placeholder="Insira sua chave da API Google Search..."
          />
        </TabsContent>
        
        <TabsContent value="preferences" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Preferências do Sistema</CardTitle>
              <CardDescription>Configure as preferências gerais do sistema de geração de conteúdo.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-neutral-500">
                As preferências do sistema serão implementadas em breve. Por enquanto, você pode configurar as preferências específicas para cada geração de post ou agendamento.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="maintenance" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Manutenção do Sistema</CardTitle>
              <CardDescription>Ferramentas de manutenção para corrigir problemas no sistema.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="border-b pb-6">
                <h3 className="text-lg font-medium mb-2">Correção de URLs de Imagens</h3>
                <p className="text-neutral-500 mb-4">
                  Corrige URLs de imagens do Unsplash que podem estar malformadas no banco de dados. 
                  Isso resolve problemas onde imagens do Unsplash não estão sendo exibidas corretamente 
                  devido à falta de parâmetros de qualidade ou formatação inadequada.
                </p>
                <Button 
                  onClick={handleFixImageUrls} 
                  disabled={isFixingImages}
                  className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
                >
                  {isFixingImages ? (
                    <>
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Corrigindo URLs...
                    </>
                  ) : (
                    "Corrigir URLs de Imagens"
                  )}
                </Button>
                
                {fixResult && (
                  <div className="mt-4">
                    <p className="text-sm text-neutral-700 mb-2">
                      {fixResult.count === 0 ? (
                        "Todas as URLs já estão corretas. Nenhuma correção foi necessária."
                      ) : (
                        `${fixResult.count} URLs foram corrigidas com sucesso.`
                      )}
                    </p>
                    
                    {fixResult.count > 0 && (
                      <div className="bg-neutral-50 p-3 rounded-md mt-3 max-h-60 overflow-y-auto">
                        <h4 className="text-sm font-medium mb-2">Correções realizadas:</h4>
                        <ul className="space-y-3 text-xs">
                          {fixResult.corrections.map((correction, index) => (
                            <li key={index} className="border-b pb-2">
                              <p className="font-medium">Post ID: {correction.id}</p>
                              <p className="text-red-600 truncate">Antes: {correction.before}</p>
                              <p className="text-green-600 truncate">Depois: {correction.after}</p>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}
