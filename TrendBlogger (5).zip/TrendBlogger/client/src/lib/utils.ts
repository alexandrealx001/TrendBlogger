import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Formata uma data para exibição amigável
 */
export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  }).format(date);
}

/**
 * Corrige URLs de imagens para garantir que sejam exibidas corretamente na aplicação.
 * Processa diferentes formatos de URL de várias fontes e lida com problemas de acesso geográfico.
 * 
 * @param url URL da imagem que pode precisar de correção
 * @returns URL corrigida ou a URL original se não precisar de correção
 */
export function fixImageUrl(url: string | null | undefined): string {
  // URLs de fallback seguras caso nenhuma imagem esteja disponível
  // Usando várias opções para aumentar a chance de pelo menos uma estar acessível
  // Incluindo URLs mais confiáveis para acesso no Brasil
  const fallbackUrls = [
    // Unsplash - geralmente confiável no Brasil
    "https://images.unsplash.com/photo-1432821596592-e2c18b78144f?q=85&w=1200&auto=format&fit=crop",
    "https://images.unsplash.com/photo-1507679799987-c73779587ccf?q=85&w=1200&auto=format&fit=crop", 
    // Pixabay - pode ter problemas mas inclui vários mirrors
    "https://cdn.pixabay.com/photo/2016/02/03/08/32/banner-1176676_1280.jpg",
    "https://i.pixabay.com/photo/2015/01/21/13/20/business-606807_1280.jpg",
    // Pexels - bom histórico de acesso no Brasil
    "https://images.pexels.com/photos/952670/pexels-photo-952670.jpeg?auto=compress&cs=tinysrgb&w=1200",
    "https://images.pexels.com/photos/590041/pexels-photo-590041.jpeg?auto=compress&cs=tinysrgb&w=1200",
    // Wikimedia - super estável globalmente
    "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3f/Article_icon.svg/1200px-Article_icon.svg.png",
    // CDN brasileiro (hostada no Brasil)
    "https://noticias.r7.com/prisma/arquivo/assets/imagens/generic_news.jpg"
  ];
  
  const randomFallback = () => {
    // Selecionar aleatoriamente uma imagem fallback
    const index = Math.floor(Math.random() * fallbackUrls.length);
    return fallbackUrls[index];
  };
  
  // Se a URL estiver vazia, retorna uma imagem de fallback
  if (!url || url.trim() === '') return randomFallback();
  
  try {
    // Lista de espelhos de imagem para serviços conhecidos com problemas geográficos
    const imageMirrors = {
      // Pixabay - serviço que frequentemente tem problemas no Brasil
      "cdn.pixabay.com": [
        (id: string) => `https://cdn.pixabay.com/photo/${id}`,
        (id: string) => `https://pixabay.com/get/${id}`,
        (id: string) => `https://i.pixabay.com/photo/${id}`
      ],
      // Unsplash - ocasionalmente tem problemas em alguns provedores no Brasil
      "images.unsplash.com": [
        (id: string) => `https://images.unsplash.com/${id}`,
        (id: string) => `https://unsplash.com/photos/${id.split('/')[1]}` // Formato alternativo
      ]
    };
    
    // Função para tentar espelhos alternativos para domínios conhecidos com problemas de acesso
    const tryMirrors = (url: string): string => {
      try {
        const parsedUrl = new URL(url);
        
        // Para Pixabay tentamos espelhos alternativos
        if (parsedUrl.hostname === 'cdn.pixabay.com') {
          // Extrai o caminho após /photo/
          const match = parsedUrl.pathname.match(/\/photo\/(.*)/);
          if (match && match[1]) {
            const photoPath = match[1];
            // Retorna a URL do espelho original, mas guarda os mirros como atributos data-
            // para que o frontend possa tentar alternativas se a imagem não carregar
            const mirrorUrls = imageMirrors['cdn.pixabay.com'].map(fn => fn(photoPath));
            
            // Adiciona dados de espelhos como atributos data-mirror-X
            // (serão usados no frontend via JavaScript)
            console.log('Espelhos disponíveis:', mirrorUrls);
            return url; // Mantém a URL original com os mirros como alternativas
          }
        }
        
        // Para Unsplash, também tentamos URLs alternativas
        else if (parsedUrl.hostname === 'images.unsplash.com') {
          // Formato URL: images.unsplash.com/photo-123456789
          const match = parsedUrl.pathname.match(/\/(photo-\d+)/);
          if (match && match[1]) {
            const photoId = match[1];
            console.log('ID de foto Unsplash:', photoId);
            return url; // Mantém a URL original, os componentes tratarão os errors
          }
        }
        
        return url; // Se não tiver espelhos, retorna a URL original
      } catch (e) {
        return url;
      }
    };
    
    // Se é uma URL do Unsplash
    if (url.includes('images.unsplash.com')) {
      // Verifica o formato básico da URL
      const unsplashPattern = /images\.unsplash\.com\/photo-\d+/;
      if (!unsplashPattern.test(url)) {
        console.warn("URL do Unsplash inválida:", url);
        return randomFallback();
      }
      
      // Extrai a parte base da URL (antes dos parâmetros)
      let baseUrl = url;
      if (url.includes('?')) {
        baseUrl = url.split('?')[0];
      }
      
      // Tenta usar espelhos se disponíveis primeiro
      tryMirrors(url);
      
      // Adiciona os parâmetros necessários
      return `${baseUrl}?q=85&w=1200&auto=format&fit=crop`;
    }
    
    // Se é uma URL do Pixabay
    if (url.includes('pixabay.com')) {
      try {
        // Garante que seja uma URL válida
        new URL(url);
        // Tenta usar espelhos se disponíveis
        return tryMirrors(url);
      } catch (e) {
        console.warn("URL do Pixabay inválida:", url);
        return randomFallback();
      }
    }
    
    // Se é uma URL do Pexels (outra fonte comum para imagens de alta qualidade)
    if (url.includes('pexels.com')) {
      try {
        // Garante que seja uma URL válida
        new URL(url);
        
        // Garante parâmetros corretos para a URL do Pexels
        if (!url.includes('auto=compress')) {
          if (url.includes('?')) {
            return `${url}&auto=compress&cs=tinysrgb&w=1200`;
          } else {
            return `${url}?auto=compress&cs=tinysrgb&w=1200`;
          }
        }
        
        return url;
      } catch (e) {
        console.warn("URL do Pexels inválida:", url);
        return randomFallback();
      }
    }
    
    // Se é uma URL do Google APIs (incluindo Google Images)
    if (url.includes('googleapis.com') || url.includes('googleusercontent.com')) {
      try {
        // Garante que seja uma URL válida
        new URL(url);
        return url; // URLs do Google geralmente já são bem formadas
      } catch (e) {
        console.warn("URL do Google inválida:", url);
        return randomFallback();
      }
    }
    
    // Para qualquer outra URL que comece com http/https
    if (url.startsWith('http')) {
      try {
        // Verifica se é uma URL válida
        new URL(url);
        return url; // retorna como está se for válida
      } catch (e) {
        console.warn("URL inválida:", url);
        return randomFallback();
      }
    }
    
    // Se chegou aqui, a URL não é reconhecível, usa fallback
    console.warn("URL não reconhecida como válida:", url);
    return randomFallback();
  } catch (error) {
    console.error("Erro ao processar URL de imagem:", error);
    return randomFallback();
  }
}
