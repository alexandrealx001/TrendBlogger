import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { 
  getAuth, 
  signInWithPopup,
  GoogleAuthProvider,
  signOut as firebaseSignOut
} from "firebase/auth";

// Configuração do Firebase
const firebaseConfig = {
  apiKey: "AIzaSyDBkxQQbYL1fbVAz6OJgngMQGp6CtQWQog",
  authDomain: "produtos-com-estilo.firebaseapp.com",
  projectId: "produtos-com-estilo",
  storageBucket: "produtos-com-estilo.firebasestorage.app",
  messagingSenderId: "23829631157",
  appId: "1:23829631157:web:353364d280919209f6eefc",
  measurementId: "G-FLK2S1L8RN"
};

// Inicialização do Firebase
const app = initializeApp(firebaseConfig);

// Inicialização do Analytics
const analytics = getAnalytics(app);

// Provedor de autenticação Google
export const googleProvider = new GoogleAuthProvider();

// Auth instância
export const auth = getAuth(app);

// Removido a função getGoogleRedirectResult pois estamos usando popup em vez de redirecionamento

// Funções de autenticação
export const signInWithGoogle = async () => {
  try {
    console.log("Iniciando processo de login Google");
    
    // Adicionando escopo para acesso ao e-mail e perfil
    googleProvider.addScope('email');
    googleProvider.addScope('profile');
    
    // Definindo configurações adicionais para melhor experiência
    googleProvider.setCustomParameters({
      prompt: 'select_account',
      login_hint: 'user@gmail.com'
    });
    
    console.log("Iniciando autenticação Google, por favor aguarde...");
    
    // Abrir o popup diretamente, sem timer
    try {
      // Usando popup para autenticação
      const result = await signInWithPopup(auth, googleProvider);
      console.log("Login com Google concluído com sucesso:", result.user);
      return result.user;
    } catch (error: any) {
      // Corrigindo o tipo do erro
      if (error?.code === 'auth/popup-closed-by-user') {
        console.log("Popup foi fechado pelo usuário");
        alert("A janela de login foi fechada. Por favor, tente novamente e mantenha a janela aberta até concluir o login.");
      } else if (error?.code === 'auth/popup-blocked') {
        alert("O popup foi bloqueado pelo navegador. Por favor, permita popups para este site e tente novamente.");
        console.error("Popup bloqueado pelo navegador:", error);
      } else {
        console.error("Erro ao autenticar com Google:", error);
        alert("Ocorreu um erro durante a autenticação. Por favor, tente novamente.");
      }
      // Em caso de erro, retornamos null
      return null;
    }
  } catch (error: any) {
    console.error("Erro durante login Google:", error);
    alert("Ocorreu um erro inesperado. Por favor, tente novamente mais tarde.");
    throw error;
  }
};

export const signOut = async () => {
  try {
    await firebaseSignOut(auth);
  } catch (error: any) {
    console.error("Erro durante logout:", error);
    throw error;
  }
};