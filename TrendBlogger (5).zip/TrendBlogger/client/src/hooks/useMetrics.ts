import { useQuery } from "@tanstack/react-query";

interface Metrics {
  totalPosts: number;
  publishedPosts: number;
  processTrends: number;
  activeSchedules: number;
}

export function useMetrics() {
  return useQuery<Metrics>({
    queryKey: ["/api/metrics"],
    queryFn: async () => {
      return fetch("/api/metrics", { credentials: "include" }).then((res) => {
        if (!res.ok) throw new Error("Failed to fetch metrics");
        return res.json();
      });
    }
  });
}
