import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { Visitor } from '@/types';
import { useToast } from '@/hooks/use-toast';

export function useVisitors() {
  const { toast } = useToast();

  // Buscar todos os visitantes
  const {
    data: visitors = [],
    isLoading,
    error,
  } = useQuery<Visitor[]>({
    queryKey: ['/api/visitors'],
    enabled: true,
  });

  // Deletar um visitante
  const deleteVisitorMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest('DELETE', `/api/visitors/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/visitors'] });
      toast({
        title: 'Sucesso',
        description: 'Visitante excluído com sucesso',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Erro',
        description: `Falha ao excluir visitante: ${error.message}`,
        variant: 'destructive',
      });
    },
  });

  // Estatísticas básicas
  const getVisitorStats = () => {
    if (!visitors) return { total: 0, lastWeek: 0, today: 0 };

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const lastWeek = new Date(now);
    lastWeek.setDate(now.getDate() - 7);

    return {
      total: visitors.length,
      lastWeek: visitors.filter(
        (v: Visitor) => v.lastLogin && new Date(v.lastLogin) >= lastWeek
      ).length,
      today: visitors.filter(
        (v: Visitor) => v.lastLogin && new Date(v.lastLogin) >= today
      ).length,
    };
  };

  return {
    visitors,
    isLoading,
    error,
    deleteVisitor: deleteVisitorMutation.mutate,
    isDeleting: deleteVisitorMutation.isPending,
    getVisitorStats,
  };
}