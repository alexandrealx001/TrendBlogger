import { useQuery } from "@tanstack/react-query";
import { Trend } from "@shared/schema";

export function useTrends(limit?: number, search?: string) {
  return useQuery<Trend[]>({
    queryKey: ["/api/trends", { limit, search }],
    queryFn: async ({ queryKey }) => {
      const [_, params] = queryKey as [string, { limit?: number, search?: string }];
      
      let url = "/api/trends";
      const queryParams = [];
      
      if (params.limit) {
        queryParams.push(`limit=${params.limit}`);
      }
      
      if (params.search && params.search.trim() !== '') {
        queryParams.push(`search=${encodeURIComponent(params.search.trim())}`);
      }
      
      if (queryParams.length > 0) {
        url += `?${queryParams.join('&')}`;
      }
      
      console.log(`Buscando tendências: ${url}`);
      
      return fetch(url, { credentials: "include" }).then((res) => {
        if (!res.ok) throw new Error("Failed to fetch trends");
        return res.json();
      });
    },
    refetchOnWindowFocus: false, // Evita refetching automático em cada foco na janela
    staleTime: 30000, // Cache por 30 segundos
    enabled: search === undefined || search === null || search.trim().length >= 2 || search.trim() === ''
  });
}
