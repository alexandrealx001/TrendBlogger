import { useQuery } from "@tanstack/react-query";
import { Post } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export function useBlogPosts(category?: string) {
  return useQuery({
    queryKey: ["blog-posts", category],
    queryFn: async () => {
      try {
        const params = new URLSearchParams();
        params.append("status", "published");
        
        if (category && category !== "all") {
          params.append("category", category);
        }
        
        console.log("Buscando posts publicados:", `/api/posts?${params.toString()}`);
        const response = await apiRequest("GET", `/api/posts?${params.toString()}`);
        console.log("Resposta da API de posts:", response);
        
        // Garante que o retorno seja sempre um array
        if (Array.isArray(response)) {
          console.log(`Posts encontrados: ${response.length}`);
          return response;
        } else {
          console.warn("A resposta da API não é um array", response);
          return [];
        }
      } catch (error) {
        console.error("Erro ao buscar posts do blog:", error);
        return [];
      }
    }
  });
}

export function useBlogPost(id?: number) {
  return useQuery({
    queryKey: ["blog-post", id],
    queryFn: async () => {
      try {
        if (!id) return null;
        
        console.log(`Buscando post específico: ID ${id}`);
        const response = await apiRequest("GET", `/api/posts/${id}`);
        console.log(`Resposta do post ${id}:`, response);
        
        // Verifica se o post é válido e está publicado
        if (response && typeof response === 'object' && response.status === "published") {
          return response as Post;
        } else {
          console.warn("Post não encontrado ou não publicado:", response);
          return null;
        }
      } catch (error) {
        console.error("Erro ao buscar post do blog:", error);
        return null;
      }
    },
    enabled: !!id
  });
}

// Função para categorizar os posts baseado nas palavras-chave e categoria atribuída
export function categorizePosts(posts: Post[]): Record<string, Post[]> {
  const result: Record<string, Post[]> = {
    tecnologia: [],
    negocios: [],
    financas: [],
    saude: [],
    politica: [],
    esportes: [],
    sustentabilidade: [],
    educacao: []
  };

  const categoryKeywords: Record<string, string[]> = {
    tecnologia: ["tecnologia", "digital", "software", "app", "programação", "computação", "ia", "inteligência artificial", "chatgpt", "5g", "iot"],
    negocios: ["negócios", "empresa", "empreendedorismo", "startups", "mercado", "corporativo", "economia"],
    financas: ["finanças", "dinheiro", "investimento", "banco", "pix", "criptomoedas", "financeiro", "economia"],
    saude: ["saúde", "bem-estar", "médico", "medicina", "hospital", "clínica", "tratamento", "doença", "covid", "lipodistrofia"],
    politica: ["política", "governo", "eleição", "congresso", "lei", "legislação", "democracia", "voto"],
    esportes: ["esporte", "futebol", "copa", "olimpíada", "jogo", "atletismo", "atleta", "competição", "campeonato"],
    sustentabilidade: ["sustentabilidade", "meio ambiente", "clima", "ecologia", "verde", "biodiversidade", "natureza"],
    educacao: ["educação", "escola", "universidade", "faculdade", "ensino", "aprendizado", "professor", "aluno"]
  };

  posts.forEach(post => {
    // Primeiro, verificamos se o post já tem uma categoria válida atribuída
    if (post.category && result.hasOwnProperty(post.category)) {
      result[post.category].push(post);
      return; // Se já tem categoria, não precisamos fazer mais nada
    }
    
    // Se não tem categoria, tentamos classificar pelas palavras-chave
    let categorized = false;
    
    if (post.keywords && post.keywords.length > 0) {
      for (const [category, keywords] of Object.entries(categoryKeywords)) {
        const hasMatchingKeyword = post.keywords.some(postKeyword => 
          keywords.some(categoryKeyword => 
            postKeyword.toLowerCase().includes(categoryKeyword.toLowerCase())
          )
        );
        
        if (hasMatchingKeyword) {
          result[category].push(post);
          categorized = true;
          break;
        }
      }
    }
    
    // Se ainda não foi categorizado, coloca em tecnologia (categoria padrão) em vez de geral
    if (!categorized) {
      console.log("Post sem categoria identificada, atribuindo à tecnologia:", post.title);
      result.tecnologia.push(post);
    }
  });

  return result;
}

export function getRecentPosts(posts: Post[], limit = 5): Post[] {
  return [...posts].sort((a, b) => {
    // Tratamento de datas que podem ser nulas
    const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    return dateB - dateA;
  }).slice(0, limit);
}