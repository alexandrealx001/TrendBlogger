import { useQuery, useMutation, UseQueryResult } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export interface User {
  id: number;
  username: string;
  name?: string | null;
  role?: string | null;
  active?: boolean | null;
  createdAt?: Date | null;
}

interface CreateUserData {
  username: string;
  password: string;
  name?: string;
  role?: string;
  active?: boolean;
}

interface UpdateUserData {
  name?: string;
  role?: string;
  active?: boolean;
  password?: string;
}

// Hook para obter todos os usuários
export function useUsers(): UseQueryResult<User[], Error> {
  return useQuery<User[], Error>({
    queryKey: ['/api/users'],
    staleTime: 5 * 60 * 1000, // 5 minutos
  });
}

// Hook para criar um novo usuário
export function useCreateUser() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (userData: CreateUserData) => {
      const res = await apiRequest("POST", "/api/users", userData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Usuário criado",
        description: "O novo usuário foi criado com sucesso.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao criar usuário",
        description: error.message || "Houve um problema ao criar o usuário.",
        variant: "destructive",
      });
    },
  });
}

// Hook para atualizar um usuário existente
export function useUpdateUser() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async ({ id, userData }: { id: number, userData: UpdateUserData }) => {
      try {
        // Usando fetch diretamente para poder verificar se a resposta vem como esperado
        const response = await fetch(`/api/users/${id}`, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(userData),
          credentials: 'include'
        });
        
        if (!response.ok) {
          const errorData = await response.text();
          console.error('Erro na resposta:', response.status, errorData);
          throw new Error(errorData || 'Erro ao atualizar usuário');
        }
        
        return await response.json();
      } catch (err) {
        console.error('Erro na requisição:', err);
        throw err;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Usuário atualizado",
        description: "As informações do usuário foram atualizadas com sucesso.",
      });
    },
    onError: (error: Error) => {
      console.error('Erro na mutação:', error);
      toast({
        title: "Erro ao atualizar usuário",
        description: error.message || "Houve um problema ao atualizar o usuário.",
        variant: "destructive",
      });
    },
  });
}

// Hook para excluir um usuário
export function useDeleteUser() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/users/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "Usuário excluído",
        description: "O usuário foi removido com sucesso.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao excluir usuário",
        description: error.message || "Houve um problema ao excluir o usuário.",
        variant: "destructive",
      });
    },
  });
}