import { useQuery, useMutation } from "@tanstack/react-query";
import { ApiKey } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

export function useApiKeys() {
  return useQuery<ApiKey[]>({
    queryKey: ["/api/settings/api-keys"],
    queryFn: async () => {
      return fetch("/api/settings/api-keys", { credentials: "include" }).then((res) => {
        if (!res.ok) throw new Error("Failed to fetch API keys");
        return res.json();
      });
    }
  });
}

export function useCreateApiKey() {
  return useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/settings/api-keys", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/api-keys"] });
    }
  });
}

export function useUpdateApiKey() {
  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      const response = await apiRequest("PATCH", `/api/settings/api-keys/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/api-keys"] });
    }
  });
}
