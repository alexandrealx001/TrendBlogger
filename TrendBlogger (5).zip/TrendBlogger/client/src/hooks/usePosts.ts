import { useQuery } from "@tanstack/react-query";
import { Post } from "@shared/schema";

interface PostsParams {
  limit?: number;
  status?: string;
}

export function usePosts(limit?: number, status?: string) {
  return useQuery<Post[]>({
    queryKey: ["/api/posts", { limit, status }],
    queryFn: async ({ queryKey }) => {
      const [_, params] = queryKey as [string, PostsParams];
      
      let url = "/api/posts";
      const queryParams = [];
      
      if (params.limit) {
        queryParams.push(`limit=${params.limit}`);
      }
      
      if (params.status && params.status !== 'all') {
        queryParams.push(`status=${params.status}`);
      }
      
      if (queryParams.length > 0) {
        url += `?${queryParams.join("&")}`;
      }
      
      return fetch(url, { credentials: "include" }).then((res) => {
        if (!res.ok) throw new Error("Failed to fetch posts");
        return res.json();
      });
    }
  });
}

export function usePost(id?: number) {
  return useQuery<Post>({
    queryKey: ["/api/posts", id],
    queryFn: async ({ queryKey }) => {
      const [_, postId] = queryKey;
      
      if (!postId) {
        throw new Error("Post ID is required");
      }
      
      return fetch(`/api/posts/${postId}`, { credentials: "include" }).then((res) => {
        if (!res.ok) throw new Error("Failed to fetch post");
        return res.json();
      });
    },
    enabled: !!id
  });
}
