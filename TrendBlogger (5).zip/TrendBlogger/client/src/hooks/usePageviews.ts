import { useQuery } from "@tanstack/react-query";
import { toast } from "@/hooks/use-toast";
import { getQueryFn } from "@/lib/queryClient";
import axios from "axios";

export type Pageview = {
  id: number;
  path: string;
  count: number;
  uniqueCount: number;
  lastVisit: string;
  createdAt: string;
};

export function usePageviews() {
  const {
    data: pageviews,
    isLoading,
    error,
    refetch,
  } = useQuery<Pageview[]>({
    queryKey: ["/api/pageviews"],
    queryFn: async () => {
      try {
        const response = await axios.get('/api/pageviews', { 
          withCredentials: true 
        });
        return response.data;
      } catch (error) {
        if (axios.isAxiosError(error)) {
          if (error.response?.status === 401) {
            toast({
              title: "Acesso negado",
              description: "Você precisa estar autenticado para acessar essas estatísticas.",
              variant: "destructive",
            });
          } else {
            toast({
              title: "Erro ao carregar estatísticas",
              description: error.response?.data?.message || "Erro ao buscar estatísticas de visualização",
              variant: "destructive",
            });
          }
        }
        throw error;
      }
    },
    staleTime: 1000 * 60, // 1 minuto
    retry: 1,
  });

  return {
    pageviews: pageviews || [],
    isLoading,
    error,
    refetch,
  };
}