import { useQuery, useMutation } from "@tanstack/react-query";
import { Schedule } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

export function useSchedules() {
  return useQuery<Schedule[]>({
    queryKey: ["/api/schedules"],
    queryFn: async () => {
      console.log("Buscando agendamentos...");
      return fetch("/api/schedules", { credentials: "include" }).then((res) => {
        if (!res.ok) throw new Error("Failed to fetch schedules");
        return res.json().then(data => {
          console.log("Agendamentos recebidos:", data);
          return data;
        });
      });
    }
  });
}

export function useCreateSchedule() {
  return useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/schedules", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
    }
  });
}

export function useUpdateSchedule() {
  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: any }) => {
      return await apiRequest("PATCH", `/api/schedules/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
    }
  });
}

export function useDeleteSchedule() {
  return useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/schedules/${id}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/schedules"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
    }
  });
}
