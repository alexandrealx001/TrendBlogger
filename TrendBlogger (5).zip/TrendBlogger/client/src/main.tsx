import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Set title
document.title = "BlogGen - Automated Blog Post Generator";

// Add meta tags
const meta = document.createElement('meta');
meta.name = 'description';
meta.content = 'Generate SEO-optimized blog posts automatically based on trending topics.';
document.head.appendChild(meta);

createRoot(document.getElementById("root")!).render(<App />);
