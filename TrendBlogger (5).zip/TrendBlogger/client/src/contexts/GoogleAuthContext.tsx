import { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, signOut } from '@/lib/firebase';
import { getRedirectResult } from 'firebase/auth';
import { apiRequest } from '@/lib/queryClient';
import { User, Visitor } from '@/types';
import axios from 'axios';

// Definição do contexto
interface GoogleAuthContextProps {
  currentUser: User | null;
  visitor: Visitor | null;
  isLoading: boolean;
  signIn: () => Promise<void>;
  logOut: () => Promise<void>;
}

// Valor padrão do contexto
const defaultContext: GoogleAuthContextProps = {
  currentUser: null,
  visitor: null,
  isLoading: true,
  signIn: async () => {},
  logOut: async () => {},
};

// Criação do contexto
const GoogleAuthContext = createContext<GoogleAuthContextProps>(defaultContext);

// Hook para usar o contexto
export const useGoogleAuth = () => useContext(GoogleAuthContext);

// Props do provedor
interface GoogleAuthProviderProps {
  children: ReactNode;
}

// Provedor do contexto
export const GoogleAuthProvider = ({ children }: GoogleAuthProviderProps) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [visitor, setVisitor] = useState<Visitor | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Não precisamos mais verificar resultados de redirecionamento pois estamos usando popup
  useEffect(() => {
    console.log("Inicializando contexto de autenticação Google");
    setIsLoading(false);
  }, []);
  
  // Efeito para observar mudanças no estado de autenticação do Firebase
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user);
      setIsLoading(false);

      // Se o usuário estiver autenticado, buscar ou criar o visitante
      if (user) {
        handleAuthenticatedUser(user);
      } else {
        setVisitor(null);
      }
    });

    return () => unsubscribe();
  }, []);

  // Função para lidar com usuário autenticado no Firebase
  const handleAuthenticatedUser = async (user: FirebaseUser) => {
    try {
      // Buscar visitante pelo googleId
      const response = await axios.get(`/api/visitors/google/${user.uid}`);
      const existingVisitor = response.data;
      setVisitor(existingVisitor);

      // Atualizar informações de login
      await axios.patch(`/api/visitors/${existingVisitor.id}/login`);
    } catch (error) {
      // Se o visitante não existir, criar um novo
      if (axios.isAxiosError(error) && error.response?.status === 404) {
        await saveVisitorToDatabase(user);
      } else {
        console.error('Erro ao processar usuário autenticado:', error);
      }
    }
  };

  // Função para salvar visitante no banco de dados
  const saveVisitorToDatabase = async (user: FirebaseUser) => {
    try {
      // Dados para criar o visitante
      const visitorData = {
        googleId: user.uid,
        email: user.email || '',
        name: user.displayName,
        photoUrl: user.photoURL,
      };

      // Criar o visitante
      const response = await axios.post('/api/visitors', visitorData);
      setVisitor(response.data);
    } catch (error) {
      console.error('Erro ao salvar visitante:', error);
    }
  };

  // Função para realizar login - não precisamos fazer nada aqui
  // O login será feito diretamente pelo botão usando signInWithRedirect
  const signIn = async () => {
    console.log("Função signIn do contexto chamada");
    setIsLoading(true);
    
    // O método signInWithRedirect está sendo chamado diretamente no componente do botão
    // Aqui apenas controlamos o estado de loading
    
    // Vamos verificar se há algum resultado de redirecionamento pendente
    try {
      const result = await getRedirectResult(auth);
      
      if (result) {
        console.log("Redirecionamento concluído com sucesso:", result.user);
        // O usuário já será processado pelo listener onAuthStateChanged
      } else {
        console.log("Nenhum resultado de redirecionamento pendente");
      }
    } catch (error) {
      console.error("Erro ao processar resultado de redirecionamento:", error);
    } finally {
      // Desativar o estado de carregamento
      setIsLoading(false);
    }
  };

  // Função para realizar logout
  const logOut = async () => {
    setIsLoading(true);
    try {
      await signOut();
      setVisitor(null);
    } finally {
      setIsLoading(false);
    }
  };

  // Valor do contexto
  const value: GoogleAuthContextProps = {
    currentUser,
    visitor,
    isLoading,
    signIn,
    logOut,
  };

  // Renderização do provedor
  return (
    <GoogleAuthContext.Provider value={value}>
      {children}
    </GoogleAuthContext.Provider>
  );
};