import React, { createContext, useState, useContext, ReactNode } from 'react';

/**
 * Definição do tipo de contexto para login
 */
export type LoginContextType = {
  isLoginModalOpen: boolean;
  openLoginModal: (initialTab?: string) => void;
  closeLoginModal: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
};

// Valor padrão para evitar undefined
const defaultLoginContext: LoginContextType = {
  isLoginModalOpen: false,
  openLoginModal: () => {},
  closeLoginModal: () => {},
  activeTab: 'login',
  setActiveTab: () => {},
};

// Criação do contexto com valor padrão
export const LoginContext = createContext<LoginContextType>(defaultLoginContext);

/**
 * Provider do contexto de login
 */
export function LoginProvider({ children }: { children: ReactNode }) {
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('login');

  // Função para abrir o modal de login com a aba especificada
  const openLoginModal = (initialTab: string = 'login') => {
    setActiveTab(initialTab);
    setIsLoginModalOpen(true);
  };

  // Função para fechar o modal de login
  const closeLoginModal = () => {
    setIsLoginModalOpen(false);
  };

  // Valor do contexto
  const contextValue: LoginContextType = {
    isLoginModalOpen,
    openLoginModal,
    closeLoginModal,
    activeTab,
    setActiveTab,
  };

  return (
    <LoginContext.Provider value={contextValue}>
      {children}
    </LoginContext.Provider>
  );
}

/**
 * Hook para usar o contexto de login
 */
export function useLogin() {
  const context = useContext(LoginContext);
  return context;
}

// Exportamos a função global para facilitar o acesso
export const globalLogin = {
  openLoginModal: (initialTab: string = 'login') => {
    const event = new CustomEvent('open-login-modal', { detail: initialTab });
    document.dispatchEvent(event);
  }
};