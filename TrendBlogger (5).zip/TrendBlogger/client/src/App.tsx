import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Sidebar from "./components/Sidebar";
import TopHeader from "./components/TopHeader";
import Dashboard from "./pages/Dashboard";
import AllTrends from "./pages/AllTrends";
import AllPosts from "./pages/AllPosts";
import NewsPage from "./pages/NewsPage";
import Scheduler from "./pages/Scheduler";
import Settings from "./pages/Settings";
import UserManagement from "./pages/UserManagement";
import VisitorManagement from "./pages/VisitorManagement";
import PageviewStats from "./pages/PageviewStats";
import AuthPage from "./pages/auth-page";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { AuthProvider } from "./hooks/useAuth";
import { GoogleAuthProvider } from "./contexts/GoogleAuthContext";
import { LoginProvider } from "./contexts/LoginContext";
import AuthRedirect from "./components/AuthRedirect";
import { useState } from "react";

// Blog pages
import BlogHome from "./pages/blog/BlogHome";
import BlogPost from "./pages/blog/BlogPost";
import BlogCategory from "./pages/blog/BlogCategory";
import BlogCategories from "./pages/blog/BlogCategories";
import BlogAbout from "./pages/blog/BlogAbout";
import BlogPrivacyPolicy from "./pages/blog/BlogPrivacyPolicy";
import BlogTerms from "./pages/blog/BlogTerms";
import BlogContact from "./pages/blog/BlogContact";
import PerfilVisitante from "./pages/blog/PerfilVisitante";

function AdminRouter() {
  return (
    <Switch>
      <Route path="/"><Dashboard /></Route>
      <Route path="/trends"><AllTrends /></Route>
      <Route path="/news"><NewsPage /></Route>
      <Route path="/posts"><AllPosts /></Route>
      <Route path="/scheduler"><Scheduler /></Route>
      <Route path="/settings"><Settings /></Route>
      <Route path="/users"><UserManagement /></Route>
      <Route path="/visitors"><VisitorManagement /></Route>
      <Route path="/pageviews"><PageviewStats /></Route>
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

// Blog router

function BlogRouter() {
  return (
    <Switch>
      <Route path="/blog" component={BlogHome} />
      <Route path="/blog/post/:id/:slug" component={BlogPost} />
      <Route path="/blog/post/:id" component={BlogPost} />
      <Route path="/blog/categoria/:slug" component={BlogCategory} />
      <Route path="/blog/categorias" component={BlogCategories} />
      <Route path="/blog/sobre" component={BlogAbout} />
      <Route path="/blog/politica-de-privacidade" component={BlogPrivacyPolicy} />
      <Route path="/blog/termos-de-uso" component={BlogTerms} />
      <Route path="/blog/contato" component={BlogContact} />
      <Route path="/blog/perfil" component={PerfilVisitante} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  
  // Determina se estamos na seção de blog ou na seção de admin
  const isBlogRoute = location.startsWith("/blog");
  const isAuthPage = location === "/auth";

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <GoogleAuthProvider>
          <LoginProvider>
            {/* Componente que gerencia os redirecionamentos de autenticação */}
            <AuthRedirect />
            
            {isBlogRoute ? (
              // Layout do Blog (sem sidebar ou header do admin)
              <BlogRouter />
            ) : isAuthPage ? (
              // Página de Autenticação (sem sidebar ou header)
              <AuthPage />
            ) : (
            // Layout do Admin
            <div className="flex h-screen overflow-hidden">
              <Sidebar isOpen={mobileMenuOpen} onClose={() => setMobileMenuOpen(false)} />
              
              <div className="flex flex-col flex-1 overflow-hidden">
                <TopHeader onMenuToggle={() => setMobileMenuOpen(!mobileMenuOpen)} />
                
                <main className="flex-1 overflow-y-auto bg-neutral-50 p-4 md:p-6">
                  <AdminRouter />
                </main>
              </div>
            </div>
          )}
          <Toaster />
          </LoginProvider>
        </GoogleAuthProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
