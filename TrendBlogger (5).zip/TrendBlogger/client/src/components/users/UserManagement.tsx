import { useState } from "react";
import { 
  useUsers, 
  useCreateUser, 
  useUpdateUser, 
  useDeleteUser,
  User
} from "@/hooks/useUsers";
import { useAuth } from "@/hooks/useAuth";
import { Loader2, Plus, Pencil, Trash2, Check, X, Shield, UserCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { formatDate } from "@/lib/utils";

export default function UserManagement() {
  const { data: users, isLoading, error } = useUsers();
  const { user: currentUser } = useAuth();
  const createUserMutation = useCreateUser();
  const updateUserMutation = useUpdateUser();
  const deleteUserMutation = useDeleteUser();
  
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  
  // Estados para o formulário de criação
  const [newUsername, setNewUsername] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newName, setNewName] = useState("");
  const [newRole, setNewRole] = useState("user");
  const [newActive, setNewActive] = useState(true);
  
  // Estados para o formulário de edição
  const [editName, setEditName] = useState("");
  const [editRole, setEditRole] = useState("");
  const [editActive, setEditActive] = useState(true);
  const [editPassword, setEditPassword] = useState("");
  
  // Lidar com a criação de usuário
  const handleCreateUser = () => {
    createUserMutation.mutate({
      username: newUsername,
      password: newPassword,
      name: newName || undefined,
      role: newRole,
      active: newActive
    });
    
    // Limpar o formulário e fechar o diálogo
    setNewUsername("");
    setNewPassword("");
    setNewName("");
    setNewRole("user");
    setNewActive(true);
    setIsCreateDialogOpen(false);
  };
  
  // Preparar para editar um usuário
  const handleEditDialogOpen = (user: User) => {
    setSelectedUser(user);
    setEditName(user.name || "");
    setEditRole(user.role || "user");
    setEditActive(user.active !== false);
    setEditPassword("");
    setIsEditDialogOpen(true);
  };
  
  // Lidar com a atualização de usuário
  const handleUpdateUser = () => {
    if (!selectedUser) return;
    
    const updatedData = {
      name: editName || undefined,
      role: editRole,
      active: editActive
    };
    
    // Adicionar senha apenas se foi fornecida
    if (editPassword) {
      Object.assign(updatedData, { password: editPassword });
    }
    
    updateUserMutation.mutate({
      id: selectedUser.id,
      userData: updatedData
    });
    
    // Fechar o diálogo
    setIsEditDialogOpen(false);
  };
  
  // Lidar com a exclusão de usuário
  const handleDeleteUser = (id: number) => {
    deleteUserMutation.mutate(id);
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Carregando usuários...</span>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="p-8 text-center text-red-500">
        <p>Erro ao carregar usuários: {error.message}</p>
      </div>
    );
  }
  
  return (
    <Card className="shadow-lg">
      <CardHeader className="bg-primary/5">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-2xl flex items-center gap-2">
              <Shield className="h-6 w-6 text-primary" />
              Gerenciamento de Usuários
            </CardTitle>
            <CardDescription>
              Gerencie usuários e permissões do sistema
            </CardDescription>
          </div>
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-1">
                <Plus className="h-4 w-4" />
                Novo Usuário
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Criar Novo Usuário</DialogTitle>
                <DialogDescription>
                  Preencha os campos abaixo para criar um novo usuário no sistema.
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="username" className="text-right">
                    Username*
                  </Label>
                  <Input 
                    id="username" 
                    value={newUsername} 
                    onChange={(e) => setNewUsername(e.target.value)} 
                    className="col-span-3" 
                    placeholder="email@exemplo.com"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="password" className="text-right">
                    Senha*
                  </Label>
                  <Input 
                    id="password" 
                    type="password" 
                    value={newPassword} 
                    onChange={(e) => setNewPassword(e.target.value)} 
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Nome
                  </Label>
                  <Input 
                    id="name" 
                    value={newName} 
                    onChange={(e) => setNewName(e.target.value)} 
                    className="col-span-3"
                    placeholder="Nome completo"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="role" className="text-right">
                    Papel
                  </Label>
                  <Select 
                    value={newRole} 
                    onValueChange={setNewRole}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Selecione um papel" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="user">Usuário</SelectItem>
                      <SelectItem value="admin">Administrador</SelectItem>
                      <SelectItem value="editor">Editor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="active" className="text-right">
                    Ativo
                  </Label>
                  <div className="flex items-center space-x-2 col-span-3">
                    <Switch 
                      id="active" 
                      checked={newActive} 
                      onCheckedChange={setNewActive} 
                    />
                    <Label htmlFor="active">{newActive ? "Sim" : "Não"}</Label>
                  </div>
                </div>
              </div>
              
              <DialogFooter>
                <Button 
                  variant="outline" 
                  onClick={() => setIsCreateDialogOpen(false)}
                >
                  Cancelar
                </Button>
                <Button 
                  onClick={handleCreateUser} 
                  disabled={!newUsername || !newPassword || createUserMutation.isPending}
                >
                  {createUserMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Criar Usuário
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID</TableHead>
                <TableHead>Usuário</TableHead>
                <TableHead>Nome</TableHead>
                <TableHead>Papel</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Criado em</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {!users || users.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center">
                    Nenhum usuário encontrado.
                  </TableCell>
                </TableRow>
              ) : (
                users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.id}</TableCell>
                    <TableCell>{user.username}</TableCell>
                    <TableCell>{user.name || "-"}</TableCell>
                    <TableCell>
                      <Badge variant={user.role === "admin" ? "default" : "secondary"}>
                        {user.role === "admin" ? "Administrador" : 
                         user.role === "editor" ? "Editor" : "Usuário"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={user.active !== false ? "default" : "destructive"} className={user.active !== false ? "bg-green-100 text-green-800 hover:bg-green-200" : ""}>
                        {user.active !== false ? "Ativo" : "Inativo"}
                      </Badge>
                    </TableCell>
                    <TableCell>{user.createdAt ? formatDate(new Date(user.createdAt)) : "-"}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => handleEditDialogOpen(user)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        
                        {/* Não permitir a exclusão do próprio usuário ou do único admin */}
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              disabled={user.id === currentUser?.id}
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                              <AlertDialogDescription>
                                Você tem certeza que deseja excluir o usuário <strong>{user.username}</strong>?
                                Esta ação não pode ser desfeita.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction 
                                onClick={() => handleDeleteUser(user.id)}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              >
                                {deleteUserMutation.isPending && (
                                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                )}
                                Excluir
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
      
      <CardFooter className="bg-primary/5 p-4 text-sm text-muted-foreground">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center w-full gap-2">
          <p>
            <span className="font-medium">{users?.length || 0}</span> usuários encontrados
          </p>
          <p>
            Os usuários com papel "Administrador" têm acesso completo ao sistema.
          </p>
        </div>
      </CardFooter>
      
      {/* Diálogo de edição */}
      {selectedUser && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Editar Usuário</DialogTitle>
              <DialogDescription>
                Atualize as informações do usuário <strong>{selectedUser.username}</strong>.
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-name" className="text-right">
                  Nome
                </Label>
                <Input 
                  id="edit-name" 
                  value={editName} 
                  onChange={(e) => setEditName(e.target.value)} 
                  className="col-span-3"
                  placeholder="Nome completo"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-role" className="text-right">
                  Papel
                </Label>
                <Select 
                  value={editRole} 
                  onValueChange={setEditRole}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Selecione um papel" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">Usuário</SelectItem>
                    <SelectItem value="admin">Administrador</SelectItem>
                    <SelectItem value="editor">Editor</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-active" className="text-right">
                  Ativo
                </Label>
                <div className="flex items-center space-x-2 col-span-3">
                  <Switch 
                    id="edit-active" 
                    checked={editActive} 
                    onCheckedChange={setEditActive} 
                    disabled={selectedUser.id === currentUser?.id}
                  />
                  <Label htmlFor="edit-active">
                    {editActive ? "Sim" : "Não"}
                    {selectedUser.id === currentUser?.id && (
                      <span className="ml-2 text-xs text-muted-foreground">
                        (Não é possível desativar seu próprio usuário)
                      </span>
                    )}
                  </Label>
                </div>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-password" className="text-right">
                  Nova Senha
                </Label>
                <Input 
                  id="edit-password" 
                  type="password" 
                  value={editPassword} 
                  onChange={(e) => setEditPassword(e.target.value)} 
                  className="col-span-3"
                  placeholder="Deixe em branco para manter a senha atual"
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button 
                variant="outline" 
                onClick={() => setIsEditDialogOpen(false)}
              >
                Cancelar
              </Button>
              <Button 
                onClick={handleUpdateUser} 
                disabled={updateUserMutation.isPending}
              >
                {updateUserMutation.isPending && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Salvar Alterações
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </Card>
  );
}