import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useCreateSchedule } from "@/hooks/useSchedules";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";

// Categorias disponíveis para selecionar
const CATEGORIAS = [
  "tecnologia", 
  "negocios", 
  "financas", 
  "saude", 
  "politica", 
  "esportes", 
  "sustentabilidade", 
  "educacao", 
  "geral"
];

interface AddScheduleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AddScheduleModal({ isOpen, onClose }: AddScheduleModalProps) {
  const { toast } = useToast();
  const createScheduleMutation = useCreateSchedule();

  const [name, setName] = useState("");
  const [frequency, setFrequency] = useState("daily");
  const [contentType, setContentType] = useState("Artigo informativo");
  const [updateTrends, setUpdateTrends] = useState(true);
  const [searchMode, setSearchMode] = useState("trends");
  const [searchPeriod, setSearchPeriod] = useState(1);
  const [generatePost, setGeneratePost] = useState(true);
  const [seoOptimization, setSeoOptimization] = useState(true);
  const [useRelatedKeywords, setUseRelatedKeywords] = useState(true);
  const [addMetaDescription, setAddMetaDescription] = useState(true);
  const [findImage, setFindImage] = useState(true);
  const [useRecentNews, setUseRecentNews] = useState(true);
  const [wordCount, setWordCount] = useState("medium");
  const [autoPublish, setAutoPublish] = useState(false);
  const [newsCategories, setNewsCategories] = useState<string[]>([]);

  const resetForm = () => {
    setName("");
    setFrequency("daily");
    setContentType("Artigo informativo");
    setUpdateTrends(true);
    setSearchMode("trends");
    setSearchPeriod(1);
    setGeneratePost(true);
    setSeoOptimization(true);
    setUseRelatedKeywords(true);
    setAddMetaDescription(true);
    setFindImage(true);
    setUseRecentNews(true);
    setWordCount("medium");
    setAutoPublish(false);
    setNewsCategories([]);
  };
  
  const toggleCategory = (categoria: string) => {
    if (newsCategories.includes(categoria)) {
      setNewsCategories(newsCategories.filter(c => c !== categoria));
    } else {
      setNewsCategories([...newsCategories, categoria]);
    }
  };

  const handleSubmit = async () => {
    if (!name.trim()) {
      toast({
        title: "Nome é obrigatório",
        description: "Por favor, dê um nome para este agendamento.",
        variant: "destructive",
      });
      return;
    }

    try {
      await createScheduleMutation.mutateAsync({
        name,
        frequency,
        active: true,
        settings: {
          updateTrends,
          searchMode,
          searchPeriod,
          generatePost,
          contentType,
          seoOptimization,
          useRelatedKeywords,
          addMetaDescription,
          useRecentNews,
          findImage,
          wordCount,
          autoPublish,
          newsCategories
        }
      });

      toast({
        title: "Agendamento criado com sucesso",
        description: "O agendamento foi criado e começará a execução conforme a frequência definida.",
      });

      resetForm();
      onClose();
    } catch (error: any) {
      toast({
        title: "Erro ao criar agendamento",
        description: error.message || "Ocorreu um erro ao criar o agendamento. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Novo Agendamento</DialogTitle>
          <DialogDescription>
            Configure um novo agendamento para geração automática de conteúdo.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Nome
            </Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="col-span-3"
              placeholder="Ex: Geração diária de artigos de tecnologia"
            />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="frequency" className="text-right">
              Frequência
            </Label>
            <Select
              value={frequency}
              onValueChange={setFrequency}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Selecione a frequência" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hourly">A cada hora</SelectItem>
                <SelectItem value="daily">Diariamente</SelectItem>
                <SelectItem value="weekly">Semanalmente</SelectItem>
                <SelectItem value="monthly">Mensalmente</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-4 items-start gap-4">
            <Label className="text-right pt-2">Ações</Label>
            <div className="col-span-3 space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="update-trends"
                  checked={updateTrends}
                  onCheckedChange={(checked) => setUpdateTrends(checked as boolean)}
                />
                <Label htmlFor="update-trends">Atualizar tendências</Label>
              </div>
              
              {updateTrends && (
                <div className="pl-6 space-y-3 mb-2">
                  <div>
                    <Label htmlFor="search-mode" className="block mb-1 text-sm">
                      Modo de busca
                    </Label>
                    <Select
                      value={searchMode}
                      onValueChange={setSearchMode}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Selecione o modo de busca" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="trends">Tendências</SelectItem>
                        <SelectItem value="news">Notícias</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="search-period" className="block mb-1 text-sm">
                      Período de busca (dias)
                    </Label>
                    <div className="flex items-center">
                      <Input
                        id="search-period"
                        type="number"
                        min="1"
                        max="30"
                        value={searchPeriod}
                        onChange={(e) => setSearchPeriod(Math.max(1, Math.min(30, parseInt(e.target.value) || 1)))}
                        className="w-full"
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {searchPeriod === 1 
                        ? `Últimas 24 horas (ex: ${new Date(Date.now() - 24*60*60*1000).toLocaleDateString('pt-BR')} a ${new Date().toLocaleDateString('pt-BR')})`
                        : `Últimos ${searchPeriod} dias (ex: ${new Date(Date.now() - searchPeriod*24*60*60*1000).toLocaleDateString('pt-BR')} a ${new Date().toLocaleDateString('pt-BR')})`
                      }
                    </p>
                  </div>
                </div>
              )}

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="generate-post"
                  checked={generatePost}
                  onCheckedChange={(checked) => setGeneratePost(checked as boolean)}
                />
                <Label htmlFor="generate-post">Gerar post a partir de tendências</Label>
              </div>
            </div>
          </div>

          {generatePost && (
            <>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="content-type" className="text-right">
                  Tipo de Conteúdo
                </Label>
                <Select
                  value={contentType}
                  onValueChange={setContentType}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Selecione o tipo de conteúdo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Artigo informativo">Artigo informativo</SelectItem>
                    <SelectItem value="Tutorial">Tutorial</SelectItem>
                    <SelectItem value="Análise/Review">Análise/Review</SelectItem>
                    <SelectItem value="Lista (Top 10)">Lista (Top 10)</SelectItem>
                    <SelectItem value="Perguntas e Respostas">Perguntas e Respostas</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {searchMode === "news" && (
                <div className="grid grid-cols-4 items-start gap-4">
                  <Label className="text-right pt-2">
                    Categorias
                  </Label>
                  <div className="col-span-3">
                    <div className="flex flex-wrap gap-2 mb-2">
                      {newsCategories.map(categoria => (
                        <Badge key={categoria} className="flex items-center gap-1 px-3 py-1">
                          {categoria}
                          <X 
                            className="h-3 w-3 cursor-pointer opacity-70 hover:opacity-100" 
                            onClick={() => toggleCategory(categoria)}
                          />
                        </Badge>
                      ))}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {CATEGORIAS.filter(c => !newsCategories.includes(c)).map(categoria => (
                        <Badge 
                          key={categoria} 
                          variant="outline" 
                          className="cursor-pointer hover:bg-primary/10"
                          onClick={() => toggleCategory(categoria)}
                        >
                          {categoria}
                        </Badge>
                      ))}
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      Selecione as categorias de notícias para buscar.
                      {newsCategories.length === 0 && " Se nenhuma for selecionada, todas serão consideradas."}
                    </p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-4 items-start gap-4">
                <Label className="text-right pt-2">Otimização</Label>
                <div className="col-span-3 space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="seo-optimization"
                      checked={seoOptimization}
                      onCheckedChange={(checked) => setSeoOptimization(checked as boolean)}
                    />
                    <Label htmlFor="seo-optimization">Otimização para SEO</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="use-related-keywords"
                      checked={useRelatedKeywords}
                      onCheckedChange={(checked) => setUseRelatedKeywords(checked as boolean)}
                    />
                    <Label htmlFor="use-related-keywords">Usar palavras-chave relacionadas</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="add-meta-description"
                      checked={addMetaDescription}
                      onCheckedChange={(checked) => setAddMetaDescription(checked as boolean)}
                    />
                    <Label htmlFor="add-meta-description">Adicionar meta description</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="find-image"
                      checked={findImage}
                      onCheckedChange={(checked) => setFindImage(checked as boolean)}
                    />
                    <Label htmlFor="find-image">Buscar imagem relevante</Label>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="use-recent-news"
                      checked={useRecentNews}
                      onCheckedChange={(checked) => setUseRecentNews(checked as boolean)}
                    />
                    <Label htmlFor="use-recent-news">Buscar informações recentes (última semana)</Label>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="word-count" className="text-right">
                  Tamanho do Post
                </Label>
                <Select
                  value={wordCount}
                  onValueChange={setWordCount}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Selecione o tamanho" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="short">Curto (500-800 palavras)</SelectItem>
                    <SelectItem value="medium">Médio (800-1200 palavras)</SelectItem>
                    <SelectItem value="long">Longo (1200-2000 palavras)</SelectItem>
                    <SelectItem value="in-depth">Aprofundado (2000+ palavras)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <div className="col-span-4 flex items-center space-x-2">
                  <Checkbox
                    id="auto-publish"
                    checked={autoPublish}
                    onCheckedChange={(checked) => setAutoPublish(checked as boolean)}
                  />
                  <Label htmlFor="auto-publish">Publicar automaticamente após gerar</Label>
                </div>
              </div>
            </>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={createScheduleMutation.isPending}
          >
            {createScheduleMutation.isPending ? (
              <>
                <span className="inline-block animate-spin mr-2">&#8635;</span> Salvando...
              </>
            ) : (
              "Salvar Agendamento"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
