import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  TrendingUp, 
  FileText, 
  Calendar, 
  Settings,
  Sparkles,
  ExternalLink,
  Globe,
  Users,
  UserCheck,
  BarChart2,
  Newspaper
} from "lucide-react";
import { useSchedules } from "@/hooks/useSchedules";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

// Menu items serão atualizados dinamicamente no componente

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location, setLocation] = useLocation();
  const { data: schedules } = useSchedules();

  // This div will be fixed positioned on mobile and overlay the page
  // On desktop it will be a regular sidebar
  const sidebarClasses = cn(
    "md:flex md:flex-shrink-0",
    isOpen ? "fixed inset-0 z-40 flex" : "hidden"
  );
  
  const handleNavigation = (path: string) => {
    setLocation(path);
    onClose();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-neutral-800 bg-opacity-50 z-30 md:hidden"
          onClick={onClose}
        />
      )}

      <div className={sidebarClasses}>
        <div className="flex flex-col w-64 bg-white border-r border-neutral-200">
          {/* Logo */}
          <div className="flex items-center h-16 px-4 border-b border-neutral-200">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-semibold text-neutral-900">BlogGen</span>
            </div>
          </div>

          {/* Menu Items */}
          <nav className="flex-1 px-2 py-4 space-y-1">
            {/* Dashboard */}
            <button
              onClick={() => handleNavigation("/")}
              className={cn(
                "w-full flex items-center px-3 py-2 text-sm font-medium rounded-md",
                location === "/"
                  ? "bg-primary/10 text-primary"
                  : "text-neutral-700 hover:bg-neutral-100"
              )}
            >
              <span 
                className={cn(
                  "mr-3",
                  location === "/" ? "text-primary" : "text-neutral-500"
                )}
              >
                <LayoutDashboard className="h-5 w-5" />
              </span>
              Dashboard
            </button>
            
            {/* Tendências */}
            <button
              onClick={() => handleNavigation("/trends")}
              className={cn(
                "w-full flex items-center px-3 py-2 text-sm font-medium rounded-md",
                location === "/trends"
                  ? "bg-primary/10 text-primary"
                  : "text-neutral-700 hover:bg-neutral-100"
              )}
            >
              <span 
                className={cn(
                  "mr-3",
                  location === "/trends" ? "text-primary" : "text-neutral-500"
                )}
              >
                <TrendingUp className="h-5 w-5" />
              </span>
              Tendências
            </button>
            
            {/* Notícias */}
            <button
              onClick={() => handleNavigation("/news")}
              className={cn(
                "w-full flex items-center px-3 py-2 text-sm font-medium rounded-md",
                location === "/news"
                  ? "bg-primary/10 text-primary"
                  : "text-neutral-700 hover:bg-neutral-100"
              )}
            >
              <span 
                className={cn(
                  "mr-3",
                  location === "/news" ? "text-primary" : "text-neutral-500"
                )}
              >
                <Newspaper className="h-5 w-5" />
              </span>
              Notícias
            </button>
            
            {/* Posts Gerados */}
            <button
              onClick={() => handleNavigation("/posts")}
              className={cn(
                "w-full flex items-center px-3 py-2 text-sm font-medium rounded-md",
                location === "/posts"
                  ? "bg-primary/10 text-primary"
                  : "text-neutral-700 hover:bg-neutral-100"
              )}
            >
              <span 
                className={cn(
                  "mr-3",
                  location === "/posts" ? "text-primary" : "text-neutral-500"
                )}
              >
                <FileText className="h-5 w-5" />
              </span>
              Posts Gerados
            </button>
            
            {/* Agendamentos (com notificação se existirem agendamentos) */}
            <button
              onClick={() => handleNavigation("/scheduler")}
              className={cn(
                "w-full flex items-center px-3 py-2 text-sm font-medium rounded-md",
                location === "/scheduler"
                  ? "bg-primary/10 text-primary"
                  : "text-neutral-700 hover:bg-neutral-100"
              )}
            >
              <span 
                className={cn(
                  "mr-3 relative",
                  location === "/scheduler" ? "text-primary" : "text-neutral-500"
                )}
              >
                <Calendar className="h-5 w-5" />
                {schedules && schedules.length > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-primary-500"></span>
                  </span>
                )}
              </span>
              Agendamentos
              {schedules && schedules.length > 0 && (
                <span className="ml-auto bg-primary-100 text-primary-800 text-xs font-semibold px-2 py-0.5 rounded-full">
                  {schedules.length}
                </span>
              )}
            </button>
            
            {/* Usuários */}
            <button
              onClick={() => handleNavigation("/users")}
              className={cn(
                "w-full flex items-center px-3 py-2 text-sm font-medium rounded-md",
                location === "/users"
                  ? "bg-primary/10 text-primary"
                  : "text-neutral-700 hover:bg-neutral-100"
              )}
            >
              <span 
                className={cn(
                  "mr-3",
                  location === "/users" ? "text-primary" : "text-neutral-500"
                )}
              >
                <Users className="h-5 w-5" />
              </span>
              Usuários
            </button>
            
            {/* Visitantes */}
            <button
              onClick={() => handleNavigation("/visitors")}
              className={cn(
                "w-full flex items-center px-3 py-2 text-sm font-medium rounded-md",
                location === "/visitors"
                  ? "bg-primary/10 text-primary"
                  : "text-neutral-700 hover:bg-neutral-100"
              )}
            >
              <span 
                className={cn(
                  "mr-3",
                  location === "/visitors" ? "text-primary" : "text-neutral-500"
                )}
              >
                <UserCheck className="h-5 w-5" />
              </span>
              Visitantes
            </button>
            
            {/* Estatísticas de Visualização */}
            <button
              onClick={() => handleNavigation("/pageviews")}
              className={cn(
                "w-full flex items-center px-3 py-2 text-sm font-medium rounded-md",
                location === "/pageviews"
                  ? "bg-primary/10 text-primary"
                  : "text-neutral-700 hover:bg-neutral-100"
              )}
            >
              <span 
                className={cn(
                  "mr-3",
                  location === "/pageviews" ? "text-primary" : "text-neutral-500"
                )}
              >
                <BarChart2 className="h-5 w-5" />
              </span>
              Estatísticas de Visualização
            </button>
            
            {/* Configurações */}
            <button
              onClick={() => handleNavigation("/settings")}
              className={cn(
                "w-full flex items-center px-3 py-2 text-sm font-medium rounded-md",
                location === "/settings"
                  ? "bg-primary/10 text-primary"
                  : "text-neutral-700 hover:bg-neutral-100"
              )}
            >
              <span 
                className={cn(
                  "mr-3",
                  location === "/settings" ? "text-primary" : "text-neutral-500"
                )}
              >
                <Settings className="h-5 w-5" />
              </span>
              Configurações
            </button>
            
            {/* Separador */}
            <div className="my-2 border-t border-neutral-200" />
            
            {/* Link para o Blog */}
            <a
              href="/blog"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center px-3 py-2 text-sm font-medium rounded-md bg-primary-50 text-primary-700 hover:bg-primary-100 hover:text-primary-800 border border-primary-200"
              onClick={(e) => {
                e.preventDefault();
                window.open('/blog', '_blank');
                // Não fechamos o sidebar neste caso, pois queremos manter a página atual
              }}
            >
              <span className="mr-3 text-primary-600 flex items-center">
                <Globe className="h-5 w-5" />
              </span>
              Ir ao Blog
              <ExternalLink className="h-3.5 w-3.5 ml-auto text-primary-400" />
            </a>
          </nav>

          {/* User Profile */}
          <div className="flex items-center px-4 py-3 border-t border-neutral-200">
            <div className="flex-shrink-0">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white">
                <span className="text-sm font-medium">BG</span>
              </div>
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-neutral-800">BlogGen</p>
              <p className="text-xs text-neutral-500">Automated Posts</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
