import { useEffect, useState } from 'react';
import { Button } from "@/components/ui/button";
import { useGoogleAuth } from "@/contexts/GoogleAuthContext";
import { Loader2, LogIn, LogOut } from 'lucide-react';
import { auth, googleProvider } from '@/lib/firebase';
import { signInWithRedirect } from 'firebase/auth';

interface GoogleLoginButtonProps {
  variant?: "default" | "outline" | "secondary" | "ghost" | "link" | "destructive";
  size?: "default" | "sm" | "lg" | "icon";
  className?: string;
}

export function GoogleLoginButton({ variant = "default", size = "default", className }: GoogleLoginButtonProps) {
  const { currentUser, signIn, logOut, isLoading } = useGoogleAuth();
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    // Resetar o estado de processamento quando o usuário mudar
    setIsProcessing(false);
  }, [currentUser]);

  const handleLogin = async () => {
    console.log("Botão de login clicado");
    setIsProcessing(true);
    try {
      console.log("Iniciando redirecionamento para login");
      
      // Tentando usar redirecionamento diretamente (alternativa ao popup)
      // Adicionando escopo para acesso ao e-mail e perfil
      googleProvider.addScope('email');
      googleProvider.addScope('profile');
      
      // Definindo prompt de seleção de conta
      googleProvider.setCustomParameters({
        prompt: 'select_account',
        login_hint: 'user@gmail.com'
      });
      
      // Usando redirecionamento em vez de popup
      console.log("Redirecionando para página de autenticação Google");
      await signInWithRedirect(auth, googleProvider);
      console.log("Redirecionamento iniciado");
      
      // O código após o redirecionamento não será executado até que o usuário retorne
      // O processamento do resultado será feito no contexto de autenticação
      
    } catch (error) {
      console.error("Erro ao realizar login:", error);
      alert("Ocorreu um erro ao tentar fazer login. Por favor, tente novamente.");
      setIsProcessing(false);
    }
  };

  const handleLogout = async () => {
    setIsProcessing(true);
    try {
      await logOut();
    } catch (error) {
      console.error("Erro ao realizar logout:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  if (isLoading) {
    return (
      <Button
        variant={variant}
        size={size}
        className={className}
        disabled
      >
        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
        Carregando...
      </Button>
    );
  }

  if (currentUser) {
    return (
      <Button
        variant={variant}
        size={size}
        className={className}
        onClick={handleLogout}
        disabled={isProcessing}
      >
        {isProcessing ? (
          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
        ) : (
          <LogOut className="h-4 w-4 mr-2" />
        )}
        Sair
      </Button>
    );
  }

  return (
    <Button
      variant={variant}
      size={size}
      className={className}
      onClick={handleLogin}
      disabled={isProcessing}
    >
      {isProcessing ? (
        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
      ) : (
        <LogIn className="h-4 w-4 mr-2" />
      )}
      Entrar com Google
    </Button>
  );
}