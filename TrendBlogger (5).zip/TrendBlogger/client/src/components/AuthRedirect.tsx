import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";

export default function AuthRedirect() {
  const { isAuthenticated, isLoading } = useAuth();
  const [location, setLocation] = useLocation();
  const isBlogRoute = location.startsWith("/blog");
  const isAuthPage = location === "/auth";

  useEffect(() => {
    // Aguarda o carregamento da autenticação
    if (isLoading) return;
    
    // Se não estiver autenticado e não estiver na rota de autenticação nem no blog, redireciona para login
    if (!isAuthenticated && !isAuthPage && !isBlogRoute) {
      setLocation("/auth");
    }
    
    // Se estiver autenticado e estiver na página de login, redireciona para o dashboard
    if (isAuthenticated && isAuthPage) {
      setLocation("/");
    }
  }, [isAuthenticated, isLoading, isAuthPage, isBlogRoute, setLocation]);

  return null;
}