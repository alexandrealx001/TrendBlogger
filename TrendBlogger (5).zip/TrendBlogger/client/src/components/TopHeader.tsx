import { useLocation } from "wouter";
import { Menu, Bell, HelpCircle, LogOut, User } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

interface TopHeaderProps {
  onMenuToggle: () => void;
}

// Map of paths to page titles
const pageTitles: Record<string, string> = {
  "/": "Dashboard",
  "/trends": "Tendências",
  "/posts": "Posts Gerados",
  "/scheduler": "Agendamentos",
  "/settings": "Configurações",
};

export default function TopHeader({ onMenuToggle }: TopHeaderProps) {
  const [location] = useLocation();
  const title = pageTitles[location] || "BlogGen";
  const { user, logoutMutation } = useAuth();
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-white shadow-sm z-10">
      <div className="flex items-center justify-between h-16 px-4 md:px-6">
        <div className="flex items-center">
          <button 
            type="button" 
            className="md:hidden text-neutral-500 hover:text-neutral-600"
            onClick={onMenuToggle}
          >
            <Menu className="h-6 w-6" />
          </button>
          <h1 className="ml-2 md:ml-0 text-lg font-semibold text-neutral-900">{title}</h1>
        </div>
        <div className="flex items-center space-x-4">
          {user && (
            <div className="flex items-center space-x-3">
              <div className="hidden md:flex items-center">
                <User className="h-5 w-5 text-primary mr-2" />
                <span className="text-sm font-medium">{user.username}</span>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
                className="text-neutral-600 hover:text-neutral-900"
              >
                <LogOut className="h-5 w-5 mr-1" />
                <span className="hidden md:inline">Sair</span>
              </Button>
            </div>
          )}
          <button type="button" className="p-1 text-neutral-500 hover:text-neutral-600">
            <Bell className="h-6 w-6" />
          </button>
          <button type="button" className="p-1 text-neutral-500 hover:text-neutral-600">
            <HelpCircle className="h-6 w-6" />
          </button>
        </div>
      </div>
    </header>
  );
}
