import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import axios from "axios";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { useMutation } from "@tanstack/react-query";

// Tipo para o visitante autenticado
export interface Visitor {
  id: number;
  name: string;
  email: string;
  photoUrl?: string;
  lastLogin: string;
  loginCount: number;
  cpf?: string;
  birthDate?: string;
  resetPasswordToken?: string;
  resetPasswordExpires?: string;
}

// Props do componente
interface LoginFormProps {
  onSuccess?: (visitor: Visitor) => void;
  initialTab?: string; // "login", "register" ou "reset"
}

// Schema de validação para login
const loginSchema = z.object({
  email: z.string().email("Email inválido"),
  password: z.string().min(1, "Senha é obrigatória")
});

type LoginFormValues = z.infer<typeof loginSchema>;

// Schema de validação para registro
const registerSchema = z.object({
  name: z.string().min(3, "Nome deve ter pelo menos 3 caracteres"),
  email: z.string().email("Email inválido"),
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
  cpf: z.string()
    .min(11, "CPF deve ter 11 dígitos")
    .regex(/^\d{3}\.?\d{3}\.?\d{3}-?\d{2}$/, "Formato de CPF inválido"),
  birthDate: z.string()
    .regex(/^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{4}$/, "Data deve estar no formato DD/MM/AAAA")
});

type RegisterFormValues = z.infer<typeof registerSchema>;

// Schema de validação para recuperação de senha
const resetRequestSchema = z.object({
  cpf: z.string()
    .min(11, "CPF deve ter 11 dígitos")
    .regex(/^\d{3}\.?\d{3}\.?\d{3}-?\d{2}$/, "Formato de CPF inválido"),
  birthDate: z.string()
    .regex(/^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{4}$/, "Data deve estar no formato DD/MM/AAAA")
});

type ResetRequestFormValues = z.infer<typeof resetRequestSchema>;

// Schema de validação para definição de nova senha
const resetPasswordSchema = z.object({
  password: z.string().min(6, "Senha deve ter pelo menos 6 caracteres"),
  confirmPassword: z.string().min(6, "Confirme a senha")
}).refine(data => data.password === data.confirmPassword, {
  message: "As senhas não coincidem",
  path: ["confirmPassword"]
});

type ResetPasswordFormValues = z.infer<typeof resetPasswordSchema>;

export function LoginForm({ onSuccess, initialTab = "login" }: LoginFormProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<string>(initialTab);
  const [resetToken, setResetToken] = useState<string | null>(null);

  // Form para login
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: ""
    }
  });

  // Form para registro
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      cpf: "",
      birthDate: ""
    }
  });

  // Form para solicitação de redefinição de senha
  const resetRequestForm = useForm<ResetRequestFormValues>({
    resolver: zodResolver(resetRequestSchema),
    defaultValues: {
      cpf: "",
      birthDate: ""
    }
  });

  // Form para redefinição de senha
  const resetPasswordForm = useForm<ResetPasswordFormValues>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      password: "",
      confirmPassword: ""
    }
  });

  // Mutation para login
  const loginMutation = useMutation({
    mutationFn: async (data: LoginFormValues) => {
      const response = await axios.post('/api/blog/login', data);
      return response.data;
    },
    onSuccess: (data) => {
      toast({
        title: "Login realizado com sucesso!",
        description: `Bem-vindo(a) ${data.visitor.name}!`,
      });
      
      if (onSuccess) {
        onSuccess(data.visitor);
      }
    },
    onError: (error: any) => {
      console.error("Erro de login:", error);
      toast({
        title: "Erro no login",
        description: error.response?.data?.message || "Não foi possível fazer login. Verifique suas credenciais.",
        variant: "destructive"
      });
    }
  });

  // Mutation para registro
  const registerMutation = useMutation({
    mutationFn: async (data: RegisterFormValues) => {
      const response = await axios.post('/api/blog/register', data);
      return response.data;
    },
    onSuccess: (data) => {
      toast({
        title: "Cadastro realizado com sucesso!",
        description: "Sua conta foi criada e você já está logado.",
      });
      
      if (onSuccess) {
        onSuccess(data.visitor);
      }
    },
    onError: (error: any) => {
      console.error("Erro no cadastro:", error);
      toast({
        title: "Erro no cadastro",
        description: error.response?.data?.message || "Não foi possível completar o cadastro.",
        variant: "destructive"
      });
    }
  });

  // Mutation para solicitar redefinição de senha
  const resetRequestMutation = useMutation({
    mutationFn: async (data: ResetRequestFormValues) => {
      const response = await axios.post('/api/blog/reset-request', data);
      return response.data;
    },
    onSuccess: (data) => {
      setResetToken(data.token);
      toast({
        title: "Solicitação enviada!",
        description: "Agora você pode definir uma nova senha."
      });
    },
    onError: (error: any) => {
      console.error("Erro na solicitação de redefinição:", error);
      toast({
        title: "Erro na solicitação",
        description: error.response?.data?.message || "Não foi possível processar sua solicitação.",
        variant: "destructive"
      });
    }
  });

  // Mutation para redefinir senha
  const resetPasswordMutation = useMutation({
    mutationFn: async (data: ResetPasswordFormValues) => {
      const response = await axios.post('/api/blog/reset-password', {
        token: resetToken,
        password: data.password
      });
      return response.data;
    },
    onSuccess: () => {
      toast({
        title: "Senha atualizada!",
        description: "Sua senha foi redefinida com sucesso. Agora você pode fazer login."
      });
      setActiveTab("login");
      setResetToken(null);
    },
    onError: (error: any) => {
      console.error("Erro na redefinição de senha:", error);
      toast({
        title: "Erro na redefinição",
        description: error.response?.data?.message || "Não foi possível redefinir sua senha.",
        variant: "destructive"
      });
    }
  });

  // Handler para login
  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };

  // Handler para registro
  const onRegisterSubmit = (data: RegisterFormValues) => {
    registerMutation.mutate(data);
  };

  // Handler para solicitação de redefinição de senha
  const onResetRequestSubmit = (data: ResetRequestFormValues) => {
    resetRequestMutation.mutate(data);
  };

  // Handler para redefinição de senha
  const onResetPasswordSubmit = (data: ResetPasswordFormValues) => {
    resetPasswordMutation.mutate(data);
  };

  // Formata o CPF enquanto o usuário digita
  const formatCPF = (value: string) => {
    const digits = value.replace(/\D/g, '');
    
    if (digits.length <= 3) {
      return digits;
    } else if (digits.length <= 6) {
      return `${digits.slice(0, 3)}.${digits.slice(3)}`;
    } else if (digits.length <= 9) {
      return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
    } else {
      return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9, 11)}`;
    }
  };

  // Formata a data enquanto o usuário digita
  const formatDate = (value: string) => {
    const digits = value.replace(/\D/g, '');
    
    if (digits.length <= 2) {
      return digits;
    } else if (digits.length <= 4) {
      return `${digits.slice(0, 2)}/${digits.slice(2)}`;
    } else {
      return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4, 8)}`;
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-center">Acesso ao Blog</CardTitle>
        <CardDescription className="text-center">
          Faça login ou crie uma conta para comentar nos posts
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Cadastro</TabsTrigger>
            <TabsTrigger value="reset">Recuperar</TabsTrigger>
          </TabsList>
          
          {/* Login */}
          <TabsContent value="login">
            <Form {...loginForm}>
              <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                <FormField
                  control={loginForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="seu@email.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Senha</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="••••••••" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={loginMutation.isPending}
                >
                  {loginMutation.isPending ? "Entrando..." : "Entrar"}
                </Button>
              </form>
            </Form>
          </TabsContent>
          
          {/* Cadastro */}
          <TabsContent value="register">
            <Form {...registerForm}>
              <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                <FormField
                  control={registerForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nome completo</FormLabel>
                      <FormControl>
                        <Input placeholder="Seu nome completo" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input placeholder="seu@email.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="cpf"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>CPF</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="000.000.000-00" 
                          {...field} 
                          onChange={(e) => {
                            const formatted = formatCPF(e.target.value);
                            field.onChange(formatted);
                          }}
                          maxLength={14}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="birthDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Data de nascimento</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="DD/MM/AAAA" 
                          {...field} 
                          onChange={(e) => {
                            const formatted = formatDate(e.target.value);
                            field.onChange(formatted);
                          }}
                          maxLength={10}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={registerForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Senha</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="••••••••" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={registerMutation.isPending}
                >
                  {registerMutation.isPending ? "Cadastrando..." : "Cadastrar"}
                </Button>
              </form>
            </Form>
            <div className="mt-2 text-sm text-center text-gray-500">
              *Seus dados são usados apenas para autenticação e recuperação de senha
            </div>
          </TabsContent>
          
          {/* Recuperação de senha */}
          <TabsContent value="reset">
            {!resetToken ? (
              <Form {...resetRequestForm}>
                <form onSubmit={resetRequestForm.handleSubmit(onResetRequestSubmit)} className="space-y-4">
                  <FormField
                    control={resetRequestForm.control}
                    name="cpf"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>CPF</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="000.000.000-00" 
                            {...field} 
                            onChange={(e) => {
                              const formatted = formatCPF(e.target.value);
                              field.onChange(formatted);
                            }}
                            maxLength={14}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={resetRequestForm.control}
                    name="birthDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Data de nascimento</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="DD/MM/AAAA" 
                            {...field} 
                            onChange={(e) => {
                              const formatted = formatDate(e.target.value);
                              field.onChange(formatted);
                            }}
                            maxLength={10}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={resetRequestMutation.isPending}
                  >
                    {resetRequestMutation.isPending ? "Enviando..." : "Verificar dados"}
                  </Button>
                </form>
              </Form>
            ) : (
              <Form {...resetPasswordForm}>
                <form onSubmit={resetPasswordForm.handleSubmit(onResetPasswordSubmit)} className="space-y-4">
                  <FormField
                    control={resetPasswordForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nova senha</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="••••••••" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={resetPasswordForm.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Confirme a senha</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="••••••••" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={resetPasswordMutation.isPending}
                  >
                    {resetPasswordMutation.isPending ? "Salvando..." : "Salvar nova senha"}
                  </Button>
                </form>
              </Form>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-center">
        <p className="text-sm text-center text-gray-500">
          O acesso ao blog é grátis e aberto para todos
        </p>
      </CardFooter>
    </Card>
  );
}