import { useEffect } from 'react';
import { useLocation } from 'wouter';
import axios from 'axios';

/**
 * Componente para rastrear visualizações de páginas do blog.
 * Este componente não renderiza nada visualmente, apenas registra as
 * visualizações de página no servidor sempre que a rota muda.
 */
export function PageviewTracker() {
  const [location] = useLocation();

  useEffect(() => {
    // Só registra visualizações para rotas do blog
    if (location.startsWith('/blog')) {
      const registerPageview = async () => {
        try {
          await axios.post('/api/pageviews', { path: location });
          console.log(`Visualização de página registrada: ${location}`);
        } catch (error) {
          console.error('Erro ao registrar visualização de página:', error);
        }
      };

      registerPageview();
    }
  }, [location]);

  // Este componente não renderiza nada visualmente
  return null;
}