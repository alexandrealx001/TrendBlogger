import { ReactNode, useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { BlogLoginButton } from "@/components/blog/BlogLoginButton";
import { PageviewTracker } from "@/components/blog/PageviewTracker";
import { LoginContextListener } from "@/components/blog/LoginContextListener";
import axios from "axios";

interface BlogLayoutProps {
  children: ReactNode;
}

export default function BlogLayout({ children }: BlogLayoutProps) {
  const [location] = useLocation();
  const [visitor, setVisitor] = useState<any | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  
  // Busca o visitante logado
  useEffect(() => {
    async function fetchVisitor() {
      try {
        const response = await axios.get('/api/blog/visitor');
        if (response.status === 200) {
          setVisitor(response.data);
          // Verifica se o email é o email do admin
          setIsAdmin(response.data.email === 'alexandrealx001@gmail.com');
        }
      } catch (error) {
        // Usuário não está logado
      }
    }
    
    fetchVisitor();
  }, []);
  
  const categories = [
    { name: "Tecnologia", slug: "tecnologia" },
    { name: "Negócios", slug: "negocios" },
    { name: "Finanças", slug: "financas" },
    { name: "Saúde", slug: "saude" },
    { name: "Política", slug: "politica" },
    { name: "Esportes", slug: "esportes" },
    { name: "Sustentabilidade", slug: "sustentabilidade" },
    { name: "Educação", slug: "educacao" }
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Componente invisível que rastreia visualizações de página */}
      <PageviewTracker />
      
      {/* Componente invisível que escuta eventos para abrir o modal de login */}
      <LoginContextListener />
      
      {/* Header */}
      <header className="relative bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 text-white shadow-xl">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-96 h-96 opacity-10">
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <path fill="#FFFFFF" d="M42.7,-62.2C53.8,-52.7,60.4,-37.8,67.6,-21.9C74.9,-6,82.8,10.9,79.5,25.3C76.2,39.8,61.5,51.8,46.3,57.2C31.1,62.7,15.5,61.7,-0.6,62.5C-16.7,63.3,-33.4,66,-43,58.7C-52.7,51.5,-55.3,34.2,-61.8,16.8C-68.2,-0.6,-78.5,-18.2,-75.3,-32.5C-72.1,-46.9,-55.5,-58,-39.5,-67C-23.5,-75.9,-7.8,-82.7,5.2,-89.8C18.2,-97,36.5,-104.4,48.5,-96.1C60.5,-87.9,66.3,-63.9,42.7,-62.2Z" transform="translate(100 100)" />
            </svg>
          </div>
          <div className="absolute -bottom-20 -left-20 w-64 h-64 opacity-10">
            <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
              <path fill="#FFFFFF" d="M54.2,-68.9C69.2,-59.9,79.5,-41.6,83.1,-22.6C86.7,-3.7,83.5,15.8,74.1,30.9C64.8,46,49.2,56.6,32.9,65C16.5,73.4,-0.6,79.6,-18.2,77.9C-35.8,76.2,-53.9,66.5,-67.1,51.7C-80.3,36.9,-88.6,16.9,-87.4,-3C-86.2,-22.9,-75.4,-42.8,-60.2,-52.5C-44.9,-62.1,-25.2,-61.5,-5.1,-55.3C15,-49.2,39.2,-77.9,54.2,-68.9Z" transform="translate(100 100)" />
            </svg>
          </div>
        </div>
        <div className="container mx-auto px-4 py-6 relative z-10">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <Link href="/blog">
                <div className="flex items-center">
                  <div className="mr-3 bg-white p-2 rounded-lg shadow-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                    </svg>
                  </div>
                  <div>
                    <span className="text-3xl font-bold hover:text-blue-100 transition duration-200 cursor-pointer">
                      Trend<span className="bg-clip-text text-transparent bg-gradient-to-r from-yellow-300 to-yellow-500 font-extrabold">Pulsee</span>
                    </span>
                    <p className="text-blue-100 mt-1">As tendências mais recentes do Brasil</p>
                  </div>
                </div>
              </Link>
            </div>
            <div className="flex items-center space-x-6">
              <Link href="/blog">
                <span className={`transition duration-200 cursor-pointer hover:scale-105 transform ${location === '/blog' ? 'text-yellow-300 font-semibold' : 'text-white hover:text-yellow-300'}`}>
                  Home
                </span>
              </Link>
              <Link href="/blog/categorias">
                <span className={`transition duration-200 cursor-pointer hover:scale-105 transform ${location === '/blog/categorias' ? 'text-yellow-300 font-semibold' : 'text-white hover:text-yellow-300'}`}>
                  Categorias
                </span>
              </Link>
              <Link href="/blog/sobre">
                <span className={`transition duration-200 cursor-pointer hover:scale-105 transform ${location === '/blog/sobre' ? 'text-yellow-300 font-semibold' : 'text-white hover:text-yellow-300'}`}>
                  Sobre
                </span>
              </Link>
              <Link href="/blog/perfil">
                <span className={`transition duration-200 cursor-pointer hover:scale-105 transform ${location === '/blog/perfil' ? 'text-yellow-300 font-semibold' : 'text-white hover:text-yellow-300'}`}>
                  Meu Perfil
                </span>
              </Link>
              <BlogLoginButton />
              
              {isAdmin && (
                <Link href="/">
                  <span className="text-white bg-gradient-to-r from-blue-800 to-indigo-900 px-4 py-2 rounded-md hover:shadow-lg hover:from-blue-900 hover:to-indigo-950 transition duration-200 cursor-pointer transform hover:scale-105 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    Admin
                  </span>
                </Link>
              )}
            </div>
          </div>
        </div>
        
        {/* Ondulação inferior */}
        <div className="absolute -bottom-1 left-0 right-0 h-4 overflow-hidden">
          <svg className="absolute bottom-0 w-full h-12 text-white" preserveAspectRatio="none" viewBox="0 0 1200 120">
            <path fill="currentColor" d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z"></path>
          </svg>
        </div>
      </header>

      {/* Category Navigation */}
      <div className="bg-white shadow-md border-b border-gray-200">
        <div className="container mx-auto px-4 py-6 overflow-x-auto">
          <div className="flex flex-nowrap gap-4 justify-start md:justify-center whitespace-nowrap">
            {categories.map((category) => (
              <Link key={category.slug} href={`/blog/categoria/${category.slug}`}>
                <span className={`px-6 py-3 text-base font-medium rounded-full cursor-pointer transform transition duration-200 hover:scale-105 ${
                  location === `/blog/categoria/${category.slug}` 
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg' 
                    : 'bg-gray-100 text-gray-800 hover:bg-blue-50 hover:text-blue-600'
                }`}>
                  {category.name}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 py-8">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-b from-gray-800 to-gray-900 text-gray-300 py-12 shadow-inner">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
            <div>
              <h3 className="text-2xl font-bold mb-4 text-white">
                Trend<span className="bg-clip-text text-transparent bg-gradient-to-r from-yellow-300 to-yellow-500">Pulsee</span>
              </h3>
              <p className="mb-4 text-gray-400">Seu portal de notícias e conteúdo baseado nas principais tendências no Brasil. Atualizações constantes com as informações mais relevantes.</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4 text-white border-b border-gray-700 pb-2">Categorias</h4>
              <ul className="space-y-2">
                {categories.slice(0, 6).map((category) => (
                  <li key={category.slug}>
                    <Link href={`/blog/categoria/${category.slug}`}>
                      <span className="hover:text-blue-400 transition duration-200 cursor-pointer">{category.name}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4 text-white border-b border-gray-700 pb-2">Links Úteis</h4>
              <ul className="space-y-2">
                <li>
                  <Link href="/blog/sobre">
                    <span className="hover:text-blue-400 transition duration-200 cursor-pointer">Sobre</span>
                  </Link>
                </li>
                <li>
                  <Link href="/blog/politica-de-privacidade">
                    <span className="hover:text-blue-400 transition duration-200 cursor-pointer">Política de Privacidade</span>
                  </Link>
                </li>
                <li>
                  <Link href="/blog/termos-de-uso">
                    <span className="hover:text-blue-400 transition duration-200 cursor-pointer">Termos de Uso</span>
                  </Link>
                </li>
                <li>
                  <Link href="/blog/contato">
                    <span className="hover:text-blue-400 transition duration-200 cursor-pointer">Contato</span>
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4 text-white border-b border-gray-700 pb-2">Inscreva-se</h4>
              <p className="mb-4 text-gray-400">Receba as últimas tendências em seu e-mail</p>
              <div className="flex">
                <input 
                  type="email" 
                  placeholder="Seu e-mail" 
                  className="px-4 py-2 text-gray-800 rounded-l-md w-full focus:outline-none focus:ring-2 focus:ring-blue-500" 
                />
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-r-md transition duration-200">
                  Enviar
                </button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-10 pt-8 text-center">
            <p>&copy; {new Date().getFullYear()} TrendPulsee. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}