import { useEffect } from 'react';
import { useLogin } from '@/contexts/LoginContext';

/**
 * Componente que escuta eventos do documento para abrir o modal de login
 * Este componente deve ser adicionado ao layout do blog
 */
export function LoginContextListener() {
  const { openLoginModal } = useLogin();
  
  useEffect(() => {
    // Manipulador para eventos do documento
    const handleOpenLoginModal = (event: CustomEvent) => {
      const initialTab = event.detail || 'login';
      openLoginModal(initialTab);
    };
    
    // Adiciona o ouvinte de evento
    document.addEventListener('open-login-modal', 
      handleOpenLoginModal as EventListener);
    
    // Remove o ouvinte de evento na desmontagem
    return () => {
      document.removeEventListener('open-login-modal', 
        handleOpenLoginModal as EventListener);
    };
  }, [openLoginModal]);
  
  // Este componente não renderiza nada
  return null;
}