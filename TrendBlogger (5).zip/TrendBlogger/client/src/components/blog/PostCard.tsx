import { Post } from "@shared/schema";
import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { fixImageUrl } from "@/lib/utils";
import { useState, useEffect } from "react";

interface PostCardProps {
  post: Post;
  featured?: boolean;
}

export default function PostCard({ post, featured = false }: PostCardProps) {
  const [imageUrl, setImageUrl] = useState<string | null>(post.imageUrl ? fixImageUrl(post.imageUrl) : null);
  const [imageError, setImageError] = useState(false);
  
  // Lista de fallbacks para tentar quando a imagem original falha
  const fallbackUrls = [
    "https://images.unsplash.com/photo-1432821596592-e2c18b78144f?q=85&w=1200&auto=format&fit=crop",
    "https://cdn.pixabay.com/photo/2016/02/03/08/32/banner-1176676_1280.jpg",
    "https://cdn.pixabay.com/photo/2015/01/21/13/20/business-606807_1280.jpg",
    "https://cdn.pixabay.com/photo/2019/01/24/08/13/arrows-3952128_1280.jpg"
  ];
  
  // Gerenciador de erro de imagem que tenta diferentes URLs
  const handleImageError = () => {
    console.log("Imagem falhou ao carregar:", imageUrl);
    
    // Se já estamos usando uma URL de fallback, tente outra
    if (imageError) {
      // Escolhe uma URL aleatória de fallback
      const randomIndex = Math.floor(Math.random() * fallbackUrls.length);
      setImageUrl(fallbackUrls[randomIndex]);
      return;
    }
    
    // Se a URL for do Pixabay, tente os espelhos alternativos
    if (imageUrl && imageUrl.includes('pixabay.com')) {
      try {
        const parsedUrl = new URL(imageUrl);
        
        if (parsedUrl.hostname === 'cdn.pixabay.com') {
          // Tenta usar um espelho alternativo
          const match = parsedUrl.pathname.match(/\/photo\/(.*)/);
          if (match && match[1]) {
            const photoPath = match[1];
            // Tenta outras URLs de espelho
            setImageUrl(`https://i.pixabay.com/photo/${photoPath}`);
            setImageError(true);
            return;
          }
        }
      } catch (e) {
        // Se falhar na análise da URL, use um fallback
        const randomIndex = Math.floor(Math.random() * fallbackUrls.length);
        setImageUrl(fallbackUrls[randomIndex]);
        return;
      }
    }
    
    // Se não for URL do Pixabay ou não conseguir criar espelho, use fallback aleatório
    const randomIndex = Math.floor(Math.random() * fallbackUrls.length);
    setImageUrl(fallbackUrls[randomIndex]);
    setImageError(true);
  };
  
  const formattedDate = post.createdAt 
    ? formatDistanceToNow(new Date(post.createdAt), {
        addSuffix: true,
        locale: ptBR,
      })
    : "";

  // Determinar a categoria baseada nas palavras-chave
  const getCategoryFromKeywords = (keywords: string[] | null): string => {
    if (!keywords || keywords.length === 0) return "tecnologia";
    
    const categoryMap: Record<string, string[]> = {
      tecnologia: ["tecnologia", "digital", "software", "app", "programação", "computação", "ia", "inteligência artificial", "chatgpt", "5g", "iot"],
      negocios: ["negócios", "empresa", "empreendedorismo", "startups", "mercado", "corporativo", "economia"],
      financas: ["finanças", "dinheiro", "investimento", "banco", "pix", "criptomoedas", "financeiro", "economia"],
      saude: ["saúde", "bem-estar", "médico", "medicina", "hospital", "clínica", "tratamento", "doença", "covid"],
      politica: ["política", "governo", "eleição", "congresso", "lei", "legislação", "democracia", "voto"],
      esportes: ["esporte", "futebol", "copa", "olimpíada", "jogo", "atletismo", "atleta", "competição", "campeonato"],
      sustentabilidade: ["sustentabilidade", "meio ambiente", "clima", "ecologia", "verde", "biodiversidade", "natureza"],
      educacao: ["educação", "escola", "universidade", "faculdade", "ensino", "aprendizado", "professor", "aluno"]
    };
    
    // Contagem para determinar a categoria mais relevante
    const categoryScores: Record<string, number> = {
      tecnologia: 0,
      negocios: 0,
      financas: 0,
      saude: 0,
      politica: 0,
      esportes: 0,
      sustentabilidade: 0,
      educacao: 0
    };
    
    // Pontuar cada palavra-chave
    for (const keyword of keywords) {
      for (const [category, categoryKeywords] of Object.entries(categoryMap)) {
        if (categoryKeywords.some(catKey => 
          keyword.toLowerCase().includes(catKey.toLowerCase())
        )) {
          categoryScores[category] += 1;
        }
      }
    }
    
    // Encontrar categoria com maior pontuação
    let bestCategory = "tecnologia";
    let highestScore = 0;
    
    for (const [category, score] of Object.entries(categoryScores)) {
      if (score > highestScore) {
        highestScore = score;
        bestCategory = category;
      }
    }
    
    return bestCategory;
  };

  // Mapeia as categorias para cores com gradientes
  const getCategoryColor = (category: string): string => {
    const colorMap: Record<string, string> = {
      tecnologia: "bg-gradient-to-r from-blue-600 to-blue-700",
      negocios: "bg-gradient-to-r from-indigo-600 to-indigo-700",
      financas: "bg-gradient-to-r from-green-600 to-green-700",
      saude: "bg-gradient-to-r from-red-600 to-red-700",
      politica: "bg-gradient-to-r from-purple-600 to-purple-700",
      esportes: "bg-gradient-to-r from-yellow-600 to-yellow-700",
      sustentabilidade: "bg-gradient-to-r from-emerald-600 to-emerald-700",
      educacao: "bg-gradient-to-r from-orange-600 to-orange-700"
    };
    
    return colorMap[category] || "bg-gradient-to-r from-blue-600 to-blue-700";
  };

  // Usar a categoria explícita do post ou inferir das keywords se não existir
  const category = post.category || getCategoryFromKeywords(post.keywords);
  const categoryColor = getCategoryColor(category);
  const postUrl = `/blog/post/${post.id}/${post.title.toLowerCase().replace(/[^\w\s]/gi, '').replace(/\s+/g, '-')}`;

  // Extrair uma descrição curta do conteúdo
  const getShortDescription = (content: string): string => {
    const stripped = content.replace(/<[^>]*>?/gm, '');
    return stripped.length > 160 ? stripped.substring(0, 157) + "..." : stripped;
  };

  const shortDescription = post.metaDescription || getShortDescription(post.content);

  if (featured) {
    return (
      <div className="bg-white rounded-xl overflow-hidden shadow-xl mb-8 hover:shadow-2xl transition-all duration-300 border border-gray-100 group">
        <div className="relative">
          {post.imageUrl ? (
            <img 
              src={imageUrl || ""} 
              alt={post.title} 
              onError={handleImageError}
              className="w-full h-[450px] object-cover transform group-hover:scale-105 transition-transform duration-700" 
            />
          ) : (
            <div className="w-full h-[450px] bg-gradient-to-br from-blue-100 to-indigo-200 flex items-center justify-center">
              <div className="flex flex-col items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-blue-500 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                </svg>
                <span className="text-blue-700 text-xl font-bold">TrendPulsee</span>
              </div>
            </div>
          )}
          
          {/* Overlay gradiente mais suave e bonito */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent opacity-90 group-hover:opacity-80 transition-opacity duration-300"></div>
          
          <div className="absolute bottom-0 left-0 p-8 w-full">
            <div className="flex items-center space-x-2 mb-4">
              <span className={`${categoryColor} text-white text-xs uppercase font-bold rounded-full px-3 py-1 shadow-md`}>
                {category}
              </span>
              <span className="text-gray-200 text-sm flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                {formattedDate}
              </span>
            </div>
            
            <h2 className="text-3xl md:text-4xl font-bold mb-3 text-white group-hover:text-blue-200 transition duration-300 leading-tight">
              <Link href={postUrl}>
                <span className="cursor-pointer bg-gradient-to-r from-white to-white bg-clip-text">{post.title}</span>
              </Link>
            </h2>
            
            <p className="text-gray-200 mb-5 line-clamp-3 md:text-lg max-w-3xl">{shortDescription}</p>
            
            <Link href={postUrl}>
              <span className="inline-block bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-6 py-3 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition duration-300 cursor-pointer font-medium shadow-lg transform group-hover:translate-y-[-3px]">
                Ler artigo completo
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2 inline" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </span>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 border border-gray-100 group hover:translate-y-[-5px]">
      <div className="relative h-52 overflow-hidden">
        {post.imageUrl ? (
          <img 
            src={imageUrl || ""} 
            alt={post.title}
            onError={handleImageError}
            className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700" 
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-blue-100 to-indigo-200 flex items-center justify-center">
            <div className="flex flex-col items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-blue-500 mb-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
              </svg>
              <span className="text-blue-700 text-sm font-bold">TrendPulsee</span>
            </div>
          </div>
        )}
        
        {/* Overlay sutil para melhorar contraste do badge de categoria */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/10 to-transparent"></div>
        
        <div className="absolute top-0 left-0 m-3 z-10">
          <span className={`${categoryColor} text-white text-xs uppercase font-bold rounded-full px-3 py-1 shadow-md`}>
            {category}
          </span>
        </div>
      </div>
      
      <div className="p-5">
        <div className="text-gray-500 mb-2 text-sm flex items-center">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          {formattedDate}
        </div>
        
        <h3 className="text-xl font-bold mb-3 group-hover:text-blue-600 transition duration-200 line-clamp-2 leading-tight">
          <Link href={postUrl}>
            <span className="cursor-pointer">{post.title}</span>
          </Link>
        </h3>
        
        <p className="text-gray-600 mb-4 text-sm line-clamp-2">{shortDescription}</p>
        
        <Link href={postUrl}>
          <span className="text-blue-600 font-medium hover:text-blue-800 transition duration-200 flex items-center cursor-pointer group-hover:translate-x-1">
            Ler artigo
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1 group-hover:ml-2 transition-all duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
            </svg>
          </span>
        </Link>
      </div>
    </div>
  );
}