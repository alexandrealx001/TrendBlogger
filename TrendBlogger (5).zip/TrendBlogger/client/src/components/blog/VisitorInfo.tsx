import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { User, LogOut, Calendar, Mail, Hash } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Visitor } from "./LoginForm";
import axios from "axios";
import { useToast } from "@/hooks/use-toast";

interface VisitorInfoProps {
  onLogout?: () => void;
}

export function VisitorInfo({ onLogout }: VisitorInfoProps) {
  const { toast } = useToast();
  const [visitor, setVisitor] = useState<Visitor | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchVisitor() {
      try {
        setIsLoading(true);
        const response = await axios.get('/api/blog/visitor');
        if (response.status === 200) {
          setVisitor(response.data);
        }
      } catch (error) {
        console.error("Erro ao carregar informações do visitante:", error);
        toast({
          title: "Erro",
          description: "Não foi possível carregar suas informações.",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchVisitor();
  }, [toast]);

  // Função para logout
  const handleLogout = async () => {
    try {
      await axios.post('/api/blog/logout');
      
      toast({
        title: "Logout realizado",
        description: "Você saiu da sua conta."
      });
      
      if (onLogout) {
        onLogout();
      }
    } catch (error) {
      console.error("Erro ao fazer logout:", error);
      toast({
        title: "Erro ao sair",
        description: "Não foi possível fazer logout.",
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="p-6">
          <div className="flex justify-center">
            <div className="animate-pulse h-24 w-full flex items-center justify-center">
              <p className="text-muted-foreground">Carregando informações...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!visitor) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardContent className="p-6">
          <div className="flex flex-col items-center gap-4">
            <div className="bg-muted p-6 rounded-full">
              <User size={32} className="text-muted-foreground" />
            </div>
            <div className="text-center">
              <h3 className="font-medium text-lg">Não está logado</h3>
              <p className="text-muted-foreground text-sm mt-1">
                Faça login para acessar seu perfil
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calcula a data do último login
  const formatLastLogin = () => {
    if (!visitor.lastLogin) return "Primeira visita";
    
    const date = new Date(visitor.lastLogin);
    return new Intl.DateTimeFormat('pt-BR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <div className="bg-primary/10 p-2 rounded-full">
            <User size={20} className="text-primary" />
          </div>
          Perfil do Visitante
        </CardTitle>
        <CardDescription>
          Suas informações de acesso ao blog
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col gap-5">
          {/* Avatar e nome */}
          <div className="flex flex-col items-center gap-3 mb-2">
            {visitor.photoUrl ? (
              <img 
                src={visitor.photoUrl} 
                alt={visitor.name} 
                className="rounded-full w-20 h-20 object-cover border-4 border-primary/20"
              />
            ) : (
              <div className="bg-gradient-to-r from-primary/20 to-primary/10 w-20 h-20 rounded-full flex items-center justify-center">
                <span className="text-primary text-xl font-semibold">
                  {visitor.name.split(' ').map(n => n[0]).slice(0, 2).join('')}
                </span>
              </div>
            )}
            <h3 className="text-xl font-medium text-center">{visitor.name}</h3>
          </div>

          {/* Informações */}
          <div className="space-y-3 text-sm">
            <div className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
              <Mail size={16} className="text-muted-foreground" />
              <span className="text-muted-foreground">Email:</span>
              <span className="font-medium ml-auto">{visitor.email}</span>
            </div>

            {visitor.cpf && (
              <div className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
                <Hash size={16} className="text-muted-foreground" />
                <span className="text-muted-foreground">CPF:</span>
                <span className="font-medium ml-auto">{visitor.cpf}</span>
              </div>
            )}
            
            {visitor.birthDate && (
              <div className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
                <Calendar size={16} className="text-muted-foreground" />
                <span className="text-muted-foreground">Data de Nascimento:</span>
                <span className="font-medium ml-auto">{visitor.birthDate}</span>
              </div>
            )}
            
            <div className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
              <Calendar size={16} className="text-muted-foreground" />
              <span className="text-muted-foreground">Último acesso:</span>
              <span className="font-medium ml-auto">{formatLastLogin()}</span>
            </div>
            
            <div className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
              <Hash size={16} className="text-muted-foreground" />
              <span className="text-muted-foreground">Número de acessos:</span>
              <span className="font-medium ml-auto">{visitor.loginCount}</span>
            </div>
          </div>

          {/* Botão de logout */}
          <Button 
            variant="outline" 
            size="sm" 
            className="w-full mt-4" 
            onClick={handleLogout}
          >
            <LogOut size={16} className="mr-2" />
            Sair da conta
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}