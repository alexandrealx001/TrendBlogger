import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { User, UserRound, LogOut } from "lucide-react";
import { LoginForm, Visitor } from "./LoginForm";
import axios from "axios";
import { useToast } from "@/hooks/use-toast";
import { useLogin } from "@/contexts/LoginContext";

export function BlogLoginButton() {
  const { toast } = useToast();
  const { 
    isLoginModalOpen, 
    openLoginModal, 
    closeLoginModal, 
    activeTab 
  } = useLogin();
  
  const [visitor, setVisitor] = useState<Visitor | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Busca o visitante logado ao carregar o componente
  useEffect(() => {
    async function fetchVisitor() {
      try {
        setIsLoading(true);
        const response = await axios.get('/api/blog/visitor');
        if (response.status === 200) {
          setVisitor(response.data);
        }
      } catch (error) {
        // Não está logado, não é um erro
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchVisitor();
  }, []);

  // Função para logout
  const handleLogout = async () => {
    try {
      await axios.post('/api/blog/logout');
      setVisitor(null);
      toast({
        title: "Logout realizado",
        description: "Você saiu da sua conta."
      });
    } catch (error) {
      console.error("Erro ao fazer logout:", error);
      toast({
        title: "Erro ao sair",
        description: "Não foi possível fazer logout.",
        variant: "destructive"
      });
    }
  };

  // Quando o login é bem-sucedido
  const handleLoginSuccess = (visitorData: Visitor) => {
    setVisitor(visitorData);
    closeLoginModal();
  };

  // Componente interno que mostra informações do visitante logado
  function VisitorInfo() {
    if (!visitor) return null;
    
    return (
      <div className="flex flex-col items-center gap-2 p-4">
        <div className="flex items-center gap-3">
          {visitor.photoUrl ? (
            <img 
              src={visitor.photoUrl} 
              alt={visitor.name} 
              className="rounded-full w-12 h-12 object-cover"
            />
          ) : (
            <div className="bg-primary/10 rounded-full w-12 h-12 flex items-center justify-center text-primary">
              <UserRound size={24} />
            </div>
          )}
          <div>
            <h4 className="font-medium">{visitor.name}</h4>
            <p className="text-sm text-muted-foreground">{visitor.email}</p>
          </div>
        </div>

        <div className="text-xs text-center text-muted-foreground mt-1">
          <p>Último acesso: {new Date(visitor.lastLogin).toLocaleDateString()}</p>
          <p>Acessos: {visitor.loginCount}</p>
        </div>
        
        <Button 
          variant="outline" 
          size="sm" 
          className="mt-2 w-full" 
          onClick={handleLogout}
        >
          <LogOut className="mr-2 h-4 w-4" /> Sair da conta
        </Button>
      </div>
    );
  }

  // O botão muda de acordo com o estado de login
  return (
    <Dialog 
      open={isLoginModalOpen} 
      onOpenChange={(open) => open ? openLoginModal() : closeLoginModal()}
    >
      <DialogTrigger asChild>
        <Button 
          variant="ghost" 
          size="sm" 
          className="gap-2"
          disabled={isLoading}
        >
          {visitor ? (
            <>
              <User size={16} />
              <span className="hidden md:inline">{visitor.name.split(' ')[0]}</span>
            </>
          ) : (
            <>
              <UserRound size={16} />
              <span className="hidden md:inline">Entrar</span>
            </>
          )}
        </Button>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-md">
        <DialogTitle className="text-center">
          {visitor ? "Informações da conta" : "Entrar no Blog"}
        </DialogTitle>
        
        {visitor ? (
          <VisitorInfo />
        ) : (
          <LoginForm onSuccess={handleLoginSuccess} initialTab={activeTab} />
        )}
      </DialogContent>
    </Dialog>
  );
}