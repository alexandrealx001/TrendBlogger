import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import GeneratePostModal from "../modals/GeneratePostModal";
import { Sparkles, Calendar, Settings } from "lucide-react";

export default function QuickActions() {
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedAction, setSelectedAction] = useState<string | null>(null);

  const handleGenerateSinglePost = () => {
    setSelectedAction("single");
    setIsModalOpen(true);
  };

  const handleScheduleGeneration = () => {
    toast({
      title: "Configure Agendamentos",
      description: "Redirecionando para a página de agendamentos...",
    });

    // In a real app, this would navigate to the Scheduler page
    setTimeout(() => {
      window.location.href = "/scheduler";
    }, 1000);
  };

  const handleConfigureAPI = () => {
    toast({
      title: "Configure API Keys",
      description: "Redirecionando para as configurações de API...",
    });

    // In a real app, this would navigate to the Settings page
    setTimeout(() => {
      window.location.href = "/settings";
    }, 1000);
  };

  return (
    <div className="mb-6">
      <h2 className="text-lg font-medium text-neutral-900 mb-4">Ações Rápidas</h2>
      
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
        {/* Generate Single Post Card */}
        <div className="bg-white overflow-hidden shadow rounded-lg border border-neutral-200 hover:border-primary-500 transition-colors">
          <div className="px-4 py-5 sm:p-6">
            <div className="flex flex-col items-center text-center">
              <div className="flex-shrink-0 bg-primary-100 rounded-full p-3 mb-4">
                <Sparkles className="h-6 w-6 text-primary-600" />
              </div>
              <h3 className="text-lg font-medium text-neutral-900 mb-2">Gerar Post Único</h3>
              <p className="text-sm text-neutral-600 mb-4">Crie um post de blog otimizado com base em uma tendência atual.</p>
              <button 
                type="button" 
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                onClick={handleGenerateSinglePost}
              >
                Gerar Agora
              </button>
            </div>
          </div>
        </div>

        {/* Schedule Generation Card */}
        <div className="bg-white overflow-hidden shadow rounded-lg border border-neutral-200 hover:border-secondary-500 transition-colors">
          <div className="px-4 py-5 sm:p-6">
            <div className="flex flex-col items-center text-center">
              <div className="flex-shrink-0 bg-secondary-100 rounded-full p-3 mb-4">
                <Calendar className="h-6 w-6 text-secondary-600" />
              </div>
              <h3 className="text-lg font-medium text-neutral-900 mb-2">Agendar Geração</h3>
              <p className="text-sm text-neutral-600 mb-4">Configure um cronograma para geração automática de posts.</p>
              <button 
                type="button" 
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-secondary-600 hover:bg-secondary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-secondary-500"
                onClick={handleScheduleGeneration}
              >
                Configurar
              </button>
            </div>
          </div>
        </div>

        {/* Configure API Card */}
        <div className="bg-white overflow-hidden shadow rounded-lg border border-neutral-200 hover:border-neutral-400 transition-colors">
          <div className="px-4 py-5 sm:p-6">
            <div className="flex flex-col items-center text-center">
              <div className="flex-shrink-0 bg-neutral-100 rounded-full p-3 mb-4">
                <Settings className="h-6 w-6 text-neutral-600" />
              </div>
              <h3 className="text-lg font-medium text-neutral-900 mb-2">Configurar API</h3>
              <p className="text-sm text-neutral-600 mb-4">Configure suas chaves de API e preferências de geração.</p>
              <button 
                type="button" 
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-neutral-700 bg-neutral-100 hover:bg-neutral-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-neutral-500"
                onClick={handleConfigureAPI}
              >
                Configurar
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Generate Post Modal */}
      <GeneratePostModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        initialTrend=""
      />
    </div>
  );
}
