import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useCreateApiKey, useUpdateApiKey } from "@/hooks/useApiKeys";
import { ApiKey } from "@shared/schema";

interface ApiKeyFormProps {
  apiKey?: ApiKey;
  service: string;
  title: string;
  description: string;
  placeholder?: string;
}

export default function ApiKeyForm({ apiKey, service, title, description, placeholder }: ApiKeyFormProps) {
  const { toast } = useToast();
  const [key, setKey] = useState(apiKey?.key || "");
  const [isActive, setIsActive] = useState(apiKey?.isActive !== false);
  const [isEditing, setIsEditing] = useState(!apiKey);
  const [isLoading, setIsLoading] = useState(false);

  const createApiKey = useCreateApiKey();
  const updateApiKey = useUpdateApiKey();

  const handleSubmit = async () => {
    if (!key.trim()) {
      toast({
        title: "Chave API obrigatória",
        description: "Por favor, informe uma chave API válida.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      if (apiKey) {
        // Update existing API key
        await updateApiKey.mutateAsync({
          id: apiKey.id,
          data: {
            key,
            isActive
          }
        });
      } else {
        // Create new API key
        await createApiKey.mutateAsync({
          service,
          key,
          isActive
        });
      }

      toast({
        title: "Chave API salva",
        description: "Sua chave API foi salva com sucesso.",
      });

      setIsEditing(false);
    } catch (error: any) {
      toast({
        title: "Erro ao salvar chave API",
        description: error.message || "Ocorreu um erro ao salvar a chave API. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4">
          <div className="flex items-center justify-between">
            <Label htmlFor={`${service}-key`}>Status</Label>
            <div className="flex items-center space-x-2">
              <Switch
                id={`${service}-active`}
                checked={isActive}
                onCheckedChange={setIsActive}
                disabled={!isEditing}
              />
              <Label htmlFor={`${service}-active`}>
                {isActive ? "Ativo" : "Inativo"}
              </Label>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor={`${service}-key`}>Chave API</Label>
            {isEditing ? (
              <Input
                id={`${service}-key`}
                placeholder={placeholder || "Insira sua chave API..."}
                value={key}
                onChange={(e) => setKey(e.target.value)}
                type="password"
              />
            ) : (
              <div className="flex items-center space-x-2">
                <Input
                  id={`${service}-key-display`}
                  value="••••••••••••••••••••••••••"
                  disabled
                  type="text"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsEditing(true)}
                >
                  Editar
                </Button>
              </div>
            )}
          </div>
        </div>
      </CardContent>
      {isEditing && (
        <CardFooter className="justify-between space-x-2">
          {apiKey && (
            <Button
              variant="ghost"
              onClick={() => {
                setKey(apiKey.key);
                setIsActive(apiKey.isActive !== false);
                setIsEditing(false);
              }}
            >
              Cancelar
            </Button>
          )}
          <Button
            onClick={handleSubmit}
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <span className="inline-block animate-spin mr-2">&#8635;</span> Salvando...
              </>
            ) : (
              "Salvar"
            )}
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}
