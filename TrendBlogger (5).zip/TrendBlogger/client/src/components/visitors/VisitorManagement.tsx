import { useState } from 'react';
import { useVisitors } from '@/hooks/useVisitors';
import { Visitor } from '@/types';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Loader2, Trash2, Search, Users } from "lucide-react";
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function VisitorManagement() {
  const { visitors, isLoading, deleteVisitor, isDeleting, getVisitorStats } = useVisitors();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedVisitorId, setSelectedVisitorId] = useState<number | null>(null);
  
  // Estatísticas de visitantes
  const stats = getVisitorStats();

  // Filtrar visitantes pelo termo de busca
  const filteredVisitors = visitors.filter((visitor: Visitor) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      visitor.name?.toLowerCase().includes(searchLower) ||
      visitor.email.toLowerCase().includes(searchLower) ||
      visitor.googleId.toLowerCase().includes(searchLower)
    );
  });

  // Formatador de data
  const formatDate = (date: string | Date | null) => {
    if (!date) return 'Nunca';
    return format(new Date(date), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR });
  };

  // Função para confirmar exclusão
  const handleDeleteConfirm = () => {
    if (selectedVisitorId !== null) {
      deleteVisitor(selectedVisitorId);
      setSelectedVisitorId(null);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-10 h-10 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <Card className="flex-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Total de Visitantes</CardTitle>
            <CardDescription>Número total de visitantes registrados</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Users className="mr-2 h-6 w-6 text-muted-foreground" />
              <span className="text-3xl font-bold">{stats.total}</span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="flex-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Visitantes na Última Semana</CardTitle>
            <CardDescription>Visitantes ativos nos últimos 7 dias</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Users className="mr-2 h-6 w-6 text-blue-500" />
              <span className="text-3xl font-bold">{stats.lastWeek}</span>
            </div>
          </CardContent>
        </Card>
        
        <Card className="flex-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Visitantes Hoje</CardTitle>
            <CardDescription>Visitantes que entraram hoje</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Users className="mr-2 h-6 w-6 text-green-500" />
              <span className="text-3xl font-bold">{stats.today}</span>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold">Gerenciamento de Visitantes</h2>
        <div className="relative w-64">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar visitantes..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>ID</TableHead>
                  <TableHead>Nome</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Último Login</TableHead>
                  <TableHead>Contagem de Login</TableHead>
                  <TableHead>Registrado em</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredVisitors && filteredVisitors.length > 0 ? (
                  filteredVisitors.map((visitor: Visitor) => (
                    <TableRow key={visitor.id}>
                      <TableCell>{visitor.id}</TableCell>
                      <TableCell>{visitor.name || 'Sem nome'}</TableCell>
                      <TableCell>{visitor.email}</TableCell>
                      <TableCell>{formatDate(visitor.lastLogin)}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{visitor.loginCount || 0}</Badge>
                      </TableCell>
                      <TableCell>{formatDate(visitor.createdAt)}</TableCell>
                      <TableCell>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => setSelectedVisitorId(visitor.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
                              <AlertDialogDescription>
                                Tem certeza que deseja excluir este visitante? Esta ação não pode ser desfeita.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel onClick={() => setSelectedVisitorId(null)}>
                                Cancelar
                              </AlertDialogCancel>
                              <AlertDialogAction
                                onClick={handleDeleteConfirm}
                                disabled={isDeleting}
                                className="bg-red-500 hover:bg-red-600"
                              >
                                {isDeleting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                                Excluir
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-6 text-muted-foreground">
                      {searchTerm
                        ? 'Nenhum visitante encontrado com esses termos de busca.'
                        : 'Nenhum visitante registrado.'}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}