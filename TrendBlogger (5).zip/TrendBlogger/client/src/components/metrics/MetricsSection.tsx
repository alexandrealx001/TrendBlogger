import { Card, CardContent } from "@/components/ui/card";
import { useMetrics } from "@/hooks/useMetrics";
import { 
  FileText, 
  TrendingUp, 
  Upload, 
  Calendar 
} from "lucide-react";

interface MetricCardProps {
  icon: React.ReactNode;
  bgColor: string;
  iconColor: string;
  title: string;
  value: number | string;
  isLoading: boolean;
}

function MetricCard({ icon, iconColor, bgColor, title, value, isLoading }: MetricCardProps) {
  return (
    <Card>
      <CardContent className="px-4 py-5 sm:p-6">
        <div className="flex items-center">
          <div className={`flex-shrink-0 ${bgColor} rounded-md p-3`}>
            {icon}
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-neutral-500 truncate">
                {title}
              </dt>
              <dd>
                <div className="text-lg font-medium text-neutral-900">
                  {isLoading ? "..." : value}
                </div>
              </dd>
            </dl>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function MetricsSection() {
  const { data: metrics, isLoading } = useMetrics();

  return (
    <div className="mb-6">
      <h2 className="text-lg font-medium text-neutral-900 mb-4">Métricas</h2>
      
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          icon={<FileText className="h-6 w-6 text-primary-600" />}
          iconColor="text-primary-600"
          bgColor="bg-primary-100"
          title="Posts Gerados"
          value={metrics?.totalPosts || 0}
          isLoading={isLoading}
        />
        
        <MetricCard
          icon={<TrendingUp className="h-6 w-6 text-secondary-600" />}
          iconColor="text-secondary-600"
          bgColor="bg-secondary-100"
          title="Tendências Processadas"
          value={metrics?.processTrends || 0}
          isLoading={isLoading}
        />
        
        <MetricCard
          icon={<Upload className="h-6 w-6 text-green-600" />}
          iconColor="text-green-600"
          bgColor="bg-green-100"
          title="Posts Publicados"
          value={metrics?.publishedPosts || 0}
          isLoading={isLoading}
        />
        
        <MetricCard
          icon={<Calendar className="h-6 w-6 text-amber-600" />}
          iconColor="text-amber-600"
          bgColor="bg-amber-100"
          title="Agendamentos Ativos"
          value={metrics?.activeSchedules || 0}
          isLoading={isLoading}
        />
      </div>
    </div>
  );
}
