import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

interface GeneratePostModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTrend: string;
}

export default function GeneratePostModal({ isOpen, onClose, initialTrend }: GeneratePostModalProps) {
  const { toast } = useToast();
  const [isGenerating, setIsGenerating] = useState(false);
  
  const [trend, setTrend] = useState(initialTrend);
  const [contentType, setContentType] = useState("Artigo informativo");
  const [seoOptimization, setSeoOptimization] = useState(true);
  const [useRelatedKeywords, setUseRelatedKeywords] = useState(true);
  const [addMetaDescription, setAddMetaDescription] = useState(true);
  const [findRelevantImage, setFindRelevantImage] = useState(true);
  const [useRecentNews, setUseRecentNews] = useState(true);
  const [wordCount, setWordCount] = useState("Médio (800-1200 palavras)");
  const [postAction, setPostAction] = useState("Salvar como rascunho");

  // Reset form when modal opens with a new trend
  // O uso correto é com useEffect, não useState
  useEffect(() => {
    if (isOpen && initialTrend) {
      setTrend(initialTrend);
      console.log("Modal aberto com tendência:", initialTrend);
    }
  }, [isOpen, initialTrend]);

  const handleSubmit = async () => {
    if (!trend.trim()) {
      toast({
        title: "Tendência Obrigatória",
        description: "Por favor, informe uma tendência para gerar o post.",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);

    try {
      // Map Portuguese content type to English
      const contentTypeMap: Record<string, string> = {
        "Artigo informativo": "Article",
        "Tutorial": "Tutorial",
        "Análise/Review": "Review",
        "Lista (Top 10)": "List",
        "Perguntas e Respostas": "Q&A"
      };
      
      // Map word count to English options
      const wordCountMap: Record<string, string> = {
        "Curto (500-800 palavras)": "short",
        "Médio (800-1200 palavras)": "medium",
        "Longo (1200-2000 palavras)": "long",
        "Aprofundado (2000+ palavras)": "in-depth"
      };

      // Determine post action
      const action = postAction === "Publicar automaticamente" ? "publish" : "draft";

      console.log("Gerando post com os seguintes parâmetros:");
      console.log({
        trend,
        contentType: contentTypeMap[contentType] || "Article",
        wordCount: wordCountMap[wordCount] || "medium",
        postAction: action
      });

      // Make API request to generate post
      await apiRequest("POST", "/api/generate", {
        trend,
        contentType: contentTypeMap[contentType] || "Article",
        seoOptimization,
        useRelatedKeywords,
        addMetaDescription,
        findRelevantImage,
        useRecentNews,
        wordCount: wordCountMap[wordCount] || "medium",
        postAction: action,
      });

      // Invalidate queries to refresh posts list
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });

      toast({
        title: "Post Gerado com Sucesso",
        description: "O post foi gerado com sucesso e está disponível na lista de posts.",
      });

      // Close modal
      onClose();
    } catch (error: any) {
      toast({
        title: "Erro ao Gerar Post",
        description: error.message || "Ocorreu um erro ao gerar o post. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[600px] md:max-w-[700px] lg:max-w-[800px]">
        <DialogHeader>
          <DialogTitle>Gerar Novo Post</DialogTitle>
          <DialogDescription>
            Configure os parâmetros para gerar um novo post de blog baseado em tendências atuais.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="trend-input" className="text-right">
              Tendência
            </Label>
            <Input
              id="trend-input"
              value={trend}
              onChange={(e) => setTrend(e.target.value)}
              className="col-span-3"
              placeholder="Digite uma tendência atual"
            />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="content-type" className="text-right">
              Tipo de Conteúdo
            </Label>
            <Select
              value={contentType}
              onValueChange={setContentType}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Selecione o tipo de conteúdo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Artigo informativo">Artigo informativo</SelectItem>
                <SelectItem value="Tutorial">Tutorial</SelectItem>
                <SelectItem value="Análise/Review">Análise/Review</SelectItem>
                <SelectItem value="Lista (Top 10)">Lista (Top 10)</SelectItem>
                <SelectItem value="Perguntas e Respostas">Perguntas e Respostas</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-4 items-start gap-4">
            <Label className="text-right pt-2">Otimização</Label>
            <div className="col-span-3 space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="seo-optimization"
                  checked={seoOptimization}
                  onCheckedChange={(checked) => setSeoOptimization(checked as boolean)}
                />
                <Label htmlFor="seo-optimization">Otimização para SEO</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="use-related-keywords"
                  checked={useRelatedKeywords}
                  onCheckedChange={(checked) => setUseRelatedKeywords(checked as boolean)}
                />
                <Label htmlFor="use-related-keywords">Usar palavras-chave relacionadas</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="add-meta-description"
                  checked={addMetaDescription}
                  onCheckedChange={(checked) => setAddMetaDescription(checked as boolean)}
                />
                <Label htmlFor="add-meta-description">Adicionar meta description</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="find-relevant-image"
                  checked={findRelevantImage}
                  onCheckedChange={(checked) => setFindRelevantImage(checked as boolean)}
                />
                <Label htmlFor="find-relevant-image">Buscar imagem relevante</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="use-recent-news"
                  checked={useRecentNews}
                  onCheckedChange={(checked) => setUseRecentNews(checked as boolean)}
                />
                <Label htmlFor="use-recent-news">Buscar informações recentes (última semana)</Label>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="word-count" className="text-right">
              Contagem de palavras
            </Label>
            <Select
              value={wordCount}
              onValueChange={setWordCount}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Selecione a contagem de palavras" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Curto (500-800 palavras)">Curto (500-800 palavras)</SelectItem>
                <SelectItem value="Médio (800-1200 palavras)">Médio (800-1200 palavras)</SelectItem>
                <SelectItem value="Longo (1200-2000 palavras)">Longo (1200-2000 palavras)</SelectItem>
                <SelectItem value="Aprofundado (2000+ palavras)">Aprofundado (2000+ palavras)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="post-action" className="text-right">
              Após gerar
            </Label>
            <Select
              value={postAction}
              onValueChange={setPostAction}
            >
              <SelectTrigger className="col-span-3">
                <SelectValue placeholder="Selecione a ação após gerar" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Salvar como rascunho">Salvar como rascunho</SelectItem>
                <SelectItem value="Publicar automaticamente">Publicar automaticamente</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={isGenerating}
          >
            {isGenerating ? (
              <>
                <span className="inline-block animate-spin mr-2">&#8635;</span> Gerando...
              </>
            ) : (
              "Gerar Post"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
