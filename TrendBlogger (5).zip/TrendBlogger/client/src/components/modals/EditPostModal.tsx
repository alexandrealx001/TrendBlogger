import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Post } from "@shared/schema";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface EditPostModalProps {
  isOpen: boolean;
  onClose: () => void;
  post: Post | null;
}

export default function EditPostModal({ isOpen, onClose, post }: EditPostModalProps) {
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [metaDescription, setMetaDescription] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [keywords, setKeywords] = useState("");
  const [category, setCategory] = useState("tecnologia");

  // Carrega os dados do post quando o modal é aberto
  useEffect(() => {
    if (isOpen && post) {
      setTitle(post.title || "");
      setContent(post.content || "");
      setMetaDescription(post.metaDescription || "");
      setImageUrl(post.imageUrl || "");
      setKeywords(post.keywords ? post.keywords.join(", ") : "");
      setCategory(post.category || "tecnologia");
    }
  }, [isOpen, post]);

  const handleSubmit = async () => {
    if (!title.trim()) {
      toast({
        title: "Título Obrigatório",
        description: "Por favor, informe um título para o post.",
        variant: "destructive",
      });
      return;
    }

    if (!content.trim()) {
      toast({
        title: "Conteúdo Obrigatório",
        description: "Por favor, adicione conteúdo ao post.",
        variant: "destructive",
      });
      return;
    }

    if (!post || !post.id) {
      toast({
        title: "Erro",
        description: "Não foi possível identificar o post para edição.",
        variant: "destructive",
      });
      return;
    }

    setIsSaving(true);

    try {
      // Prepara as palavras-chave como um array
      const keywordsArray = keywords
        .split(",")
        .map(k => k.trim())
        .filter(k => k.length > 0);

      // Faz a requisição para atualizar o post
      await apiRequest("PATCH", `/api/posts/${post.id}`, {
        title,
        content,
        metaDescription,
        imageUrl,
        keywords: keywordsArray,
        category
      });

      // Invalidar queries para atualizar lista de posts
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/metrics"] });
      
      // Invalidar queries do blog se o post estiver publicado
      if (post.status === "published") {
        queryClient.invalidateQueries({ queryKey: ["blog-posts"] });
        queryClient.invalidateQueries({ queryKey: ["blog-post", post.id] });
      }

      toast({
        title: "Post Atualizado",
        description: "O post foi atualizado com sucesso.",
      });

      // Fechar modal
      onClose();
    } catch (error: any) {
      toast({
        title: "Erro ao Atualizar Post",
        description: error.message || "Ocorreu um erro ao atualizar o post. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[90vw] md:max-w-[80vw] lg:max-w-[1200px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editar Post</DialogTitle>
          <DialogDescription>
            Modifique os dados do post conforme necessário.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="title-input" className="text-right">
              Título
            </Label>
            <Input
              id="title-input"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="col-span-3"
              placeholder="Título do post"
            />
          </div>

          <div className="grid grid-cols-4 items-start gap-4">
            <Label htmlFor="content-input" className="text-right mt-2">
              Conteúdo
            </Label>
            <Textarea
              id="content-input"
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="col-span-3 min-h-[500px]"
              placeholder="Conteúdo HTML do post"
              rows={20}
              maxLength={100000}
            />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="metadesc-input" className="text-right">
              Meta Description
            </Label>
            <Input
              id="metadesc-input"
              value={metaDescription}
              onChange={(e) => setMetaDescription(e.target.value)}
              className="col-span-3"
              placeholder="Descrição para SEO"
            />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="image-input" className="text-right">
              URL da Imagem
            </Label>
            <Input
              id="image-input"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="col-span-3"
              placeholder="URL da imagem do post"
            />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="keywords-input" className="text-right">
              Palavras-chave
            </Label>
            <Input
              id="keywords-input"
              value={keywords}
              onChange={(e) => setKeywords(e.target.value)}
              className="col-span-3"
              placeholder="Palavras-chave separadas por vírgula"
            />
          </div>

          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="category-input" className="text-right">
              Categoria
            </Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger id="category-input" className="col-span-3">
                <SelectValue placeholder="Selecione uma categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="tecnologia">Tecnologia</SelectItem>
                <SelectItem value="negocios">Negócios</SelectItem>
                <SelectItem value="financas">Finanças</SelectItem>
                <SelectItem value="saude">Saúde</SelectItem>
                <SelectItem value="politica">Política</SelectItem>
                <SelectItem value="esportes">Esportes</SelectItem>
                <SelectItem value="sustentabilidade">Sustentabilidade</SelectItem>
                <SelectItem value="educacao">Educação</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button 
            onClick={handleSubmit} 
            disabled={isSaving}
          >
            {isSaving ? (
              <>
                <span className="inline-block animate-spin mr-2">&#8635;</span> Salvando...
              </>
            ) : (
              "Salvar Alterações"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}