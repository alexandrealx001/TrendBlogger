import { Link } from "wouter";
import { usePosts } from "@/hooks/usePosts";
import { FileText, MoreVertical } from "lucide-react";
import { Post } from "@shared/schema";

export default function RecentPosts() {
  const { data: posts, isLoading } = usePosts(5);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "published":
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
            Publicado
          </span>
        );
      case "draft":
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
            Rascunho
          </span>
        );
      case "error":
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
            Erro
          </span>
        );
      default:
        return (
          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-neutral-100 text-neutral-800">
            {status}
          </span>
        );
    }
  };

  const formatRelativeTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return 'Agora';
    }
    
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    if (diffInMinutes < 60) {
      return `Há ${diffInMinutes} ${diffInMinutes === 1 ? 'minuto' : 'minutos'}`;
    }
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) {
      return `Há ${diffInHours} ${diffInHours === 1 ? 'hora' : 'horas'}`;
    }
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 30) {
      return `Há ${diffInDays} ${diffInDays === 1 ? 'dia' : 'dias'}`;
    }
    
    const diffInMonths = Math.floor(diffInDays / 30);
    return `Há ${diffInMonths} ${diffInMonths === 1 ? 'mês' : 'meses'}`;
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-medium text-neutral-900">Posts Recentes</h2>
        <button 
          onClick={() => window.location.href = "/posts"}
          className="text-sm font-medium text-primary hover:text-primary/80"
        >
          Ver todos
        </button>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-neutral-200">
          {isLoading ? (
            Array(5)
              .fill(0)
              .map((_, i) => (
                <li key={i} className="px-4 py-4 sm:px-6 animate-pulse">
                  <div className="flex items-center space-x-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-neutral-200 rounded"></div>
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="h-5 bg-neutral-200 rounded w-3/4"></div>
                      <div className="h-3 bg-neutral-200 rounded w-1/4"></div>
                    </div>
                    <div className="flex-shrink-0">
                      <div className="h-6 w-20 bg-neutral-200 rounded"></div>
                    </div>
                  </div>
                </li>
              ))
          ) : posts && posts.length > 0 ? (
            posts.map((post: Post) => (
              <li key={post.id} className="px-4 py-4 sm:px-6 hover:bg-neutral-50">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-neutral-200 rounded overflow-hidden">
                    {post.imageUrl ? (
                      <img
                        src={post.imageUrl}
                        alt={post.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-primary-100 text-primary-600">
                        <FileText className="h-5 w-5" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-neutral-900 truncate">
                      {post.title}
                    </p>
                    <p className="text-xs text-neutral-500">
                      Gerado {post.createdAt ? formatRelativeTime(post.createdAt.toString()) : ''}
                    </p>
                  </div>
                  <div className="flex-shrink-0 flex items-center space-x-1">
                    {getStatusBadge(post.status || "draft")}
                    <button
                      type="button"
                      className="p-1 rounded-full text-neutral-400 hover:text-neutral-500 focus:outline-none"
                    >
                      <MoreVertical className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </li>
            ))
          ) : (
            <li className="px-4 py-4 sm:px-6 text-center text-neutral-500">
              Nenhum post gerado. Gere seu primeiro post!
            </li>
          )}
        </ul>
      </div>
    </div>
  );
}
