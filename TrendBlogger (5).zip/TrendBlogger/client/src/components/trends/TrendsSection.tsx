import { useState } from "react";
import { useTrends } from "@/hooks/useTrends";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Trend } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import GeneratePostModal from "../modals/GeneratePostModal";

export default function TrendsSection() {
  const { toast } = useToast();
  const { trends, isLoading, isRefetching } = useTrends(5);
  const [refreshing, setRefreshing] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTrend, setSelectedTrend] = useState<string>("");

  const handleRefresh = async () => {
    setRefreshing(true);
    try {
      await apiRequest("POST", "/api/trends/update", {});
      
      queryClient.invalidateQueries({ queryKey: ["/api/trends"] });
      
      toast({
        title: "Tendências atualizadas",
        description: "As tendências foram atualizadas com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro ao atualizar tendências",
        description: "Ocorreu um erro ao atualizar as tendências. Tente novamente.",
        variant: "destructive",
      });
    } finally {
      setRefreshing(false);
    }
  };

  const handleGenerateFromTrend = (trend: Trend) => {
    setSelectedTrend(trend.title);
    setIsModalOpen(true);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-medium text-neutral-900">Tendências Atuais</h2>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRefresh}
          disabled={refreshing || isRefetching}
          className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-primary-700 bg-primary-100 hover:bg-primary-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
        >
          {refreshing || isRefetching ? (
            <>
              <span className="material-icons animate-spin mr-1 text-sm">refresh</span>
              Atualizando...
            </>
          ) : (
            <>
              <span className="material-icons text-sm mr-1">refresh</span>
              Atualizar
            </>
          )}
        </Button>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-neutral-200">
          {isLoading ? (
            Array(5)
              .fill(0)
              .map((_, i) => (
                <li key={i} className="px-4 py-4 sm:px-6 animate-pulse">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 mr-3 text-neutral-500">
                        <div className="h-5 w-5 bg-neutral-200 rounded"></div>
                      </div>
                      <div>
                        <div className="h-5 w-40 bg-neutral-200 rounded mb-1"></div>
                        <div className="h-3 w-20 bg-neutral-200 rounded"></div>
                      </div>
                    </div>
                    <div>
                      <div className="h-8 w-24 bg-neutral-200 rounded"></div>
                    </div>
                  </div>
                </li>
              ))
          ) : trends && trends.length > 0 ? (
            trends.map((trend, index) => (
              <li key={trend.id} className="px-4 py-4 sm:px-6 hover:bg-neutral-50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 mr-3 text-neutral-500">
                      <span className="text-sm font-medium">{index + 1}</span>
                    </div>
                    <div>
                      <div className="text-sm font-medium text-primary-600">{trend.title}</div>
                      <div className="text-xs text-neutral-500">{trend.searchVolume} buscas</div>
                    </div>
                  </div>
                  <div>
                    <button
                      type="button"
                      className="inline-flex items-center px-2.5 py-1.5 border border-transparent text-xs font-medium rounded text-primary-700 bg-primary-100 hover:bg-primary-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                      onClick={() => handleGenerateFromTrend(trend)}
                    >
                      Gerar Post
                    </button>
                  </div>
                </div>
              </li>
            ))
          ) : (
            <li className="px-4 py-4 sm:px-6 text-center text-neutral-500">
              Nenhuma tendência encontrada. Tente atualizar.
            </li>
          )}
        </ul>
      </div>

      {/* Generate Post Modal */}
      <GeneratePostModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        initialTrend={selectedTrend}
      />
    </div>
  );
}
