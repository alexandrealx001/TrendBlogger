import { pgTable, text, serial, integer, boolean, timestamp, json, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users schema (kept from original)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name"),
  role: text("role").default("user"),   // 'admin' ou 'user'
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  role: true,
  active: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Trends schema
export const trends = pgTable("trends", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  searchVolume: text("search_volume"),
  publishedAt: text("published_at"),  // Data de publicação para o modo de notícias
  rank: integer("rank"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertTrendSchema = createInsertSchema(trends).omit({
  id: true,
  createdAt: true,
});

export type InsertTrend = z.infer<typeof insertTrendSchema>;
export type Trend = typeof trends.$inferSelect;

// Blog posts schema
export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  metaDescription: text("meta_description"),
  keywords: text("keywords").array(),
  imageUrl: text("image_url"),
  trendId: integer("trend_id"),
  status: text("status").default("draft"), // draft, published, error
  category: text("category").default("geral"), // tecnologia, negocios, financas, saude, politica, esportes, sustentabilidade, educacao, geral
  references: text("references").array(), // Links externos de referência
  createdAt: timestamp("created_at").defaultNow(),
  wordCount: integer("word_count"),
});

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  createdAt: true,
});

export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;

// Schedule schema
export const schedules = pgTable("schedules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  frequency: text("frequency").notNull(), // daily, weekly, monthly
  active: boolean("active").default(true),
  settings: json("settings"), // JSON for flexible settings
  lastRun: timestamp("last_run"),
  nextRun: timestamp("next_run"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertScheduleSchema = createInsertSchema(schedules).omit({
  id: true,
  lastRun: true,
  nextRun: true,
  createdAt: true,
});

export type InsertSchedule = z.infer<typeof insertScheduleSchema>;
export type Schedule = typeof schedules.$inferSelect;

// API Keys schema
export const apiKeys = pgTable("api_keys", {
  id: serial("id").primaryKey(),
  service: text("service").notNull(),
  key: text("key").notNull(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertApiKeySchema = createInsertSchema(apiKeys).omit({
  id: true,
  createdAt: true,
});

export type InsertApiKey = z.infer<typeof insertApiKeySchema>;
export type ApiKey = typeof apiKeys.$inferSelect;

// Visitors schema (for blog users)
export const visitors = pgTable("visitors", {
  id: serial("id").primaryKey(),
  googleId: text("google_id").unique(),
  email: text("email").notNull().unique(),
  password: text("password"),
  cpf: varchar("cpf", { length: 14 }).unique(),
  birthDate: varchar("birth_date", { length: 10 }),
  name: text("name"),
  photoUrl: text("photo_url"),
  lastLogin: timestamp("last_login").defaultNow(),
  loginCount: integer("login_count").default(1),
  createdAt: timestamp("created_at").defaultNow(),
  resetPasswordToken: text("reset_password_token"),
  resetPasswordExpires: timestamp("reset_password_expires"),
});

export const insertVisitorSchema = createInsertSchema(visitors).omit({
  id: true,
  createdAt: true,
  loginCount: true,
  lastLogin: true,
  resetPasswordToken: true,
  resetPasswordExpires: true
});

export type InsertVisitor = z.infer<typeof insertVisitorSchema>;
export type Visitor = typeof visitors.$inferSelect;

// Tabela para estatísticas de visitação do blog
export const pageviews = pgTable("pageviews", {
  id: serial("id").primaryKey(),
  path: text("path").notNull(),
  count: integer("count").notNull().default(0),
  uniqueCount: integer("unique_count").notNull().default(0), // Contagem de IPs únicos
  lastVisit: timestamp("last_visit").defaultNow(),
  createdAt: timestamp("created_at").defaultNow()
});

// Tabela para registrar IPs únicos por página
export const uniqueVisitors = pgTable("unique_visitors", {
  id: serial("id").primaryKey(),
  pageviewId: integer("pageview_id").notNull().references(() => pageviews.id),
  ipAddress: text("ip_address").notNull(),
  userAgent: text("user_agent"),
  visitDate: timestamp("visit_date").defaultNow()
});

export const insertPageviewSchema = createInsertSchema(pageviews).omit({
  id: true,
  count: true,
  uniqueCount: true,
  lastVisit: true,
  createdAt: true
});

export const insertUniqueVisitorSchema = createInsertSchema(uniqueVisitors).omit({
  id: true,
  visitDate: true
});

export type InsertPageview = z.infer<typeof insertPageviewSchema>;
export type Pageview = typeof pageviews.$inferSelect;
export type InsertUniqueVisitor = z.infer<typeof insertUniqueVisitorSchema>;
export type UniqueVisitor = typeof uniqueVisitors.$inferSelect;
