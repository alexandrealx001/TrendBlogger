# TrendPulse - Plataforma de Geração Automática de Conteúdo

Uma plataforma inteligente para geração automatizada de conteúdo para blogs, baseada em tendências e notícias atuais. A aplicação utiliza tecnologias de IA para criar posts relevantes, otimizados para SEO, com uma estrutura clara e imagens contextualizadas.

## Funcionalidades Principais

- **Monitoramento de Tendências**: Integração com Google Trends para identificar tópicos populares no Brasil.
- **Geração de Conteúdo**: Criação automática de posts utilizando OpenAI, com diferentes opções de tamanho e estilo.
- **Agendamento Automático**: Programação de tarefas para criação e publicação de conteúdo.
- **Otimização para SEO**: Geração de conteúdo otimizado para mecanismos de busca.
- **Interface de Blog**: Visualização pública de posts com navegação por categorias.
- **Painel Administrativo**: Gerenciamento completo de posts, configurações e estatísticas.
- **Analytics Avançado**: Rastreamento de visualizações de página e visitantes únicos com métricas por período.

## Tecnologias Utilizadas

- **Frontend**: React.js, TailwindCSS, ShadcnUI
- **Backend**: Node.js, Express
- **Banco de Dados**: PostgreSQL
- **ORM**: Drizzle ORM
- **Autenticação**: Passport.js
- **APIs Externas**: OpenAI, Google Trends, Google Search

## Requisitos

- Node.js 18.x ou superior
- PostgreSQL 14.x ou superior
- Chave de API da OpenAI
- Chave de API do Google Search

## Instalação

1. Clone o repositório
   ```bash
   git clone https://github.com/seu-usuario/trendpulse.git
   cd trendpulse
   ```

2. Instale as dependências
   ```bash
   npm install
   ```

3. Configure as variáveis de ambiente
   ```bash
   cp .env.example .env
   # Edite o arquivo .env com suas credenciais
   ```

4. Execute as migrações do banco de dados
   ```bash
   npm run db:push
   ```

5. Inicie o servidor de desenvolvimento
   ```bash
   npm run dev
   ```

## Implantação em Produção

Consulte o arquivo [DEPLOYMENT.md](DEPLOYMENT.md) para instruções detalhadas sobre como implantar a aplicação em um servidor de produção.